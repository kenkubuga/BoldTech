<?php
session_start();
error_reporting(0);
include('includes/config.php');
$cid=intval($_GET['cid']);
$class=FeeDetails($cid)->Classid;
$level=FeeDetails($cid)->LevelId;
$sql="delete from tblfee where id=:cid ";
$query = $dbh->prepare($sql);
$query->bindParam(':cid',$cid,PDO::PARAM_STR);
$query->execute();
if($class!="*")
{
	$classfee = SumFee($class);
	$allclassfee = SumAllFee($level);
	$totalfee =$classfee+$allclassfee;
	$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$sql="UPDATE `stu_class` SET `class_total_fee`=:total WHERE (`class_id`=:classid) LIMIT 1";
	$query = $dbh->prepare($sql);
	$query->bindParam(':total',$totalfee,PDO::PARAM_STR);
	$query->bindParam(':classid',$class,PDO::PARAM_STR);
	$query->execute();
	$msg="Fee added successfully";
}else
{
	$stmt = $dbh->prepare("SELECT stu_class.class_id FROM stu_class WHERE stu_class.LevelId = :id");
	$stmt->execute(array(':id' => $level));
	while($row=$stmt->fetch(PDO::FETCH_ASSOC))
	{
		$classid=$row['class_id'];
		$classfee = SumFee($classid);
		$allclassfee = SumAllFee($level);
		$totalfee =$classfee+$allclassfee;
		$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql="UPDATE `stu_class` SET `class_total_fee`=:total WHERE (`class_id`=:classid) LIMIT 1";
		$query = $dbh->prepare($sql);
		$query->bindParam(':total',$totalfee,PDO::PARAM_STR);
		$query->bindParam(':classid',$classid,PDO::PARAM_STR);
		$query->execute();
	}
	$msg="Bill Updated successfully";
}
?>