-- phpMyAdmin SQL Dump
-- version 4.0.4.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 31, 2019 at 05:34 PM
-- Server version: 5.5.32
-- PHP Version: 5.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `academydb`
--
CREATE DATABASE IF NOT EXISTS `academydb` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `academydb`;

-- --------------------------------------------------------

--
-- Table structure for table `fee_chart`
--

CREATE TABLE IF NOT EXISTS `fee_chart` (
  `fee_id` int(50) NOT NULL AUTO_INCREMENT,
  `class_id` int(50) NOT NULL,
  `tuition` varchar(100) NOT NULL,
  `computer` varchar(100) NOT NULL,
  `sports` varchar(100) NOT NULL,
  `library` varchar(100) NOT NULL,
  `miscellaneous` varchar(100) NOT NULL,
  PRIMARY KEY (`fee_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `fee_chart`
--

INSERT INTO `fee_chart` (`fee_id`, `class_id`, `tuition`, `computer`, `sports`, `library`, `miscellaneous`) VALUES
(1, 1, '100', '110', '40', '70', '60'),
(2, 2, '50', '80', '40', '30', '40'),
(3, 3, '150', '40', '10', '20', '30'),
(4, 9, '45', '450', '10', '5', '100'),
(5, 4, '50', '25', '25', '35', '60');

-- --------------------------------------------------------

--
-- Table structure for table `paid_fees`
--

CREATE TABLE IF NOT EXISTS `paid_fees` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `stu_id` varchar(100) NOT NULL,
  `Classid` int(11) NOT NULL,
  `amount_paid` varchar(100) NOT NULL,
  `date_received` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `paid_fees`
--

INSERT INTO `paid_fees` (`id`, `stu_id`, `Classid`, `amount_paid`, `date_received`) VALUES
(1, '1', 5, '141', '2018-10-16 10:47:52'),
(2, '18', 10, '200', '2018-10-16 16:32:18'),
(3, '19', 10, '150', '2018-10-16 16:33:56'),
(4, '14133', 1, '200', '2018-11-07 00:02:33');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE IF NOT EXISTS `roles` (
  `role_id` int(50) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(100) NOT NULL,
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE IF NOT EXISTS `staff` (
  `staff_id` int(50) NOT NULL AUTO_INCREMENT,
  `role` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `fullname` varchar(100) NOT NULL,
  `contact` varchar(50) NOT NULL,
  PRIMARY KEY (`staff_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`staff_id`, `role`, `username`, `password`, `fullname`, `contact`) VALUES
(1, '1', 'Kaykay', 'admin', 'Kumangkem', '0233999111'),
(2, '2', 'teach', 'me', 'logindices', '0574564348'),
(7, '1', 'jsadongu', 'P@ssword123', 'Joyce Sadongu ', '0205828734'),
(8, '5', 'STF0012', 'P@ssword123', 'Nathan Abakwile', '0249242924'),
(9, '4', '08101', 'P@ssword123', 'Hassan Hamadu', '0209115979'),
(10, '1', 'tmabakwile', '123', 'Tanimu Morrison Abakwile', '0200321666'),
(11, '3', 'mawakere', 'P@ssword123', 'Martina Awakere', '0209521266'),
(12, '2', 'iopei', 'P@ssword123', 'Isaac Opei', '0540307609'),
(13, '3', 'nathan', '123', 'nathan quine', '0549317781');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE IF NOT EXISTS `student` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `stu_id` int(50) NOT NULL,
  `surname` varchar(100) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `admission_year` varchar(100) NOT NULL,
  `class` varchar(100) NOT NULL,
  `guardian_name` varchar(100) NOT NULL,
  `guardian_contact` varchar(100) NOT NULL,
  `fees_paid` varchar(100) NOT NULL DEFAULT '0',
  `status` varchar(50) NOT NULL DEFAULT 'Owing',
  `Photo` varchar(100) NOT NULL DEFAULT 'default.jpg',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=561 ;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id`, `stu_id`, `surname`, `firstname`, `admission_year`, `class`, `guardian_name`, `guardian_contact`, `fees_paid`, `status`, `Photo`) VALUES
(36, 18101, 'Bogobire', 'Lisa Wesoamo ', '2018/2019', '10', 'TAMAGA SHIRLEY', '0246101345', '0', 'Cleared', 'default.jpg'),
(37, 18102, '  Awinepoya', 'Emelda', '2018 / 2019', '10', 'AWINPOYA EMMANUEL', '0246776150', '0', 'Owing', 'default.jpg'),
(38, 18103, 'Memang', 'Pontian Wenia ', '2018/2019.', '10', 'KAMBOKE MATHILDA', '0247060044', '0', 'Owing', 'default.jpg'),
(39, 18104, 'Abugbilla', 'Wendy ', '2018/2019.', '10', 'ABUGBILLA MATHEW', '0244845402', '0', 'Owing', 'default.jpg'),
(40, 18105, 'Awelana Bantiu', 'Valdrada ', '2018/2019.', '10', 'BANTIU CABRAL', '0244271223', '0', 'Owing', 'default.jpg'),
(41, 18106, 'Wekem Bayigatu', 'Raymond ', '2018/2019.', '10', 'BAYIGATU AKWOWUHOGE', '0242652558', '0', 'Owing', 'default.jpg'),
(42, 18107, 'Weyei Kwara', 'Wenzel  ', '2018/2019.', '10', 'KWARA SAMUEL', '0245988531', '0', 'Owing', 'default.jpg'),
(43, 18108, 'Abdul-Mumin', 'Aisha ', '2018/2019.', '10', 'ABDUL-MUMIN SALIFU', '0247806302', '0', 'Owing', 'default.jpg'),
(44, 18109, 'Kunadawe Campey', 'Godslove  ', '2018/2019.', '10', 'CAMPEY  RUFUS', '0249743844', '0', 'Owing', 'default.jpg'),
(45, 18110, 'Aabaah', 'Adrian ', '2018/2019.', '10', 'AABAAH  IVEN', '0243923853', '0', 'Owing', 'default.jpg'),
(46, 18111, 'Abdul-Rahim Kanamalve', ' Farouk', '2018/2019.', '10', 'ZAKARIA FAROUK', '0243833218', '0', 'Owing', 'default.jpg'),
(47, 18112, 'Apaayine Agebure', 'Anne  ', '2018/2019.', '10', 'MOSES AGEBURE', '0244696764', '0', 'Owing', 'default.jpg'),
(48, 18113, ' Mawutor Baah', 'Joel Godswill', '2018/2019.', '10', 'BAAH  ERIC', '0208384119', '0', 'Owing', 'default.jpg'),
(49, 18114, 'Sackey', 'Iqrah  Narkie ', '2018/2019.', '10', 'SHERRIF  SACKEY', '0201302031', '0', 'Owing', 'default.jpg'),
(50, 18115, 'Yenupang Yaro', 'Hansel  ', '2018/2019.', '10', 'THOMAS YARO', '0203134690', '0', 'Owing', 'default.jpg'),
(51, 18116, 'Akiwele Jakpa', 'Christabel ', '2018/2019.', '10', 'IDDI CHARLES', '0246584056', '0', 'Owing', 'default.jpg'),
(52, 18117, 'Wekea Chatio', 'Lowel ', '2018/2019.', '10', 'CHATIO SAMUEL TANTI', '0508065910', '0', 'Owing', 'default.jpg'),
(53, 18118, 'Wewoli Wewol', 'Chromatius  I', '2018/2019.', '10', 'WEWOLI EDWARD', '0547067820', '0', 'Owing', 'default.jpg'),
(54, 18119, 'Kambasi', 'Naiim  Yenolam ', '2018/2019.', '10', 'ANAS KAMBASI', '0244156254', '0', 'Owing', 'default.jpg'),
(55, 18120, 'Welam Kambonga', 'Petra ', '2018/2019.', '10', 'KAMBONGA  ISSAC', '0249666779', '0', 'Owing', 'default.jpg'),
(56, 18121, 'Anontara', 'Jerry ', '2018/2019.', '10', 'ANONTARA RICHARD', '0551384006', '0', 'Owing', 'default.jpg'),
(57, 18122, 'Apegwine Aguyire', 'Bakhita  ', '2018/2019.', '10', 'GODFRED  AGUYIRE', '0245285484', '0', 'Owing', 'default.jpg'),
(58, 18123, 'Imen', 'Ali', '2018/2019.', '10', 'BARTHOLOMEW  MEMANG', '0245374217', '0', 'Owing', 'default.jpg'),
(59, 18124, 'Anabakem', ' Rian  Asaliwe', '2018/2019.', '10', 'ANABAKEM  ROGER', '0246985040', '0', 'Owing', 'default.jpg'),
(60, 18125, 'Obiri ', 'Basil  Kweku', '2018/2019.', '10', 'WILSON  ADJEI', '0505181390', '0', 'Owing', 'default.jpg'),
(61, 18126, 'Kwose Wezane', ' Audrick  ', '2018/2019.', '10', 'TANDARI ABEL KWOSE', '0247807042', '0', 'Owing', 'default.jpg'),
(62, 18127, 'Zumabone Joshua', '   Sungnuma', '2018/2019.', '10', 'JUSTINE  ZUMABONE', '0247821349', '0', 'Owing', 'default.jpg'),
(63, 18128, 'Zumabone Jasmine', '   Sungsuma', '2018/2019.', '10', 'JUSTINE ZUMABONE', '0247821349', '0', 'Owing', 'default.jpg'),
(64, 18129, 'Mawah Laazib', ' Simeon   ', '2018/2019.', '10', 'ROSEMARY BALINIA', '0245283652', '0', 'Owing', 'default.jpg'),
(65, 18130, 'Arinzechuckwu Odo', ' Victor   ', '2018/2019.', '10', 'ODO ABIGAIL', '0559149346', '0', 'Owing', 'default.jpg'),
(66, 18131, 'Sung-Numa', 'Ang-Naban Israel  ', '2018/2019.', '10', 'EVANS .A. NABAN', '0242863939', '0', 'Owing', 'default.jpg'),
(67, 18132, 'Amoliga', ' Asher', '2018/2019.', '10', 'APANNA GEORGINA', '0240995177', '0', 'Owing', 'default.jpg'),
(68, 18133, 'Abdul-Hakim', 'Zakia ', '2018/2019.', '10', 'ABDUL-HAKIM', '0246903490', '0', 'Owing', 'default.jpg'),
(69, 18134, 'Wemanga Sapio', 'Zina Purity ', '2018/2019.', '10', 'OTHNIEL NAA SAPIO', '0547671010', '0', 'Owing', 'default.jpg'),
(70, 18135, 'Sakyi', 'Rhoda ', '2018/2019.', '10', 'SAKYI GABRIEL', '0207254425', '0', 'Owing', 'default.jpg'),
(71, 18136, 'Atiduba', 'Ransford ', '2018/2019.', '10', 'ATOOBEY  WILFRED', '0249699668', '0', 'Owing', 'default.jpg'),
(72, 18137, 'Bodsum Alem', 'Naveed  ', '2018/2019.', '10', 'ALEM JOHN NDEBURI', '0207444229', '0', 'Owing', 'default.jpg'),
(73, 18138, 'Ayangba', 'Petrina  Teiwe ', '2018/2019.', '10', 'AMBROSE   AYANGBA', '0208677850', '0', 'Owing', 'default.jpg'),
(74, 18139, 'Wewoni Ajonba', 'Victoria  ', '2018/2019.', '10', 'ROCKSON   AJONGBA', '0505181422', '0', 'Owing', 'default.jpg'),
(75, 18140, 'Gbeku', 'Senyonam  Kokutse ', '2018/2019.', '10', 'SELIKEM GBEKU', '0208413970', '0', 'Owing', 'default.jpg'),
(76, 18141, 'Yeboah', 'Dorothy  Nana Afia ', '2018/2019.', '10', 'DR. DOUGLAS BOAH', '0243676263', '0', 'Owing', 'default.jpg'),
(77, 18142, 'Nantomah', 'Ezekiel ', '2018/2019.', '10', 'DR.K. NANTOMAH', '0208298678', '0', 'Owing', 'default.jpg'),
(78, 18143, 'Wenyem Atira-Kaba ', ' Parese', '2018/2019.', '10', 'ATIRA-KABA PARESE', '0248865399', '0', 'Owing', 'default.jpg'),
(79, 18144, 'Wesoamo Akibase', 'Luckycia  ', '2018/2019.', '10', 'AKIBASE  IGNATUS', '0542531994', '0', 'Owing', 'default.jpg'),
(80, 18145, 'Wepaare Aluu', 'Edwin ', '2018/2019.', '10', 'ALUU ROGER', '0246101420', '0', 'Owing', 'default.jpg'),
(81, 18146, 'Babayegiwe Wenawome  Aborah', 'Hikmat ', '2018/2019.', '10', 'WENAWOME ABORAH', '0249433343', '0', 'Owing', 'default.jpg'),
(82, 18147, 'Awelana Aloa', 'Maurice ', '2018/2019.', '10', 'JOSEPH NABAARESE', '0242656966', '0', 'Owing', 'default.jpg'),
(83, 18148, ' Awelana Ayiko', 'Miriam ', '2018/2019.', '10', 'GODWIN ANEPE', '0242042471', '0', 'Owing', 'default.jpg'),
(84, 18149, ' Weyei Kwara', 'Wenel', '2018/2019.', '10', 'KWARA SAMUEL', '0245988531', '0', 'Owing', 'default.jpg'),
(85, 17101, 'Apuri', 'Stanislaus ', '2017/2018.', '11', 'APURI GODFRED', '0209751333', '0', 'Owing', 'default.jpg'),
(86, 17102, 'Abasi', ' Welana', '2017/2018.', '11', 'ABASI JONAS APELIRA', '0202128077', '0', 'Owing', 'default.jpg'),
(87, 17103, 'Seidu Zeeba', 'Baqiyat-Sualihat ', '2017/2018.', '11', 'SEIDU MUSAH', '0246312444', '0', 'Owing', 'default.jpg'),
(88, 17104, 'Anamlie Alongweh', 'Marcia ', '2017/2018.', '11', 'ALONGWEH  EPRAIM', '0248401252', '0', 'Owing', 'default.jpg'),
(89, 17105, 'Boabmahmi Konzabre', 'Janis  ', '2017/2018.', '11', 'JAMES KONZABRE', '0207270391', '0', 'Owing', 'default.jpg'),
(90, 17106, 'Wenawume Abewe', 'Daniella  ', '2017/2018.', '11', 'DANIEL  AZONGO ABEWE', '0207839384', '0', 'Owing', 'default.jpg'),
(91, 17107, ' Asigibe Weyelam', '  Jezel', '2017/2018.', '11', 'JESSE ASIGIBE', '0202850110', '0', 'Owing', 'default.jpg'),
(92, 17108, 'Gbeadese Lansah', 'Luke ', '2017/2018.', '11', 'LANSAH LUKEMAN', '0245111668', '0', 'Owing', 'default.jpg'),
(93, 17109, 'Atipaga', 'Muslimatu ', '2017/2018.', '11', 'ATIPAGA GANIU', '0201959118', '0', 'Owing', 'default.jpg'),
(94, 17110, 'Asaliwe Welaga', 'Cyril  ', '2017/2018.', '11', 'PAUL WELAGA', '0242013589', '0', 'Owing', 'default.jpg'),
(95, 17111, 'Weseh Azuwepeh', 'Gradel ', '2017/2018.', '11', 'AZUWEPEH ABAYAGI', '0243953549', '0', 'Owing', 'default.jpg'),
(96, 17112, 'Aweworo Kuseh', 'Imelda ', '2017/2018.', '11', 'EMMANUEL KUSEH', '0246779773', '0', 'Owing', 'default.jpg'),
(97, 17113, 'Anim Kwadwo', 'Sinapi-Aba ', '2017/2018.', '11', 'KOFI ANIM DWAMENA', '0543959007', '0', 'Owing', 'default.jpg'),
(98, 17114, 'Apewe Atiga', 'Eulogius ', '2017/2018.', '11', 'ATIGA BENNEDICT', '0208185658', '0', 'Owing', 'default.jpg'),
(99, 17115, ' Wekem Amena', 'Fredrick', '2017/2018.', '11', 'SAMUEL AMENA', '0209086686', '0', 'Owing', 'default.jpg'),
(100, 17116, 'Winebood Nambe', 'Abigail  ', '2017/2018.', '11', 'RAZAK NAMBE', '0244662831', '0', 'Owing', 'default.jpg'),
(101, 17117, 'Wepare Awozare', 'Gerald  ', '2017/2018.', '11', 'AWOZARE GERALD', '0248993490', '0', 'Owing', 'default.jpg'),
(102, 17118, 'Wemang Bawoloriko', 'Bright  ', '2017/2018.', '11', 'BAWOLORIKO  GILBERT', '0249582317', '0', 'Owing', 'default.jpg'),
(103, 17119, 'Nyaaba', 'Nulao ', '2017/2018.', '11', 'NYAABA THOMAS', '0241121564', '0', 'Owing', 'default.jpg'),
(104, 17120, 'Weyire Babachuweh', 'Annabel ', '2017/2018.', '11', 'BABACHUWEH DESMOND', '0208070616', '0', 'Owing', 'default.jpg'),
(105, 17121, 'Wenia Kanyagele', 'Eustadiola ', '2017/2018.', '11', 'JOHN KANYAGELE', '0200153831', '0', 'Owing', 'default.jpg'),
(106, 17122, ' Basugu', 'Harris', '2017/2018.', '11', 'BASUGU ZAKARI', '0203655789', '0', 'Owing', 'default.jpg'),
(107, 17123, 'Kunde', 'Jason ', '2017/2018.', '11', 'KUNDE  MAXWELL', '0507465102', '0', 'Owing', 'default.jpg'),
(108, 17124, ' Ajegewe Samari', 'Cornelius ', '2017/2018.', '11', 'SAMARI DAVID', '0244068116', '0', 'Owing', 'default.jpg'),
(109, 17125, ' Pog-Naba Abani', 'Juanita', '2017/2018.', '11', 'JAMES ABANI AWUNI', '0200161390', '0', 'Owing', 'default.jpg'),
(110, 17126, 'Tapsoba    Ali', 'Nawas ', '2017/2018.', '11', 'ALI TAPSOBA', '0200616281', '0', 'Owing', 'default.jpg'),
(111, 17127, 'Kwogyenga', 'Awelan Delicia ', '2017/2018.', '11', 'ROBERT KWOGYENGA', '0209812668', '0', 'Owing', 'default.jpg'),
(112, 17128, 'Abayire Wemochiga', ' Leslie   ', '2017/2018.', '11', 'ABAYIRE   RUDOLF', '0246507954', '0', 'Owing', 'default.jpg'),
(113, 17129, ' Hikimatu', 'Mahamudu', '2017/2018.', '11', 'MAHAMUDU   TIDUNGA', '0549090823', '0', 'Owing', 'default.jpg'),
(114, 17130, 'Duncan', 'Alira ', '2017/2018.', '11', 'ALIRA EMMANUUEL', '0247643928', '0', 'Owing', 'default.jpg'),
(115, 17131, 'Kwowove', ' Janelle', '2017/2018.', '11', 'MICHAEL  KWOWOVE', '0546710416', '0', 'Owing', 'default.jpg'),
(116, 17132, 'Ayiweh Bugapeh', 'Mehitabel  ', '2017/2018.', '11', 'BUGAPEH CLETUS', '0244457585', '0', 'Owing', 'default.jpg'),
(117, 17133, 'Wepia Sulemana', 'Joel Khalid ', '2017/2018.', '11', 'MASAWUDU   SULEMANA', '0554678181', '0', 'Owing', 'default.jpg'),
(118, 17134, 'Wesoamo Adams', 'Ibrahim ', '2017/2018.', '11', 'ISSIFU  FATIMA', '0548230544', '0', 'Owing', 'default.jpg'),
(119, 17135, 'Ajigiwe Chirawotage', 'Presley ', '2017/2018.', '11', 'CHIRAWOTAGE  STANLEY', '0240433630', '0', 'Owing', 'default.jpg'),
(120, 17136, ' Awin-Etego Kwoyire', 'Jude  Newton ', '2017/2018.', '11', 'KWOYIRE LARARUS', '0249041411', '0', 'Owing', 'default.jpg'),
(121, 17137, 'Wekea Aloa', 'Austin ', '2017/2018.', '11', 'ALOA JOSEPH', '0242656966', '0', 'Owing', 'default.jpg'),
(122, 17138, 'Tibietorb Mawah', 'Seminole ', '2017/2018.', '11', 'ROSEMARY BALINIA', '0245283652', '0', 'Owing', 'default.jpg'),
(123, 17139, 'Fangaje', 'Anthonia ', '2017/2018.', '11', 'SINABISI BLENDINA', '0205403957', '0', 'Owing', 'default.jpg'),
(124, 17140, 'Amibase', ' Helga', '2017/2018.', '11', 'AMIBASE  THOMAS', '0209234918', '0', 'Owing', 'default.jpg'),
(125, 17141, 'Alaredewe', 'Achana Zoe   ', '2017/2018.', '11', 'ACHANA   CLETUS', '0244576583', '0', 'Owing', 'default.jpg'),
(126, 17142, ' Ataresum', 'Dalaba Maya ', '2017/2018.', '11', 'DR.MAXWELL DALABA', '0244843904', '0', 'Owing', 'default.jpg'),
(127, 17143, 'Awinebisa .B', 'Enganeba Theophilus  .', '2017/2018.', '11', 'BAINKONGE ENGANEBA', '0202227675', '0', 'Owing', 'default.jpg'),
(128, 17144, 'Ansu Adom', '  Asante', '2017/2018.', '11', 'COLLINS  ANSU', '0207667504', '0', 'Owing', 'default.jpg'),
(129, 17145, 'Hafsa', 'Mamudu ', '2017/2018.', '11', 'BUKARI   MAMUDU', '0242343064', '0', 'Owing', 'default.jpg'),
(130, 17146, 'Awedana', 'Awaregya ', '2017/2018.', '11', 'JULIUS  AWAREGYA', '0242712735', '0', 'Owing', 'default.jpg'),
(131, 17147, 'Awonge  Awintoema', ' Helsa', '2017/2018.', '11', 'AWONGE  MATHEW', '0208957951', '0', 'Owing', 'default.jpg'),
(132, 17148, 'Atiyire', ' Daniella', '2017/2018.', '11', 'ELIJAH  ATIYIRE', '0204225993', '0', 'Owing', 'default.jpg'),
(133, 17149, ' Adaliba', 'Gaddiel  Wekiah', '2017/2018.', '11', 'ROBERT  ADALIBA', '0246458641', '0', 'Owing', 'default.jpg'),
(134, 17150, 'Balinia', 'Ben-Rogers ', '2017/2018.', '11', 'ARTHUR BALINIA ADDA', '0244564437', '0', 'Owing', 'default.jpg'),
(135, 17151, 'Ayinnongya Asusyine', 'Louisa  ', '2017/2018.', '11', 'CHARLES AYEFO', '0208987771', '0', 'Owing', 'default.jpg'),
(136, 17152, 'Nikiema', ' Abiba', '2017/2018.', '11', 'ABDUL-AZIZ NIKIEMA', '0244698163', '0', 'Owing', 'default.jpg'),
(137, 17153, 'Adaliba', 'Linette Awelana ', '2017/2018.', '11', 'ADALIBA CLIFFORD', '0506967560', '0', 'Owing', 'default.jpg'),
(138, 17154, 'Lorlornyo', 'Austin    Ahiada', '2017/2018.', '11', 'ALIRA RITA', '0244027782', '0', 'Owing', 'default.jpg'),
(139, 17155, 'Banadamye', 'Fabian  Wekem ', '2017/2018.', '11', 'SEBASTIAN AGOJE', '0248725203', '0', 'Owing', 'default.jpg'),
(140, 17156, 'Wesonodaga Wese', 'Comfort  ', '2017/2018.', '11', 'WESE ATIGA SAMPSON', '0205576512', '0', 'Owing', 'default.jpg'),
(141, 17157, 'C. Seidu', 'Wewura Immaculte .', '2017/2018.', '11', 'SEIDU EUGENE', '0208385335', '0', 'Owing', 'default.jpg'),
(142, 17158, 'Apoya', 'Terance Ajeidiwe ', '2017/2018.', '11', 'ERIC KWOWE APOYA', '0204495048', '0', 'Owing', 'default.jpg'),
(143, 17159, 'Aduah Abaah', 'Edwin  ', '2017/2018.', '11', 'ABAAH POLYCARP', '0547968779', '0', 'Owing', 'default.jpg'),
(144, 17160, 'Farhan Wunpagere', ' Haruna', '2017/2018.', '11', 'HARUNA SULEMANNA', '0205334248', '0', 'Owing', 'default.jpg'),
(145, 17161, 'Pangabro', 'Neriah  Donlema ', '2017/2018.', '11', 'CHRIS  FUSEINI', '0246078845', '0', 'Owing', 'default.jpg'),
(146, 17162, 'Wenapete Anechana', 'Cleopatra  ', '2017/2018.', '11', 'ROBERT  ANECHANA', '0243905756', '0', 'Owing', 'default.jpg'),
(147, 17163, ' Aryee', 'Kendra  Naa  Deide', '2017/2018.', '11', 'AYI KWEI   ARYEE', '0505005921', '0', 'Owing', 'default.jpg'),
(148, 17164, 'Etsey', 'Andy Elorm Wesoamo ', '2017/2018.', '11', 'ETSEY AMEVOR', '0246717142', '0', 'Owing', 'default.jpg'),
(149, 17165, 'Abakwile', 'Wezem  Quatus ', '2017/2018.', '11', 'ABAWILE  TANIMU', '0244585573', '0', 'Owing', 'default.jpg'),
(150, 17166, 'Dakwari', ' Israel .Y.', '2017/2018.', '11', 'DAKWARI LAARI JOSEPH', '0547266506', '0', 'Owing', 'default.jpg'),
(151, 17167, 'Adom-Domfeh', ' Elisha', '2017/2018.', '11', 'ISSAC ADOM-DOMFEH', '0248723387', '0', 'Owing', 'default.jpg'),
(152, 17168, 'Gertrude', ' Bediako', '2017/2018.', '11', 'BEDIAKO FELICITY', '0246530576', '0', 'Owing', 'default.jpg'),
(153, 17169, ' Atudizane Wedam', 'Patrick  ', '2017/2018.', '11', 'WEDAM   RICHARD', '0509151536', '0', 'Owing', 'default.jpg'),
(154, 17170, ' Minyila', 'Jason  Wetonga', '2017/2018.', '11', 'ROGER MINYILA', '2027051442', '0', 'Owing', 'default.jpg'),
(155, 14101, 'Abdul-Hakim', 'Sakiru ', '2014/2015.', '1', 'UMAR ABDUL-HAKIM', '0246903490', '0', 'Owing', 'default.jpg'),
(156, 14102, 'Asakeboba', ' Chris Aponge', '2014/2015.', '1', 'RAYMONDASAKEBOBA', '0207508225', '0', 'Owing', 'default.jpg'),
(157, 14103, 'Azodewo', ' Gracious A', '2014/2015.', '1', 'AZODEWO MICHAEL', '0249211044', '0', 'Owing', 'default.jpg'),
(158, 14104, 'Wepuga', 'Adaba Rowina ', '2014/2015.', '1', 'PUPURATIRE KWAME ADABA', '0243641980', '0', 'Owing', 'default.jpg'),
(159, 14105, 'Akambe', ' Janice', '2014/2015.', '1', 'AKAMBE KENNETH', '024457738', '0', 'Owing', 'default.jpg'),
(160, 14106, 'Apoya ', 'Thelma Awelana', '2014/2015.', '1', 'APOYA ERIC KWOWE', '0245896187', '0', 'Owing', 'default.jpg'),
(161, 14107, 'Atiirimbey', ' Elton Ayoekanbey', '2014/2015.', '1', 'ATIIRIMBAY A EMMANUEL', '0508129162', '0', 'Owing', 'default.jpg'),
(162, 14108, 'Aguyire', ' Ephraim A.', '2014/2015.', '1', 'AGUYIRE GODFRED ANABA', '0245285484', '0', 'Owing', 'default.jpg'),
(163, 14109, 'Abdul-Rahman', ' Najat', '2014/2015.', '1', 'ABDUL-RAHMAN ABUDU', '0244585607', '0', 'Owing', 'default.jpg'),
(164, 14110, ' Awintumah', 'Azemse Servane', '2014/2015.', '1', 'AZEMSE CHARLES', '0207240000', '0', 'Owing', 'default.jpg'),
(165, 14111, 'Anim Duah', ' Jireh Yaw', '2014/2015.', '1', 'ANIM ISSAC', '0502973005', '0', 'Owing', 'default.jpg'),
(166, 14112, 'Hamidu', 'Abdul-Hamid ', '2014/2015.', '1', 'MARY K KANSIGO', '0244994202', '0', 'Owing', 'default.jpg'),
(167, 14113, ' Daabu', 'Mohammed Jawad', '2014/2015.', '1', 'MOHAMMED DAAR', '0205761295', '0', 'Owing', 'default.jpg'),
(168, 14114, ' Kogyapwah', 'Mildred', '2014/2015.', '1', 'KOGYAPWAH VITUS', '0243885574', '0', 'Owing', 'default.jpg'),
(169, 14115, 'Hassan', 'Jalaludine ', '2014/2015.', '1', 'HASSAN BRAIMAH', '0506110322', '0', 'Owing', 'default.jpg'),
(170, 14116, 'Tanko', 'Nadia ', '2014/2015.', '1', 'TANKO', '0200279216', '0', 'Owing', 'default.jpg'),
(171, 14117, 'Petio', 'Marilyn Wesoamo ', '2014/2015.', '1', 'MAXWELL KWOTAU PETIO', '020752668', '0', 'Owing', 'default.jpg'),
(172, 14118, 'Toffic', ' Haruna', '2014/2015.', '1', 'HARUNA', '0204512478', '0', 'Owing', 'default.jpg'),
(173, 14119, 'Webana', 'Emmanuella ', '2014/2015.', '1', 'WEBANA ALLOU', '0243353860', '0', 'Owing', 'default.jpg'),
(174, 14120, 'Sudeis Ibrahim', 'Erasung  ', '2014/2015.', '1', 'ABDULAI IBRAHIM', '0208864448', '0', 'Owing', 'default.jpg'),
(175, 14121, 'Abagana', 'Winifred A ', '2014/2015.', '1', 'KUBALERE BAWA', '0242280586', '0', 'Owing', 'default.jpg'),
(176, 14122, 'Apusiwine', 'Asanyire Hector ', '2014/2015.', '1', 'AUGUSTINE ASANYIRE', '0246862646', '0', 'Owing', 'default.jpg'),
(177, 14123, 'Atanlana ', 'Selina  Charntel', '2014/2015.', '1', 'ATANLANA', '0508065769', '0', 'Owing', 'default.jpg'),
(178, 14124, 'Akanlu', ' Miranda Awewora', '2014/2015.', '1', 'AKANLU ADEWUYI  N.', '0503617214', '0', 'Owing', 'default.jpg'),
(179, 14125, 'Ayaaba', 'Conrad Wesoeamo ', '2014/2015.', '1', 'DOMINIC AYAABA', '0208447628', '0', 'Owing', 'default.jpg'),
(180, 14126, 'Ahmed', 'Abdul-Muqaddim ', '2014/2015.', '1', 'DAUDA  A JADEED', '0208294475', '0', 'Owing', 'default.jpg'),
(181, 14127, 'Seidu Zeeba', 'Abdul -Kareem ', '2014/2015.', '1', 'SEIDU MUSAH', '0208313038', '0', 'Owing', 'default.jpg'),
(182, 14128, 'Nurideen', 'Hamdia ', '2014/2015.', '1', 'NURIDEEN ALHASSAN', '0244521761', '0', 'Owing', 'default.jpg'),
(183, 14129, 'Apuri', 'Reina ', '2014/2015.', '1', 'APURI GODFRED', '0249231319', '0', 'Owing', 'default.jpg'),
(184, 14130, 'Dikera', 'Marven Wedamdaga ', '2014/2015.', '1', 'DIKERA GODWIN', '0244576633', '0', 'Owing', 'default.jpg'),
(185, 14131, 'Aburiya', 'Awinebuno Tiffiney ', '2014/2015.', '1', 'ABURIYA NYAABA RAYMOND', '0207984464', '0', 'Owing', 'default.jpg'),
(186, 14132, ' Addah', 'Abdul-Hayi Wemoyei', '2014/2015.', '1', 'BABA IDDRISU ADDAH', '0244813783', '0', 'Owing', 'default.jpg'),
(187, 14133, 'Abakwile', 'Ophel ', '2014/2015.', '1', 'TANIMU ABAKWILE', '0244585573', '600', 'Owing', 'default.jpg'),
(188, 14134, 'Aduum', 'Abowine Tatiana ', '2014/2015.', '1', 'ADUUM A NATHANIEL', '0205777066', '0', 'Owing', 'default.jpg'),
(189, 14135, 'Kanyagele', 'Edwin ', '2014/2015.', '1', 'JOHN KANYELE', '0244153831', '0', 'Owing', 'default.jpg'),
(190, 14136, 'Awuge', 'Audrey ', '2014/2015.', '1', 'AUGUSTINE AWUGE', '0248273596', '0', 'Owing', 'default.jpg'),
(191, 14137, 'Adafula', 'Welambatia ', '2014/2015.', '1', 'ADAFULA KWAKU WILDER', '0245680443', '0', 'Owing', 'default.jpg'),
(192, 14138, 'Anechana', ' Colleta-Mina W', '2014/2015.', '1', 'ROBERT ANECHANA', '0208093885', '0', 'Owing', 'default.jpg'),
(193, 14139, 'Aluu', ' Chelsea A', '2014/2015.', '1', 'ALUU ROGER', '0246101420', '0', 'Owing', 'default.jpg'),
(194, 14140, 'Bayigatu', ' Patience', '2014/2015.', '1', 'BAYIGATU AKWOWOOHOGE', '0242652558', '0', 'Owing', 'default.jpg'),
(195, 14141, 'Babachuweh', ' Lucy Awelama', '2014/2015.', '1', 'BABACHUMEK DESMOND', '0208070616', '0', 'Owing', 'default.jpg'),
(196, 14142, 'Abapina', ' Joash', '2014/2015.', '1', 'SAMUEL ABAPINA', '0249817980', '0', 'Owing', 'default.jpg'),
(197, 14143, 'Keriya', 'Prospera ', '2014/2015.', '1', 'KUNZOE KIRIYA', '0246142497', '0', 'Owing', 'default.jpg'),
(198, 14144, ' Kanore', 'Blessing', '2014/2015.', '1', 'GAALINKEH GRACE', '0206578318', '0', 'Owing', 'default.jpg'),
(199, 14145, 'Etsey', 'Arlene Enyonam ', '2014/2015.', '1', 'ELIZABETH KWOSE', '0246717714', '0', 'Owing', 'default.jpg'),
(200, 14146, 'Esime Onai', 'Emmanuela ', '2014/2015.', '1', 'LUCAS ONAI', '0208295275', '0', 'Owing', 'default.jpg'),
(201, 14147, ' Mamudu', 'Kaima', '2014/2015.', '1', 'BUKARI MAMUDU', '0242343064', '0', 'Owing', 'default.jpg'),
(202, 14148, 'Ayiko', ' Aaron', '2014/2015.', '1', 'ANEPE  GODWIN', '020665270', '0', 'Owing', 'default.jpg'),
(203, 14149, 'Abane', 'Kaizerworth W ', '2014/2015.', '1', 'AMORO CLETUS', '0246211515', '0', 'Owing', 'default.jpg'),
(204, 14150, 'Basugu', 'Harith M.A ', '2014/2015.', '1', 'ISSAKA ZAKARI BASUGU', '0203655789', '0', 'Owing', 'default.jpg'),
(205, 14151, 'Bakewey', 'E Patsy  Wesono', '2014/2015.', '1', 'ACHANA  BAKEWEYE', '0244867111', '0', 'Owing', 'default.jpg'),
(206, 14152, 'Adagra', 'Curtis   Wepia ', '2014/2015.', '1', 'ADAGRA CHRISTOPHER', '0243506221', '0', 'Owing', 'default.jpg'),
(207, 14153, 'Darko', ' Ryan  George', '2014/2015.', '1', 'DARKOGEORGE', '0243810035', '0', 'Owing', 'default.jpg'),
(208, 14154, 'Paribi', 'Batachim ', '2014/2015.', '1', 'RITA  AYANGBA', '0242910872', '0', 'Owing', 'default.jpg'),
(209, 14155, 'Akunzera', 'Nora Wemanga ', '2014/2015.', '1', 'JONAS AKUNZWRA', '0242909795', '0', 'Owing', 'default.jpg'),
(210, 14156, 'Atudiwe', 'Nathan  Fangaje', '2014/2015.', '1', 'FANGAJE DAVID', '0244904755', '0', 'Owing', 'default.jpg'),
(211, 14157, ' Womudowe', 'Wisdom   Tiyiamo', '2014/2015.', '1', 'PE OSCAR TIYIAMU  II', '0244780849', '0', 'Owing', 'default.jpg'),
(212, 14158, 'Amoliga', 'Anderson ', '2014/2015.', '1', 'AMOLIGA  DAVID', '0204546033', '0', 'Owing', 'default.jpg'),
(213, 14159, 'Campey', 'Israel  Bendoweh ', '2014/2015.', '1', 'CAMPEY  RUFUS', '0249743844', '0', 'Owing', 'default.jpg'),
(214, 14160, 'Atukiya', 'Cassandra Webasoa ', '2014/2015.', '1', 'ATUKIYA CHRISTOPHER', '0200646281', '0', 'Owing', 'default.jpg'),
(215, 14161, 'Atukiya', 'Cassabel Weyelam ', '2014/2015.', '1', 'ATUKIYA CHRISTOPHER', '0200646281', '0', 'Owing', 'default.jpg'),
(216, 14162, 'Boa-Amponsem', 'Derrick Nana ', '2014/2015.', '1', 'DR. DOUGLAS BOAH', '0243676263', '0', 'Owing', 'default.jpg'),
(217, 13101, 'Hassan', 'Fahima ', '2013/2014.', '2', 'HASSAN HAMADU', '0209115979', '0', 'Owing', 'default.jpg'),
(218, 13102, 'Muntala', 'Abdul Wahab ', '2013/2014.', '2', 'IDDRISU MUNTALA', '0240995573', '0', 'Owing', 'default.jpg'),
(219, 13103, 'Iddrisu', 'Abdul-Rashid ', '2013/2014.', '2', 'ADAM IDDRISU', '0244081172', '0', 'Owing', 'default.jpg'),
(220, 13104, ' Feleeb', 'Slyvester', '2013/2014.', '2', 'KONLAN ISAAC FELEEB', '0245622395', '0', 'Owing', 'default.jpg'),
(221, 13105, ' Mohenu', 'Victoria Aweseh', '2013/2014.', '2', 'MCCARTHY WOTA', '0242614652', '0', 'Owing', 'default.jpg'),
(222, 13106, 'Aboona', ' Genevie Wepia-Am', '2013/2014.', '2', 'ABOONA SOLOMON', '0246592342', '0', 'Owing', 'default.jpg'),
(223, 13107, 'Issifu', 'Mohammed Gazalee ', '2013/2014.', '2', 'INUSAH ISSIFU', '0245160749', '0', 'Owing', 'default.jpg'),
(224, 13108, 'Alatinga', ' Brainy Isaiah', '2013/2014.', '2', 'ALATINGA LOUIS AGAO', '0248992868', '0', 'Owing', 'default.jpg'),
(225, 13109, ' Alangya', 'Adeline', '2013/2014.', '2', 'ALANGYA DANIEL', '0245610266', '0', 'Owing', 'default.jpg'),
(226, 13110, 'Ayando', 'Cyprian ', '2013/2014.', '2', 'AYANDO TIMOTHY', '0243924694', '0', 'Owing', 'default.jpg'),
(227, 13111, 'Pwasam', 'Persis Webagana ', '2013/2014.', '2', 'JAMES K PWASAM', '0204848668', '0', 'Owing', 'default.jpg'),
(228, 13112, 'Binpori', 'Arnold Binyiin ', '2013/2014.', '2', 'BINPORI REUBEN I', '0242032642', '0', 'Owing', 'default.jpg'),
(229, 13113, 'Apayire', 'Tesla-Kuyilam ', '2013/2014.', '2', 'KWAKU APAYIRE', '0244752147', '0', 'Owing', 'default.jpg'),
(230, 13114, 'Akuu', 'Bright ', '2013/2014.', '2', 'AKAMBE MARGARET', '0249118086', '0', 'Owing', 'default.jpg'),
(231, 13115, 'Abakeh', 'Marzel Awewora ', '2013/2014.', '2', 'ROBERT ABAKEH', '0245283652', '0', 'Owing', 'default.jpg'),
(232, 13116, 'Bawoloriko', 'Welam Gloria ', '2013/2014.', '2', 'BAWOLORIKO GILBERT', '0249582317', '0', 'Owing', 'default.jpg'),
(233, 13117, 'Mohammed', 'Hanalatu ', '2013/2014.', '2', 'AKUM SAFIA', '0249613151', '0', 'Owing', 'default.jpg'),
(234, 13118, 'Mwnibuobu Zulhaq', 'Fatin ', '2013/2014.', '2', 'YAHAYA ZULHAQ', '0209193443', '0', 'Owing', 'default.jpg'),
(235, 13119, ' Atariwine', 'Awonge Hermas  ', '2013/2014.', '2', 'AWONGE MATHEW', '0208957851', '0', 'Owing', 'default.jpg'),
(236, 13120, 'Abafari', ' Bill Raphael', '2013/2014.', '2', 'ABAFARI SIMON', '0203338733', '0', 'Owing', 'default.jpg'),
(237, 13121, 'Gyebi', ' Bryan', '2013/2014.', '2', 'ALBERT GYBEI', '0205174705', '0', 'Owing', 'default.jpg'),
(238, 13122, '  Adda', 'Balinia Bervelnard  Natua', '2013/2014.', '2', 'ARTHUR  BALINIA', '0244564437', '0', 'Owing', 'default.jpg'),
(239, 13123, 'Nikiema', 'Sherida ', '2013/2014.', '2', 'ABDUL AZIZ NIKIEMA', '0506225353', '0', 'Owing', 'default.jpg'),
(240, 13124, 'Kwose', ' Abdul -Halid', '2013/2014.', '2', 'KWOSE NOBERT HAFIS', '0240769919', '0', 'Owing', 'default.jpg'),
(241, 13125, 'Wetogeamo', 'Jason  Dalinjong', '2013/2014.', '2', 'CHARLOTTE BASIGIYEM', '0206297635', '0', 'Owing', 'default.jpg'),
(242, 13126, 'Mensah', 'Ama-Benyiwa ', '2013/2014.', '2', 'ANTHONY KOFI MENSAH', '0243253344', '0', 'Owing', 'default.jpg'),
(243, 13127, 'Nchor', 'Amaziah Awinepanga ', '2013/2014.', '2', 'AKANNOBE AUGUSTINE NCHOR', '0202163071', '0', 'Owing', 'default.jpg'),
(244, 13128, 'Kwowove', 'Webre Jason ', '2013/2014.', '2', 'DIDONGO KWOWOVE MICHAEL', '0546710416', '0', 'Owing', 'default.jpg'),
(245, 13129, 'Abem', 'Shaidatu ', '2013/2014.', '2', 'ABEM', '0246354136', '0', 'Owing', 'default.jpg'),
(246, 13130, 'Agyeman', 'Britto    A.K', '2013/2014.', '2', 'BENJAMIN AGYEMANO', '0246358103', '0', 'Owing', 'default.jpg'),
(247, 13131, 'Hamidu', 'Farahatu Awelana ', '2013/2014.', '2', 'MAIDA HAMIDU BOGOBIRI', '024959911', '0', 'Owing', 'default.jpg'),
(248, 13132, ' Dauda', 'Dramani', '2013/2014.', '2', 'DAUDA', '0248991351', '0', 'Owing', 'default.jpg'),
(249, 13133, 'Achana', 'Yvonne Wemochiga ', '2013/2014.', '2', 'JAMES ACHANA', '0242887194', '0', 'Owing', 'default.jpg'),
(250, 13134, 'Abatazore', 'Natacia ', '2013/2014.', '2', 'KUDJO ABATAZORE', '0243659372', '0', 'Owing', 'default.jpg'),
(251, 13135, 'Abdallah', 'Mutia ', '2013/2014.', '2', 'SALIFU ABDALLAH', '0243071762', '0', 'Owing', 'default.jpg'),
(252, 13136, 'Anabakem', 'Salome ', '2013/2014.', '2', 'ANABAKEM ROGER', '0246985040', '0', 'Owing', 'default.jpg'),
(253, 13137, 'Gwala', 'Kelvin ', '2013/2014.', '2', 'VICTORIA ADDA', '0245794706', '0', 'Owing', 'default.jpg'),
(254, 13138, 'Alegewe', 'Dominic ', '2013/2014.', '2', 'REBECCA ALEGEWE', '0245375226', '0', 'Owing', 'default.jpg'),
(255, 13139, 'Achana', 'Ezra Aveidiwe ', '2013/2014.', '2', 'CLETUS', '0244576583', '0', 'Owing', 'default.jpg'),
(256, 13140, 'Awewoyigan', 'Awaregya Bertilla  E', '2013/2014.', '2', 'JULIUS  AWAREGYA', '0208320831', '0', 'Owing', 'default.jpg'),
(257, 13141, 'Yinebon', 'Abani Josie ', '2013/2014.', '2', 'AWUNI JAMES ABANI', '0200161390', '0', 'Owing', 'default.jpg'),
(258, 13142, 'Setiga', ' Carlton', '2013/2014.', '2', 'SETIGA ALEXANDER', '0203092888', '0', 'Owing', 'default.jpg'),
(259, 13143, 'Atukwiah', ' Lincoln .W.', '2013/2014.', '2', 'CHRISTOPHER  ATUKWIAH', '0200646281', '0', 'Owing', 'default.jpg'),
(260, 13144, 'Achile', ' Elijah  Ane', '2013/2014.', '2', 'ACHILE  REGINA', '0248134440', '0', 'Owing', 'default.jpg'),
(261, 13145, 'Achile', ' Elisha  Asaliwe', '2013/2014.', '2', 'ACHILE  REGINA', '0267392803', '0', 'Owing', 'default.jpg'),
(262, 13146, 'Musah Mapuchi', '  Immaculate', '2013/2014.', '2', 'MUSAH   KARIMU', '0243951780', '0', 'Owing', 'default.jpg'),
(263, 13147, 'Afagachie', 'Jayden Wekem ', '2013/2014.', '2', 'KENNEDY AFAGACHIE', '0203449475', '0', 'Owing', 'default.jpg'),
(264, 13148, ' Pagadam', 'Devon  Wezenamo', '2013/2014.', '2', 'MERY ATULE', '0206917828', '0', 'Owing', 'default.jpg'),
(265, 13149, 'Inusah', ' Abdul-Gafaru', '2013/2014.', '2', 'INUSAH', '0244940351', '0', 'Owing', 'default.jpg'),
(266, 13150, 'Cheriba', 'Bright   Karim', '2013/2014.', '2', 'CHERIBA KARIM', '0244633877', '0', 'Owing', 'default.jpg'),
(267, 16101, 'Akuu', 'Makayla ', '2016/2017.', '13', 'AKUU BENJAMIN', '0208042283', '0', 'Owing', 'default.jpg'),
(268, 16102, 'Balua', 'Jayden ', '2016/2017.', '13', 'BALUA A. CHRISTOPHER', '0244967367', '0', 'Owing', 'default.jpg'),
(269, 16103, 'Balua', 'Jordan ', '2016/2017.', '13', 'BALUA A. CHRISTOPHER', '0244967367', '0', 'Owing', 'default.jpg'),
(270, 16104, 'Addah', 'Wesono Shetu ', '2016/2017.', '13', 'BABA I. ADDAH', '0202502522', '0', 'Owing', 'default.jpg'),
(271, 16105, 'Wepaare', 'Tachega Caleb  ', '2016/2017.', '13', 'TACHEGA MARTIN', '0206180216', '0', 'Owing', 'default.jpg'),
(272, 16106, 'Amoliga', ' Alisha', '2016/2017.', '13', 'AMOLIGA  DAVID', '0200741432', '0', 'Owing', 'default.jpg'),
(273, 16107, 'Yinnamyah', 'Gbandana Carl  ', '2016/2017.', '13', 'TIMOTHY  GBANADANA', '0207125864', '0', 'Owing', 'default.jpg'),
(274, 16108, 'Ibrahim  Nuhu', ' Hawa', '2016/2017.', '13', 'IBRAHIM NUHU', '0244049341', '0', 'Owing', 'default.jpg'),
(275, 16109, 'Bakiweyei Agao', 'Wenceslaus   ', '2016/2017.', '13', 'ACHANA NATALIA', '0245996157', '0', 'Owing', 'default.jpg'),
(276, 16110, 'Atongu', 'Fidelis ', '2016/2017.', '13', 'SIMON ATONGU', '0247806840', '0', 'Owing', 'default.jpg'),
(277, 16111, 'Ayiweyem', 'Angela ', '2016/2017.', '13', 'ABAPINA JERRY', '0507163679', '0', 'Owing', 'default.jpg'),
(278, 16112, 'Assana', 'Trisha Elizabeth ', '2016/2017.', '13', 'SOLOMON ADDA', '0206073742', '0', 'Owing', 'default.jpg'),
(279, 16113, ' Fiaxoh', 'Godson Wepia', '2016/2017.', '13', 'BUKARI SAYAKULU', '0242049241', '0', 'Owing', 'default.jpg'),
(280, 16114, 'Zembatia', 'Bismark Wepia ', '2016/2017.', '13', 'AJEGEBA  ZENBATIA', '0243301908', '0', 'Owing', 'default.jpg'),
(281, 16115, 'Iman', ' Abdul-Kadire', '2016/2017.', '13', 'ABDUL-KADIRE', '0243143083', '0', 'Owing', 'default.jpg'),
(282, 16116, 'Nurideen', 'Abdul-Nasri ', '2016/2017.', '13', 'MUMUNI ALIMATU', '0247737972', '0', 'Owing', 'default.jpg'),
(283, 16117, 'Wodah', 'Samuel ', '2016/2017.', '13', 'JOHN WODAH', '0246579684', '0', 'Owing', 'default.jpg'),
(284, 16118, 'Chanagia', ' Phylis', '2016/2017.', '13', 'CHANAGIA  SIMON', '0206401784', '0', 'Owing', 'default.jpg'),
(285, 16119, 'Kwarase', ' Mahasin', '2016/2017.', '13', 'SAFIA BAWA', '0540217280', '0', 'Owing', 'default.jpg'),
(286, 16120, 'Adiyire', ' Bogobire Zulkarnain', '2016/2017.', '13', 'ABDULAI SALIAMATU', '0509165647', '0', 'Owing', 'default.jpg'),
(287, 16121, 'Bayigatu', ' Abigail Awotiga', '2016/2017.', '13', 'BAYIGATU EVELYN', '0247402801', '0', 'Owing', 'default.jpg'),
(288, 16122, ' Wewoli', 'Bertila  Weswoamo', '2016/2017.', '13', 'ADALONG BENEDICTA', '0548489998', '0', 'Owing', 'default.jpg'),
(289, 16123, 'Aniba', 'Blessing Awewoba ', '2016/2017.', '13', 'ADUNI ZULFATAH', '0542381968', '0', 'Owing', 'default.jpg'),
(290, 16124, 'Baah', ' Mirabel Godslove', '2016/2017.', '13', 'SEKPEY GIFTY', '0208384119', '0', 'Owing', 'default.jpg'),
(291, 16125, 'Ayerkey', 'Cudjoe   Dora', '2016/2017.', '13', 'CUDJOE LINDA', '0209112115', '0', 'Owing', 'default.jpg'),
(292, 16126, 'Alogokali', ' Brian  Abaswewe', '2016/2017.', '13', 'ALOGOKALI  SAMPSON', '0246078914', '0', 'Owing', 'default.jpg'),
(293, 16127, 'Akwolaga ', 'Jayden', '2016/2017.', '13', 'JOANA APANGAO', '0242257093', '0', 'Owing', 'default.jpg'),
(294, 16128, 'Anyedina', ' Abel  Wenawume', '2016/2017.', '13', 'SOLOMON  ANYEDINA', '0248577576', '0', 'Owing', 'default.jpg'),
(295, 16129, 'Onai', ' Eliezer  Lelabi', '2016/2017.', '13', 'LUCAS YAW ONAI', '0208295275', '0', 'Owing', 'default.jpg'),
(296, 16130, 'Nongeno', ' Benita  Awelana', '2016/2017.', '13', 'ROBERT  NONGENO', '0201469109', '0', 'Owing', 'default.jpg'),
(297, 16131, 'Abafari', ' Simon   Lamlana', '2016/2017.', '13', 'ABAFARI   SIMON', '0203338733', '0', 'Owing', 'default.jpg'),
(298, 16132, 'Brown', ' Angela', '2016/2017.', '13', 'ELTON  KISSI  BROWN', '0244790778', '0', 'Owing', 'default.jpg'),
(299, 16133, 'Alangya', ' Gerald   Weyipe', '2016/2017.', '13', 'ALANGYA  DANIEL', '0245610266', '0', 'Owing', 'default.jpg'),
(300, 16134, 'Kanore', ' Joshua  Wontewe', '2016/2017.', '13', 'KANORE  AZAGSEYA', '0244483927', '0', 'Owing', 'default.jpg'),
(301, 16135, 'Ntoso', ' Kinvegel', '2016/2017.', '13', 'NTOSO CLEMENT', '0209389490', '0', 'Owing', 'default.jpg'),
(302, 16136, 'Issahaku', 'Ileham ', '2016/2017.', '13', 'AJEBAJENGA  ISSAHAKU', '0541623220', '0', 'Owing', 'default.jpg'),
(303, 16137, 'Annang', 'Aaron  Kwesi ', '2016/2017.', '13', 'ANNANG BENJAMIN', '0246033705', '0', 'Owing', 'default.jpg'),
(304, 16138, 'Aborah', 'Muhsin Wekiyigani Wenawome ', '2016/2017.', '13', 'WENAWOME ABORAH', '0249433343', '0', 'Owing', 'default.jpg'),
(305, 16139, 'Kyereh', 'Joshua ', '2016/2017.', '13', 'SAKYI  GABRIEL', '0207254425', '0', 'Owing', 'default.jpg'),
(306, 16140, 'Akelimbona ', 'Nathan Agebure', '2016/2017.', '13', 'MOSES  AGEBURE', '0244696764', '0', 'Owing', 'default.jpg'),
(307, 16141, 'Baboyire Awonong', 'Nathaniel  ', '2016/2017.', '13', 'AWONONG TITUS', '0245828158', '0', 'Owing', 'default.jpg'),
(308, 16142, 'Ndaa', ' Chriselda', '2016/2017.', '13', 'ATINGA NDAA', '0208762128', '0', 'Owing', 'default.jpg'),
(309, 16143, ' Adaboma', 'Blessing Abugbilla ', '2016/2017.', '13', 'ABUGBILLA MATTHEW', '0544049686', '0', 'Owing', 'default.jpg'),
(310, 16144, 'Ayuba', 'Ramadhaan ', '2016/2017.', '13', 'AYUBA IBRAHIM', '0207111550', '0', 'Owing', 'default.jpg'),
(311, 16145, 'Punparengo', 'Briana Weperi ', '2016/2017.', '13', 'PUNPARENGO P. JUSTICE', '0244028786', '0', 'Owing', 'default.jpg'),
(312, 16146, ' Aboyure', 'Michelle A.', '2016/2017.', '13', 'ABOYURE AUGUSTINE', '0203030052', '0', 'Owing', 'default.jpg'),
(313, 16147, 'Minyila ', 'Bendwowe   Annabel', '2016/2017.', '13', 'COSMOS MINYILA', '0200501618', '0', 'Owing', 'default.jpg'),
(314, 16148, 'Aguyire', ' Conrand    Awiniboma', '2016/2017.', '13', 'GODWIN  AGUYIRE', '0246862622', '0', 'Owing', 'default.jpg'),
(315, 16149, ' Osman', 'Al-Hassan Maltiti', '2016/2017.', '13', 'SABINA  DORAGIA', '0243663487', '0', 'Owing', 'default.jpg'),
(316, 16150, ' Dzinyakpor', 'Elikem Collins', '2016/2017.', '13', 'DZINYAKPOR  FRED', '0200623331', '0', 'Owing', 'default.jpg'),
(317, 16151, 'Atarigiya', 'Mubarak  Muhammed', '2016/2017.', '13', 'ZAKARIA MUHAMMED', '0243708999', '0', 'Owing', 'default.jpg'),
(318, 16152, 'Kambasi', 'Huzaifatu Seweh ', '2016/2017.', '13', 'ANAS .B. KABASI', '0203694918', '0', 'Owing', 'default.jpg'),
(319, 16153, ' Konnu', 'Maria Nsuusom', '2016/2017.', '13', 'KONNU GEOGRE', '0246663090', '0', 'Owing', 'default.jpg'),
(320, 16154, ' Webapwoara', 'Wedam Jean-Mary ', '2016/2017.', '13', 'WEDAM LAWRENCE', '0244411909', '0', 'Owing', 'default.jpg'),
(321, 16155, ' Asigibe', 'Julian Madiba', '2016/2017.', '13', 'ASIGIBE MARLEY', '0201234716', '0', 'Owing', 'default.jpg'),
(322, 16156, 'Yinme', 'Michael Mwinnenaa ', '2016/2017.', '13', 'IRENE ANGBING', '0209692392', '0', 'Owing', 'default.jpg'),
(323, 16157, ' Pwadura', 'Thomas Aquinas.A.', '2016/2017.', '13', 'PWADURA ALICE', '0501275225', '0', 'Owing', 'default.jpg'),
(324, 16158, 'Abadigao', ' Melvin  Wezanamo', '2016/2017.', '13', 'ABADIGOA ERIC', '0201838388', '0', 'Owing', 'default.jpg'),
(325, 16159, 'Ahmed', ' Abubakar- Sadik', '2016/2017.', '13', 'AHMED JADEED', '0208294475', '0', 'Owing', 'default.jpg'),
(326, 16160, ' Wezane', 'Bakete Francine ', '2016/2017.', '13', 'BIA LILIAN', '0200540837', '0', 'Owing', 'default.jpg'),
(327, 16161, 'Alhassan', 'Harith ', '2016/2017.', '13', 'PRUDENCE', '0208762432', '0', 'Owing', 'default.jpg'),
(328, 16162, ' Mantanso', 'Farouk Firdaus', '2016/2017.', '13', 'FAROUK ZAKARIA', '0243832180', '0', 'Owing', 'default.jpg'),
(329, 16163, 'Ayando', ' Reindorf Atarawine', '2016/2017.', '13', 'AYANDO TIMOTHY', '0206652124', '0', 'Owing', 'default.jpg'),
(330, 16164, 'Binpori', ' Reynold', '2016/2017.', '13', 'MAASANG  JUSTINA', '0205492804', '0', 'Owing', 'default.jpg'),
(331, 16165, 'Wepiah', ' Harry  Wepaari', '2016/2017.', '13', 'JOSHUA   WEPIAH', '0203196946', '0', 'Owing', 'default.jpg'),
(332, 16166, 'Kambasi', ' Jordan   Kwowora', '2016/2017.', '13', 'KAMBASI   SEBASTIAN', '0200632006', '0', 'Owing', 'default.jpg'),
(333, 16167, 'Pagadam', ' Rodney   Bendowe', '2016/2017.', '13', 'DAVID BAWA PAGADAM', '0244580337', '0', 'Owing', 'default.jpg'),
(334, 16168, 'Pagadam', ' Ryann   Akiwele', '2016/2017.', '13', 'DAVID   BAWA PAGADAM', '0203154007', '0', 'Owing', 'default.jpg'),
(335, 16169, 'Amoasah', ' Leonard', '2016/2017.', '13', 'AMOASAH   ERNEST', '0245608946', '0', 'Owing', 'default.jpg'),
(336, 16170, '. Kahil', 'Abdul-Rauf .B', '2016/2017.', '13', 'ABDUL-RAUF SEIDU', '0208387709', '0', 'Owing', 'default.jpg'),
(337, 16171, 'Awampaga', 'Morgan ', '2016/2017.', '13', 'AWAMPAGA CLEMENT', '0246779686', '0', 'Owing', 'default.jpg'),
(338, 16172, 'Moctar', 'Ramzia ', '2016/2017.', '13', 'MOCTAR MAIGA', '0244593523', '0', 'Owing', 'default.jpg'),
(339, 16173, 'Webakura ', 'Arnold Kandwe', '2016/2017.', '13', 'OBED KANDWE WEPARI', '0205006977', '0', 'Owing', 'default.jpg'),
(340, 16174, 'Wese Kufiah', 'Vincent  ', '2016/2017.', '13', 'KUFIAH WESE CHARLES', '0246911598', '0', 'Owing', 'default.jpg'),
(341, 16175, 'Ajongeba', ' Tanasha    Yezuranu', '2016/2017.', '13', 'JACQUELINE YORESE', '0200616509', '0', 'Owing', 'default.jpg'),
(342, 16176, ' Mwinbaluuro', 'Jenelle-Amy Dassah', '2016/2017.', '13', 'DASSAH  SYLVESTER', '0209249862', '0', 'Owing', 'default.jpg'),
(343, 16177, ' Adda', 'Saviour  Wekia', '2016/2017.', '13', 'ADDA FREDINAND', '0546900665', '0', 'Owing', 'default.jpg'),
(344, 16178, ' Boateng', 'Stacy  Ansomaa', '2016/2017.', '13', 'CLEMENT BOATENG', '0242516451', '0', 'Owing', 'default.jpg'),
(345, 16179, 'Gbeku', 'Sefemor Koku ', '2016/2017.', '13', 'GBEKU SELIKEM', '0208413970', '0', 'Owing', 'default.jpg'),
(346, 15101, 'Akugri', ' Collette Wesono', '2015/2016.', '14', 'STEPHEN AKUGRI', '0244810261', '0', 'Owing', 'default.jpg'),
(347, 15102, 'Sakea', 'Sylvia Welam ', '2015/2016.', '14', 'SAKEA GRACE', '0503612096', '0', 'Owing', 'default.jpg'),
(348, 15103, 'Amitaba', ' Emmanuella', '2015/2016.', '14', 'AMITABA EMMANUEL', '0507364101', '0', 'Owing', 'default.jpg'),
(349, 15104, 'Amoah', ' Webakura Seminole', '2015/2016.', '14', 'AMOAH KENNEDY', '0203836218', '0', 'Owing', 'default.jpg'),
(350, 15105, 'Afaga-Apaba', ' Godslove', '2015/2016.', '14', 'AVOGOGE DESMOND', '0547067823', '0', 'Owing', 'default.jpg'),
(351, 15106, 'Kabah', ' Vincent Wekem', '2015/2016.', '14', 'JAMES KWOLAGA KABAH', '054827624', '0', 'Owing', 'default.jpg'),
(352, 15107, 'Kabah', ' Victor   Wedam', '2015/2016.', '14', 'JAMES KWOLAGA KABAH', '0548427624', '0', 'Owing', 'default.jpg'),
(353, 15108, 'Formecar', ' Prince', '2015/2016.', '14', 'RAYMOND FORMECAR', '0261063342', '0', 'Owing', 'default.jpg'),
(354, 15109, 'Sulemana', ' Bevelen', '2015/2016.', '14', 'MASAWUDU SULEMANA', '0245374130', '0', 'Owing', 'default.jpg'),
(355, 15110, 'Mathias', 'Kaliza Wemochiga ', '2015/2016.', '14', 'KABA KALIZA', '0246143630', '0', 'Owing', 'default.jpg'),
(356, 15111, 'Aabaah', ' Dane', '2015/2016.', '14', 'IVEN AABAAHH', '0243923853', '0', 'Owing', 'default.jpg'),
(357, 15112, 'Konzabre', ' Justin  Yinteeb', '2015/2016.', '14', 'JAMES KONZABRE', '0207270391', '0', 'Owing', 'default.jpg'),
(358, 15113, 'Abayire', ' Platini Atogkwoah', '2015/2016.', '14', 'ABAYIRE FRANCIAS', '0203058688', '0', 'Owing', 'default.jpg'),
(359, 15114, 'Saalana', ' Fasbir Reece', '2015/2016.', '14', 'SAALANA', '0200965940', '0', 'Owing', 'default.jpg'),
(360, 15115, 'Achagetune', ' Brian Wepeeri', '2015/2016.', '14', 'ACHAGETUNE VITUS', '0203516822', '0', 'Owing', 'default.jpg'),
(361, 15116, 'Tipagya', 'Shafawu  Latif', '2015/2016.', '14', 'ADAMS LATIF', '0206635981', '0', 'Owing', 'default.jpg'),
(362, 15117, 'Annan', ' Kesiah Acheampomaa', '2015/2016.', '14', 'ANNAN COLLINS', '0204851753', '0', 'Owing', 'default.jpg'),
(363, 15118, 'Kubati ', 'Richlove Atudeawe', '2015/2016.', '14', 'AKENDAGA EMMANUEL A', '0243929091', '0', 'Owing', 'default.jpg'),
(364, 15119, 'Abayire', ' Alexis', '2015/2016.', '14', 'WEBONGA', '0246507954', '0', 'Owing', 'default.jpg'),
(365, 15120, 'Ayangba', ' Fergan   Wedaga', '2015/2016.', '14', 'NABA AYANGBA AMBROSE', '0208677850', '0', 'Owing', 'default.jpg'),
(366, 15121, 'Kodelogo ', 'Polycarp   Webadua', '2015/2016.', '14', 'KODELOGO  FREDERICK', '0201786413', '0', 'Owing', 'default.jpg'),
(367, 15122, ' Ajago', 'Antonia Adaldiwe', '2015/2016.', '14', 'AJAGO ALBERT BAYIRINIA', '0203549917', '0', 'Owing', 'default.jpg'),
(368, 15123, ' Donnawonu', 'Edson Atudiwe', '2015/2016.', '14', 'DONNAWONU ROBERT', '0200334819', '0', 'Owing', 'default.jpg'),
(369, 15124, 'Akolgo', ' Godswill Ayinbono', '2015/2016.', '14', 'FRANCIS ABAGNA', '0208377971', '0', 'Owing', 'default.jpg'),
(370, 15125, 'Timbilla', 'Ezekiel ', '2015/2016.', '14', 'ANNA .A. TIMBILLA', '0206433053', '0', 'Owing', 'default.jpg'),
(371, 15126, 'Ayichuru', 'Kieran ', '2015/2016.', '14', 'PAUL AYICHURU', '0200313960', '0', 'Owing', 'default.jpg'),
(372, 15127, 'Kambonga', ' Wayne  Ajegetena', '2015/2016.', '14', 'NORBERT KAMBONGA', '0201541254', '0', 'Owing', 'default.jpg'),
(373, 15128, 'Logojoori', 'Bright Aneyoani ', '2015/2016.', '14', 'CHORO CHRISTOPHER', '0208418052', '0', 'Owing', 'default.jpg'),
(374, 15129, 'Zulhaq', 'Fadil Hena-Nea ', '2015/2016.', '14', 'YAHAYA ZULHAQ', '0209193443', '0', 'Owing', 'default.jpg'),
(375, 15130, 'Nchor', 'Grace  Abeesum ', '2015/2016.', '14', 'NYAABA MARY', '0207651547', '0', 'Owing', 'default.jpg'),
(376, 15131, ' Bayanyinah', 'Yasir Abdul-Rauf', '2015/2016.', '14', 'PASCALINA A BILLY', '0265025990', '0', 'Owing', 'default.jpg'),
(377, 15132, 'Anyoka ', 'Stephanie', '2015/2016.', '14', 'ANYOKA DOUGLAS', '0207652690', '0', 'Owing', 'default.jpg'),
(378, 15133, 'Naseem', ' Hadeyta', '2015/2016.', '14', 'YAKUBU NASEEM', '0207651819', '0', 'Owing', 'default.jpg'),
(379, 15134, 'Abdul-Mumin', ' Nasiba-Witoresema', '2015/2016.', '14', 'ABDUL-MUMIN SALIFU', '0264922599', '0', 'Owing', 'default.jpg'),
(380, 15135, 'Mohammed', ' Shamsu', '2015/2016.', '14', 'MOHAMMED ABULA', '0205866608', '0', 'Owing', 'default.jpg'),
(381, 15136, 'Alira', ' Dominion', '2015/2016.', '14', 'ALIRA TIMOTHY', '0200955139', '0', 'Owing', 'default.jpg'),
(382, 15137, 'Alira ', 'David', '2015/2016.', '14', 'ALIRA TIMOTHY', '0200955139', '0', 'Owing', 'default.jpg'),
(383, 15138, 'Akanyim', ' Manuel   A', '2015/2016.', '14', 'AKANYIN ROBERT', '020367830', '0', 'Owing', 'default.jpg'),
(384, 15139, 'Abakeh', ' Milana Awelana', '2015/2016.', '14', 'ABAKEH ROBERTO', '0247071909', '0', 'Owing', 'default.jpg'),
(385, 15140, '  Woninomma', 'Adams Salahud-Deen ', '2015/2016.', '14', 'ADAMS OSMAN', '0205790957', '0', 'Owing', 'default.jpg'),
(386, 15141, 'Achaab ', 'Eucharia', '2015/2016.', '14', 'ACHAAB KANFASI FELIX', '0245284644', '0', 'Owing', 'default.jpg'),
(387, 15142, 'Ataogye', ' Corand Adipari', '2015/2016.', '14', 'ATAOGYE SYLVESTER', '0200645458', '0', 'Owing', 'default.jpg'),
(388, 15143, 'Azuwepeh ', 'Godiva', '2015/2016.', '14', 'GEORVANI AZUWEPEH', '0243953549', '0', 'Owing', 'default.jpg'),
(389, 15144, 'Logotuah', ' Welamma Petra', '2015/2016.', '14', 'LOGOTUAH EMMMANUEL', '0242267280', '0', 'Owing', 'default.jpg'),
(390, 15145, 'Maapeh', ' Pearl', '2015/2016.', '14', 'ALFRED MAAPEH', '0209422052', '0', 'Owing', 'default.jpg'),
(391, 15146, 'Atombil', ' Edith  Awelamma', '2015/2016.', '14', 'ATOMBIL  SIMON', '0208776293', '0', 'Owing', 'default.jpg'),
(392, 15147, 'Ansu ', 'Nana Ama Nhyira', '2015/2016.', '14', 'ANSU  COLLIN', '0207667504', '0', 'Owing', 'default.jpg'),
(393, 15148, 'Matuweamu ', 'Musah   Felicitas', '2015/2016.', '14', 'KARIMU MUSAH', '0208781502', '0', 'Owing', 'default.jpg'),
(394, 15149, 'Wonje', ' Ronel  Awelana', '2015/2016.', '14', 'DANIEL WONJE  AJEGIWE', '0200243199', '0', 'Owing', 'default.jpg'),
(395, 15150, ' Apeligiba', 'Victor Awinsune', '2015/2016.', '14', 'RAYMOND  APELIGIBA', '0207755345', '0', 'Owing', 'default.jpg'),
(396, 15151, ' Bagna', 'Ridwan Weyire', '2015/2016.', '14', 'BAGNA IBRAHIM', '0200764282', '0', 'Owing', 'default.jpg'),
(397, 15152, ' Winpang', 'Naila   Alem', '2015/2016.', '14', 'ALEM JOHN', '2027444229', '0', 'Owing', 'default.jpg'),
(398, 15153, 'Zumasigee', 'Marron ', '2015/2016.', '14', 'BASIMBO DIANA', '0551036658', '0', 'Owing', 'default.jpg'),
(399, 15154, ' Songsoma', 'Elsie Jebuni', '2015/2016.', '14', 'JEBUNI FRANK ALAN', '0206099409', '0', 'Owing', 'default.jpg'),
(400, 15155, 'Kuswopaga', 'Theophilus    Danjori', '2015/2016.', '14', 'DANJORI EBENEZER', '0248765152', '0', 'Owing', 'default.jpg'),
(401, 12101, ' Azemse', 'Sebastian Akudbilla', '2012/2013.', '3', 'AZEMSE CHARLES M', '0207240000', '0', 'Owing', 'default.jpg'),
(402, 12102, ' Naban', 'Elsie Sonni', '2012/2013.', '3', 'EVANS A NABAN', '0242863939', '0', 'Owing', 'default.jpg'),
(403, 12103, 'Kassin', 'Abdul Wakilu ', '2012/2013.', '3', 'ESI KASSIN', '0249146908', '0', 'Owing', 'default.jpg'),
(404, 12104, 'Tanimu', 'Abiba Ibrahim ', '2012/2013.', '3', 'IBRAHIM TANIMU', '0209811880', '0', 'Owing', 'default.jpg'),
(405, 12105, 'Minyila', 'Lamlamma Audrey ', '2012/2013.', '3', 'FAUTINA ATUKIYAH', '0243270018', '0', 'Owing', 'default.jpg'),
(406, 12106, ' Hammond', 'Hannah', '2012/2013.', '3', 'MALIK BOAKYE', '0249449667', '0', 'Owing', 'default.jpg'),
(407, 12107, 'Asusyine', 'Prince ', '2012/2013.', '3', 'MBA AGNES', '0209430220', '0', 'Owing', 'default.jpg'),
(408, 12108, 'Ayigtogri', 'Ezekiel ', '2012/2013.', '3', 'MOSES AYIGTOGRI', '0240124651', '0', 'Owing', 'default.jpg'),
(409, 12109, 'Assim Daabu', ' Mahama', '2012/2013.', '3', 'MAHAMA IDDRISU', '0208676861', '0', 'Owing', 'default.jpg'),
(410, 12110, ' Haruna', 'Radiyatu', '2012/2013.', '3', 'HARUNA SULEMANA', '0243648470', '0', 'Owing', 'default.jpg'),
(411, 12111, ' Kwara', 'Mehetabel Wesoamo', '2012/2013.', '3', 'KWARA YAW', '02', '0', 'Owing', 'default.jpg'),
(412, 12112, ' Kunde', 'Kellen Wentemi', '2012/2013.', '3', 'BABA KUNDE', '0246524320', '0', 'Owing', 'default.jpg'),
(413, 12113, 'Dikumwine', 'Mabel ', '2012/2013.', '3', 'DIKUMWINE K. LAMBERT', '0243681130', '0', 'Owing', 'default.jpg'),
(414, 12114, 'Adawina', 'Himelin ', '2012/2013.', '3', 'ADAWINA JAMES', '0249489083', '0', 'Owing', 'default.jpg'),
(415, 12115, 'Amankwah', 'Ebenezer.K ', '2012/2013.', '3', 'EDWARD KOFI AMANKWAH', '0249048161', '0', 'Owing', 'default.jpg'),
(416, 12116, 'Awewuri', 'Eunice Welaga ', '2012/2013.', '3', 'SAMUEL WELAGA', '0246816135', '0', 'Owing', 'default.jpg'),
(417, 12117, 'Alhassan', 'Bahkita ', '2012/2013.', '3', 'ALHASSAN ABDUL GAFARU', '0249311501', '0', 'Owing', 'default.jpg'),
(418, 12118, ' Azibayela', 'Narcissus    A.', '2012/2013.', '3', 'AZIBAYELA', '0245224277', '0', 'Owing', 'default.jpg'),
(419, 12119, ' Pwavia', 'Sered Wepia', '2012/2013.', '3', 'MR.DININTA PWAVIA', '0204606266', '0', 'Owing', 'default.jpg'),
(420, 12120, 'Nambe', ' Nathaniel', '2012/2013.', '3', 'RAZAK  NAMBE', '0244662831', '0', 'Owing', 'default.jpg'),
(421, 12121, 'Welaga', ' Sophia Madiwe', '2012/2013.', '3', 'PAUL WELAGA', '0242013589', '0', 'Owing', 'default.jpg'),
(422, 12122, 'Adabi', 'Issah Abdul-Mustam ', '2012/2013.', '3', 'ADABI ISSAH', '0204207313', '0', 'Owing', 'default.jpg'),
(423, 12123, 'Doragia ', 'Wesoamo  Tiinawura', '2012/2013.', '3', 'DORAGIA NARCISSUS', '0244893963', '0', 'Owing', 'default.jpg'),
(424, 12124, ' Kudamo', 'Reuben  Zurinyira', '2012/2013.', '3', 'KUDAMO  STANLEY', '0248585835', '0', 'Owing', 'default.jpg'),
(425, 12125, 'Atidumba', 'Henry  Ayameboka ', '2012/2013.', '3', 'ATOOBEY  WILFRED', '0249699668', '0', 'Owing', 'default.jpg'),
(426, 12126, 'Naseem', 'Munibatu-Rahiman ', '2012/2013.', '3', 'YAKUBU NASEEM', '0261372190', '0', 'Owing', 'default.jpg'),
(427, 12127, 'Ayichuru', 'Atudi-Awe Nathan ', '2012/2013.', '3', 'AYICHURU PAUL', '0249780932', '0', 'Owing', 'default.jpg'),
(428, 12128, 'Dalaba', 'Mandy Ayamzoya ', '2012/2013.', '3', 'ANEH JUSTINA', '0242214690', '0', 'Owing', 'default.jpg'),
(429, 12129, 'Alhassan', 'Nadia ', '2012/2013.', '3', 'ALHASSAN', '0203907036', '0', 'Owing', 'default.jpg'),
(430, 12130, 'Annan', 'Lois ', '2012/2013.', '3', 'ANNAN COLLINS', '0548134190', '0', 'Owing', 'default.jpg'),
(431, 12131, 'Ajongba', 'Bateizem Davida ', '2012/2013.', '3', 'ABALEVA ERIC', '0243320474', '0', 'Owing', 'default.jpg'),
(432, 12132, 'Nabengye', 'Theodora Wesoamo ', '2012/2013.', '3', 'BEATRICE AFOBIKU', '0246739025', '0', 'Owing', 'default.jpg'),
(433, 12133, 'Akoka', 'Benjamin ', '2012/2013.', '3', 'RICHARD AKOKA', '0242860003', '0', 'Owing', 'default.jpg'),
(434, 12134, 'Azuntaaba', 'Shatel ', '2012/2013.', '3', 'AZUNTAABA GIFTY', '0267549367', '0', 'Owing', 'default.jpg'),
(435, 12135, 'Adiali', 'Michelle Lois ', '2012/2013.', '3', 'ANE MERCY', '0207199212', '0', 'Owing', 'default.jpg'),
(436, 12136, ' Abaching', 'Ebenezer Wemaaga', '2012/2013.', '3', 'GLADYS', '024527081', '0', 'Owing', 'default.jpg'),
(437, 12137, ' Akibase', 'Francis Xavier', '2012/2013.', '3', 'AKIBASE AZAGESEYA IGNATIUS', '0541809919', '0', 'Owing', 'default.jpg'),
(438, 12138, ' Kambonga', 'Kimberly A.W', '2012/2013.', '3', 'NORBERT KAMBONGA', '0243256462', '0', 'Owing', 'default.jpg'),
(439, 12139, 'Amoasah', 'Lordina ', '2012/2013.', '3', 'ERNEST AMOASAH', '0245608946', '0', 'Owing', 'default.jpg'),
(440, 12140, 'Mensah', 'Nana Edumadze ', '2012/2013.', '3', 'ANTHONY KOFI MENSAH', '0243253344', '0', 'Owing', 'default.jpg'),
(441, 12141, 'Adiyire', 'Zulaiha  Bogobiri', '2012/2013.', '3', 'SAMAD BOGOBIRE', '0245285593', '0', 'Owing', 'default.jpg'),
(442, 12142, ' Awini', 'Joel Asaana', '2012/2013.', '3', 'MICHEAL AWINI', '0208775515', '0', 'Owing', 'default.jpg'),
(443, 12143, 'Abdulai', 'Hiba ', '2012/2013.', '3', 'ABDULAI', '0542381750', '0', 'Owing', 'default.jpg'),
(444, 12144, ' Adams', 'Shamima  Nasara', '2012/2013.', '3', 'LATIF ADAMS', '0206635981', '0', 'Owing', 'default.jpg'),
(445, 12145, 'Kyei', 'Dylan .A. ', '2012/2013.', '3', 'LYDIA WEPIA', '0203174427', '0', 'Owing', 'default.jpg');
INSERT INTO `student` (`id`, `stu_id`, `surname`, `firstname`, `admission_year`, `class`, `guardian_name`, `guardian_contact`, `fees_paid`, `status`, `Photo`) VALUES
(446, 12146, 'Asakeboba', ' Mary Ann-Wechegi-Amo', '2012/2013.', '3', 'ASAKEBOBA RAYMOND', '0547070871', '0', 'Owing', 'default.jpg'),
(447, 12147, 'Mohammed', 'Hamdiatu ', '2012/2013.', '3', 'MOHAMMED', '0241099442', '0', 'Owing', 'default.jpg'),
(448, 12148, 'Wenia-Amo', 'Amena Gloria  ', '2012/2013.', '3', 'AMENA  SAMUEL', '0209086686', '0', 'Owing', 'default.jpg'),
(449, 11101, 'Apuri', 'Frederica ', '2011/2012.', '4', 'APURI GODFRED', '0249231319', '0', 'Owing', 'default.jpg'),
(450, 11102, 'Petio', 'Michelle Maawe ', '2011/2012.', '4', 'PETIO', '0242663550', '0', 'Owing', 'default.jpg'),
(451, 11103, 'Nchor', 'Anselm Asigsunga ', '2011/2012.', '4', 'AKANNOBE WISDOM N.', '0245244553', '0', 'Owing', 'default.jpg'),
(452, 11104, 'Apayire', 'Bernstein Webura ', '2011/2012.', '4', 'KWAKU', '0244752147', '0', 'Owing', 'default.jpg'),
(453, 11105, 'Aboyure', 'Mildred Atogetege ', '2011/2012.', '4', 'ABOYURE AUGUSTINE', '024484783', '0', 'Owing', 'default.jpg'),
(454, 11106, 'Adaliba', 'Eliezer Wekem ', '2011/2012.', '4', 'ABACHENG MARY', '0246458641', '0', 'Owing', 'default.jpg'),
(455, 11107, ' Gilla', 'Valeria Weseamo', '2011/2012.', '4', 'DAVID GILLA', '024638570', '0', 'Owing', 'default.jpg'),
(456, 11108, 'Anyoka', 'Newton ', '2011/2012.', '4', 'ANYOKA MERCY', '0207652690', '0', 'Owing', 'default.jpg'),
(457, 11109, ' Seidu', 'Jaladeen', '2011/2012.', '4', 'ADINAN', '0249860557', '0', 'Owing', 'default.jpg'),
(458, 11110, 'Adongo', 'Conrad ', '2011/2012.', '4', 'ADONGO E.A', '0208600822', '0', 'Owing', 'default.jpg'),
(459, 11111, ' Iddrisu', 'Abubakar Zibah', '2011/2012.', '4', 'ROSEMARY', '0268823811', '0', 'Owing', 'default.jpg'),
(460, 11112, 'Osman', 'Mariam Deishini ', '2011/2012.', '4', 'SABINA', '0243663437', '0', 'Owing', 'default.jpg'),
(461, 11113, 'Kaba', 'Edwina ', '2011/2012.', '4', 'ADIBURA JANET RAKIATU', '0248404684', '0', 'Owing', 'default.jpg'),
(462, 11114, 'Adongo', 'Laurine ', '2011/2012.', '4', 'LAZOROS ADONGO', '0248990813', '0', 'Owing', 'default.jpg'),
(463, 11115, 'Akanyim', 'George Cyril ', '2011/2012.', '4', 'ABOBE SYLVIA', '0543820741', '0', 'Owing', 'default.jpg'),
(464, 11116, ' Abudu', 'Zita Ashley', '2011/2012.', '4', 'LYDIA KOGANA', '0246319647', '0', 'Owing', 'default.jpg'),
(465, 11117, 'Sakea', 'Gifty ', '2011/2012.', '4', 'SAKER GRACE', '0246909619', '0', 'Owing', 'default.jpg'),
(466, 11118, 'Azanlerigu', 'Whitney  A.', '2011/2012.', '4', 'AWURE SLIM', '0540323797', '0', 'Owing', 'default.jpg'),
(467, 11119, 'Akewele', 'Antoanette  Atogebania', '2011/2012.', '4', 'SUSANA ATOGEBANIA', '0242259476', '0', 'Owing', 'default.jpg'),
(468, 11120, 'Gidigo', 'Pamela Esinam ', '2011/2012.', '4', 'JOHN KOFI GIDIGO', '0244801537', '0', 'Owing', 'default.jpg'),
(469, 11121, 'Amibase', 'Awinepaliya Noreen ', '2011/2012.', '4', 'THOMAS AMIBASE', '0209234918', '0', 'Owing', 'default.jpg'),
(470, 11122, 'Ayipe', 'Justin-Leslie Wekem ', '2011/2012.', '4', 'AYIPE ALHASSAN', '0243244768', '0', 'Owing', 'default.jpg'),
(471, 11123, ' Alhassan', 'Faruza', '2011/2012.', '4', 'ALHASSAN', '0203907036', '0', 'Owing', 'default.jpg'),
(472, 11124, 'Abuba ', 'Hebatu Salifu', '2011/2012.', '4', 'AQBYBA SALIFU', '0244665573', '0', 'Owing', 'default.jpg'),
(473, 11125, 'Logotuah', ' Wepia Pearl', '2011/2012.', '4', 'LOGOTUAH EMMANUEL', '0205176209', '0', 'Owing', 'default.jpg'),
(474, 11126, ' Ayaaba', 'Elenor  Welam', '2011/2012.', '4', 'AYAABA DOMINIC', '0208447628', '0', 'Owing', 'default.jpg'),
(475, 11127, 'Nyaaba', ' Wezaane', '2011/2012.', '4', 'NYAABA  THOMAS', '0241121564', '0', 'Owing', 'default.jpg'),
(476, 11128, 'Ayerter', 'Cudjoe  Sixtus', '2011/2012.', '4', 'CUDJOE LINDA', '0209112115', '0', 'Owing', 'default.jpg'),
(477, 11129, 'Tiyiamo', ' Betty', '2011/2012.', '4', 'TIYIAMO   OSCAR   BATABI', '0205174558', '0', 'Owing', 'default.jpg'),
(478, 11130, 'Nchor', 'Theresa  Awineyela ', '2011/2012.', '4', 'NCHOR JOHN  AJOGIYAM', '0246491368', '0', 'Owing', 'default.jpg'),
(479, 11131, 'Kwosongo', 'Prosper ', '2011/2012.', '4', 'ANNANG BENJAMIN', '0249889978', '0', 'Owing', 'default.jpg'),
(480, 11132, 'Ayipe', 'Wepia ', '2011/2012.', '4', 'TAYAM EDITH', '0207533706', '0', 'Owing', 'default.jpg'),
(481, 11133, 'Dakwari ', 'Shadrach  .Y.', '2011/2012.', '4', 'DAKWARI  LAARI JOSEPH', '0242620272', '0', 'Owing', 'default.jpg'),
(482, 11134, 'Sakyi', 'Benjamin ', '2011/2012.', '4', 'SAKYI GABRIEL', '0207254425', '0', 'Owing', 'default.jpg'),
(483, 10101, 'Abayire', ' Freda Kapuri', '2010/2011.', '5', 'GEORGINA ABAYIRE', '0246507954', '0', 'Owing', 'default.jpg'),
(484, 10102, 'Bayigatu', 'Mable Wenawume ', '2010/2011.', '5', 'EVELYN BAYIGATU', '0247402801', '0', 'Owing', 'default.jpg'),
(485, 10103, 'Adagiyele', 'Mckenzy Wematu ', '2010/2011.', '5', 'JEROME', '0246773428', '0', 'Owing', 'default.jpg'),
(486, 10104, 'Ahiada', 'Audrey Etornam ', '2010/2011.', '5', 'RITA ALIRA WENAWUME', '0244027782', '0', 'Owing', 'default.jpg'),
(487, 10105, 'Babachuweh', 'Michael Awewura ', '2010/2011.', '5', 'LUCY AKO A', '0243220591', '0', 'Owing', 'default.jpg'),
(488, 10106, 'Abakeh', 'Michelle Ajegewe ', '2010/2011.', '5', 'JANE BAYOR', '0200983205', '0', 'Owing', 'default.jpg'),
(489, 10107, 'Punparengo', 'Hansel Amangpare ', '2010/2011.', '5', 'PEWORA P JUSTICS', '0244028786', '0', 'Owing', 'default.jpg'),
(490, 10108, 'Maapeh', 'Vanessa Wemoyei ', '2010/2011.', '5', 'ALFREAD MAAPEH', '0249511196', '0', 'Owing', 'default.jpg'),
(491, 10109, ' Babachuweh', 'Michelle Anuyiri', '2010/2011.', '5', 'LUCY AKO A', '0243220591', '0', 'Owing', 'default.jpg'),
(492, 10110, 'Zembatia', 'Lawrencia ', '2010/2011.', '5', 'AGUSWINE', '0246434977', '0', 'Owing', 'default.jpg'),
(493, 10111, 'Abem', 'Sheriff ', '2010/2011.', '5', 'MUNATU', '0248249030', '0', 'Owing', 'default.jpg'),
(494, 10112, ' Sedoctor', 'Desmond', '2010/2011.', '5', 'SEDOCTOR', '0249226517', '0', 'Owing', 'default.jpg'),
(495, 10113, 'Ajegeba', 'Doreen Ayirewura ', '2010/2011.', '5', 'LAMBERT', '0243015518', '0', 'Owing', 'default.jpg'),
(496, 10114, 'Feleeb', 'Rita Y ', '2010/2011.', '5', 'KONLAN ISAAC FELEEB', '0245622395', '0', 'Owing', 'default.jpg'),
(497, 10115, ' Samari', 'Polycarp Wemochiga', '2010/2011.', '5', 'SAMARI PATRICIA', '0243151174', '0', 'Owing', 'default.jpg'),
(498, 10116, ' Abakwile', 'Sakina', '2010/2011.', '5', 'MARTINA ABAKWILE', '0249242924', '0', 'Owing', 'default.jpg'),
(499, 10117, ' Abakwile', 'Perez', '2010/2011.', '5', 'MARTINA AWAKERE', '0209521266', '0', 'Owing', 'default.jpg'),
(500, 10118, 'Akanlu', 'Rupert Weswa-Amo ', '2010/2011.', '5', 'AKANLU KAWIA MATILDA', '0245608925', '0', 'Owing', 'default.jpg'),
(501, 10119, 'Ayageyire', 'Harriet .W. ', '2010/2011.', '5', 'LAZARUS .A', '0206714790', '0', 'Owing', 'default.jpg'),
(502, 10120, 'Awozare', 'Wekea Evelyn ', '2010/2011.', '5', 'GERALD ATAWORA', '0209115801', '0', 'Owing', 'default.jpg'),
(503, 10121, 'Nuhu', ' Faiza', '2010/2011.', '5', 'ZABRIM  NUHU', '0269205070', '0', 'Owing', 'default.jpg'),
(504, 10122, 'Yamtot', ' Joan Vianney', '2010/2011.', '5', 'YAMTOT THOMAS', '0204510009', '0', 'Owing', 'default.jpg'),
(505, 10123, ' Brown', 'Michelle', '2010/2011.', '5', 'ELTON BROWN', '0508784040', '0', 'Owing', 'default.jpg'),
(506, 10124, 'Bakeweye', ' Peggy  Welandaga', '2010/2011.', '5', 'ACHANA  BAKEWEYE', '0244867111', '0', 'Owing', 'default.jpg'),
(507, 10125, 'Afaradaga', ' Mac-Ralph', '2010/2011.', '5', 'AFARADAGA', '0249229037', '0', 'Owing', 'default.jpg'),
(508, 10126, 'Alhassan', ' Wakeelah   Makakpia', '2010/2011.', '5', 'ALHASSAN   SALIFU', '0200957527', '0', 'Owing', 'default.jpg'),
(509, 10127, ' Akunzera', 'Carl Adoliwine', '2010/2011.', '5', 'JONAS AKUNZERA', '0242909795', '0', 'Owing', 'default.jpg'),
(510, 10128, 'Akantoe', ' Abraham', '2010/2011.', '5', 'DAVID  AMOLIGA', '0200741432', '0', 'Owing', 'default.jpg'),
(511, 10129, 'Yeboah', 'Daniela Nana Akua ', '2010/2011.', '5', 'DR.DOUGLAS BOAH', '0243676263', '0', 'Owing', 'default.jpg'),
(512, 9101, 'Akanson', 'Ezekiel ', '2009/2010.', '6', 'AKANSON AKANLU JIM', '0248276358', '0', 'Owing', 'default.jpg'),
(513, 9102, ' Allou', 'Bright', '2009/2010.', '6', 'I.P ALLOU', '0245179087', '0', 'Owing', 'default.jpg'),
(514, 9103, 'Achana', 'Levi Atudewe ', '2009/2010.', '6', 'CHRISTY', '0244576583', '0', 'Owing', 'default.jpg'),
(515, 9104, 'Aluah', 'Henry W ', '2009/2010.', '6', 'THOMPSON ALUAH', '0266567197', '0', 'Owing', 'default.jpg'),
(516, 9105, ' Daabu ', 'Aqeelmahama', '2009/2010.', '6', 'IDDRISU', '0244163909', '0', 'Owing', 'default.jpg'),
(517, 9106, 'Akimikisi', 'Debajei Rolanda ', '2009/2010.', '6', 'ASIMIKISI', '0246213232', '0', 'Owing', 'default.jpg'),
(518, 9107, 'Awini', 'Justine Lamisi ', '2009/2010.', '6', 'AWINI MICHEAL', '0242569607', '0', 'Owing', 'default.jpg'),
(519, 9108, 'Alobase', 'Shemer ', '2009/2010.', '6', 'ALOBASE RAPHAEL', '0242257093', '0', 'Owing', 'default.jpg'),
(520, 9109, ' Minyila', 'Godson Wefaro', '2009/2010.', '6', 'COSMOS MINYILA', '0243270018', '0', 'Owing', 'default.jpg'),
(521, 9110, ' Akambe', 'Josephine', '2009/2010.', '6', 'AKAMBE', '0242553491', '0', 'Owing', 'default.jpg'),
(522, 9111, ' Sabutu', 'Ramatu', '2009/2010.', '6', 'SABUTU ABDULAI', '0208503450', '0', 'Owing', 'default.jpg'),
(523, 9112, 'Mamudu', 'Hafiz ', '2009/2010.', '6', 'BUKARI MAMUDU', '0242343064', '0', 'Owing', 'default.jpg'),
(524, 9113, ' Zindam', 'Lordess', '2009/2010.', '6', 'ZINDAM EDMOND', '0549603476', '0', 'Owing', 'default.jpg'),
(525, 9114, 'Abapina', 'Hezekiah   Babayagiwe ', '2009/2010.', '6', 'SAMUEL ABAPINA', '0542310079', '0', 'Owing', 'default.jpg'),
(526, 9115, 'Sulemana', ' Mariama', '2009/2010.', '6', 'SULEMANA FUSEINI', '0209692158', '0', 'Owing', 'default.jpg'),
(527, 9116, 'Brown', 'Michael A. ', '2009/2010.', '6', 'AGANZUA K. VICTORIA', '0502577933', '0', 'Owing', 'default.jpg'),
(528, 9117, 'Ahmed', 'Fatahia ', '2009/2010.', '6', 'AHMED JADEED', '0208294475', '0', 'Owing', 'default.jpg'),
(529, 8101, 'Hassan ', 'Faizah', '2008/2009.', '7', 'HASSAN HAMADU', '0244736818', '0', 'Owing', 'default.jpg'),
(530, 8102, 'Dikumwine', ' Marita', '2008/2009.', '7', 'DIKUMWINE LAMBERT', '0243681130', '0', 'Owing', 'default.jpg'),
(531, 8103, 'Sadik', 'Saratu   Bogobiri', '2008/2009.', '7', 'AHMED SADIK BOGOBIRI', '0248213379', '0', 'Owing', 'default.jpg'),
(532, 8104, 'Gidigo', 'Simon ', '2008/2009.', '7', 'JOHN KOFI GIDIGO', '0244801537', '0', 'Owing', 'default.jpg'),
(533, 8105, ' Kukiyoni', 'Joel', '2008/2009.', '7', 'KUKIYONI GILBERT', '0247436589', '0', 'Owing', 'default.jpg'),
(534, 8106, ' Sabito', 'Abdul Kamil', '2008/2009.', '7', 'SABITO ISSIFU', '0249558537', '0', 'Owing', 'default.jpg'),
(535, 8107, 'Dalaba', 'Minerva ', '2008/2009.', '7', 'DALABA MAXWELL', '0244843904', '0', 'Owing', 'default.jpg'),
(536, 8108, ' Feleeb', 'Sandra', '2008/2009.', '7', 'KONLAN ISAAC FELEEB', '0245622395', '0', 'Owing', 'default.jpg'),
(537, 8109, 'Awinime', 'Shirley ', '2008/2009.', '7', 'GOERGE', '0249083906', '0', 'Owing', 'default.jpg'),
(538, 8110, ' Sulemana', 'Ibrahim', '2008/2009.', '7', 'SULEMANA', '0245284723', '0', 'Owing', 'default.jpg'),
(539, 8111, ' Anao', 'Joshua', '2008/2009.', '7', 'KENNEDY MAAKWO', '0548425201', '0', 'Owing', 'default.jpg'),
(540, 8112, 'Mumuni', 'Jamal-Deen ', '2008/2009.', '7', 'MUMUNI', '0244802379', '0', 'Owing', 'default.jpg'),
(541, 8113, 'Nawuntemi ', 'Gabriel Bawah', '2008/2009.', '7', 'FRANCIS BADAWEL', '0203057576', '0', 'Owing', 'default.jpg'),
(542, 8114, 'Anechana', 'Cydonia W. ', '2008/2009.', '7', 'ROBERT ANACHANA', '0208093885', '0', 'Owing', 'default.jpg'),
(543, 8115, 'Abanonavae', ' Venissa', '2008/2009.', '7', 'ABONONAVAE JAMES', '0207736377', '0', 'Owing', 'default.jpg'),
(544, 8116, ' Ayaaba', 'Damian Wedam', '2008/2009.', '7', 'AYAABA DOMINIC', '0208447628', '0', 'Owing', 'default.jpg'),
(545, 8117, ' Iddrisu', 'Humaida', '2018/2019', '7', 'ADAM IDDRISU', '0246416222', '0', 'Owing', 'default.jpg'),
(546, 8118, 'Bampe', 'Denzi ', '2008/2009.', '8', 'PATRICK', '0541104946', '0', 'Owing', 'default.jpg'),
(547, 8119, ' Bayigatu', 'Simon Atingdwi', '2008/2009.', '8', 'BAYIGATU', '0242652558', '0', 'Owing', 'default.jpg'),
(548, 8120, 'Ayangba', 'Randy Wematu ', '2008/2009.', '8', 'AYANGBA AMBROSE', '0245377993', '0', 'Owing', 'default.jpg'),
(549, 8121, 'Amibase', 'Ursula ', '2008/2009.', '8', 'THOMAS AMIBASE', '0209234918', '0', 'Owing', 'default.jpg'),
(550, 8122, ' Achaab', 'Anabel', '2008/2009.', '8', 'KANFOSI ACAAB', '0245284644', '0', 'Owing', 'default.jpg'),
(551, 8123, 'Abdul Majeed', 'Ramatu ', '2008/2009.', '8', 'ABDUL MAJEED', '0541623831', '0', 'Owing', 'default.jpg'),
(552, 8124, 'Ayichuru', 'Carl ', '2008/2009.', '8', 'PAUL AYICHURU', '0243905527', '0', 'Owing', 'default.jpg'),
(553, 8125, 'Amuriyaga', 'Manuella ', '2008/2009.', '8', 'AMURIYAGA ISSAC', '020138945', '0', 'Owing', 'default.jpg'),
(554, 8126, 'Chanase', 'Osmund ', '2008/2009.', '8', 'AKURUGU AGARTHA', '050418022', '0', 'Owing', 'default.jpg'),
(555, 8127, 'Logotuah', ' Wenia Pamela', '2008/2009.', '8', 'EMMANUEL LOGOTUAH', '0242267280', '0', 'Owing', 'default.jpg'),
(556, 8128, ' Sadongo', 'Jeremiah K.', '2008/2009.', '8', 'JOHN SADONGO', '0205352145', '0', 'Owing', 'default.jpg'),
(557, 8129, 'Acquah-Dadzie', 'Anthony ', '2008/2009.', '8', 'IREN D.A.YINME', '0545566746', '0', 'Owing', 'default.jpg'),
(558, 8130, 'Kwakyewaa ', 'Julian  Kekeli', '2017', '8', 'AVORYI GODWIN', '0246628766', '0', 'Owing', '8130.jpg'),
(559, 8131, 'Sakyi', 'Roselyn ', '2018/2019', '8', 'GABRIEL SAKYI', '0207254425', '0', 'Owing', 'default.jpg'),
(560, 19001, 'Kubuga', 'Ken', '2018/2019', '24', 'Ken', '0244887736', '0', 'Owing', 'default.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `stu_class`
--

CREATE TABLE IF NOT EXISTS `stu_class` (
  `class_id` int(50) NOT NULL AUTO_INCREMENT,
  `class_name` varchar(100) NOT NULL,
  `class_total_fee` varchar(100) NOT NULL DEFAULT '0',
  `LevelId` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`class_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `stu_class`
--

INSERT INTO `stu_class` (`class_id`, `class_name`, `class_total_fee`, `LevelId`) VALUES
(1, 'Stage 1A', '210', 5),
(2, 'Stage  2A', '200', 5),
(3, 'Stage  3', '200', 5),
(4, 'Stage  4', '0', 3),
(5, 'Stage  5', '0', 3),
(6, 'Stage 6', '0', 3),
(7, 'JHS 1', '600', 4),
(8, 'JHS 2', '650', 4),
(9, 'JHS 3', '400', 4),
(10, 'Nursery 1A', '175', 1),
(11, 'Nursery 2B', '300', 1),
(12, 'Creche', '0', 1),
(13, 'Kindergarten 1A', '0', 2),
(14, 'Kindergarten 2B', '0', 2),
(17, 'Kindergarten 1B', '0', 2),
(19, 'Kindergarten 2A', '0', 2),
(20, 'Nursery 1B', '0', 1),
(21, 'Nursery 2A', '0', 1),
(22, 'Stage 1B', '0', 5),
(23, 'Stage 2B', '0', 5),
(24, 'Alumni Class', '0', 4),
(25, 'Primary 7', '0', 3);

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE IF NOT EXISTS `subjects` (
  `subject_id` int(50) NOT NULL AUTO_INCREMENT,
  `subject_class` varchar(100) NOT NULL,
  `subject_name` varchar(100) NOT NULL,
  `subject_teacher` varchar(100) NOT NULL,
  PRIMARY KEY (`subject_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tblarrears`
--

CREATE TABLE IF NOT EXISTS `tblarrears` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stu_id` varchar(50) NOT NULL,
  `term` varchar(10) NOT NULL,
  `arrears` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22 ;

--
-- Dumping data for table `tblarrears`
--

INSERT INTO `tblarrears` (`id`, `stu_id`, `term`, `arrears`) VALUES
(10, '18101', 'Second', '560.00'),
(12, '18103', 'Second', '251.00'),
(14, '16101', 'First', '309.00'),
(15, '15101', 'First', '309.00'),
(16, '8101', 'First', '909.00'),
(17, '17105', 'First', '300.00'),
(18, '13101', 'Second', '150.00'),
(20, '18104', 'Second', '112.50');

-- --------------------------------------------------------

--
-- Table structure for table `tblexpenses`
--

CREATE TABLE IF NOT EXISTS `tblexpenses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(100) NOT NULL,
  `reason` varchar(1000) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `date` date NOT NULL,
  `cashier` varchar(100) DEFAULT NULL,
  `officer` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `tblexpenses`
--

INSERT INTO `tblexpenses` (`id`, `type`, `reason`, `amount`, `date`, `cashier`, `officer`) VALUES
(3, 'Fuel and lubricant ', 'fuel for headteachers ', '40.00', '2018-12-05', 'Martina Awakere', ''),
(4, 'sanitation', 'liquid soap for cleaning ', '5.00', '2018-12-05', 'Martina Awakere', ''),
(5, 'fuel and lubricant', 'fuel for headteachers', '40.00', '2018-12-06', 'Martina Awakere', ''),
(6, 'repair and maintenance', 'servicing and replacement of copier tonner and rollers', '400.00', '2018-12-06', 'nathan quine', ''),
(7, 'Administrative', 'Stationery', '120.00', '2019-01-15', 'Kumangkem', 'Sir Moses'),
(8, 'Administrative', 'January Light Bill', '400.00', '2019-01-24', 'Kumangkem', 'Leo'),
(9, 'aDMIN', 'Light Bill', '100.00', '2019-01-31', 'Kumangkem', 'logindices');

-- --------------------------------------------------------

--
-- Table structure for table `tblfee`
--

CREATE TABLE IF NOT EXISTS `tblfee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `FeeName` varchar(50) NOT NULL,
  `Fee` decimal(10,2) NOT NULL,
  `Classid` varchar(10) NOT NULL DEFAULT '*',
  `LevelId` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=37 ;

--
-- Dumping data for table `tblfee`
--

INSERT INTO `tblfee` (`id`, `FeeName`, `Fee`, `Classid`, `LevelId`) VALUES
(25, 'tuition', '0.00', '1', 5),
(30, 'Tuition Fee P2', '200.00', '2', 5),
(29, 'Tuition Fee P1', '200.00', '1', 5),
(31, 'Tuition Fee P3', '200.00', '3', 5),
(32, 'Printing Fee P1', '10.00', '1', 5),
(33, 'Nursery Fee', '120.00', '10', 1),
(34, 'PTA Levy', '25.00', '10', 1),
(35, 'Feeding', '30.00', '10', 1),
(36, 'Nursery 2B', '300.00', '11', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblfeepayment`
--

CREATE TABLE IF NOT EXISTS `tblfeepayment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stu_id` varchar(50) NOT NULL,
  `transtype` varchar(25) NOT NULL,
  `classid` int(11) NOT NULL,
  `term` varchar(10) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `Rdate` date NOT NULL,
  `cashier` varchar(100) NOT NULL,
  `acyear` varchar(50) NOT NULL,
  `reason` varchar(500) NOT NULL,
  `status` varchar(20) NOT NULL,
  `paydate` date NOT NULL,
  `NameDep` text NOT NULL,
  `paybank` text NOT NULL,
  `paymode` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=136 ;

--
-- Dumping data for table `tblfeepayment`
--

INSERT INTO `tblfeepayment` (`id`, `stu_id`, `transtype`, `classid`, `term`, `amount`, `Rdate`, `cashier`, `acyear`, `reason`, `status`, `paydate`, `NameDep`, `paybank`, `paymode`) VALUES
(114, '18101', 'Credit', 10, 'Second', '11.00', '2019-01-28', '1', '2018/2019', 'Testpayment', 'approved', '2019-01-08', 'fgfdgs', 'GNBank ', 'Cash'),
(112, '18101', 'Credit', 10, 'Second', '297.00', '2019-01-24', '1', '2018/2019', 'Jayy', 'approved', '2019-01-17', 'depositor', 'GNBank ', 'Direct Payment'),
(113, '18101', 'Credit', 10, 'Second', '10.00', '2019-01-28', '1', '2018/2019', 'Testpayment', 'approved', '2019-01-17', 'fadsfds', 'GNBank ', 'Cheque'),
(110, '18101', 'Credit', 10, 'Second', '297.00', '2019-01-24', '1', '2018/2019', 'Jake', 'approved', '2019-01-23', 'fdfads', 'Barclays ', 'Direct Payment'),
(109, '18101', 'Credit', 10, 'Second', '297.00', '2019-01-24', '1', '2018/2019', 'Alabi', 'approved', '2019-01-10', 'ALabale', 'Barclays ', 'Cheque'),
(107, '18104', 'Credit', 10, 'Second', '100.00', '2019-01-24', '1', '2018/2019', 'partpayment for January', 'approved', '2019-01-04', 'His Fatther', 'GNBank ', 'Cash'),
(108, '18104', 'Reversal', 10, 'Second', '-20.00', '2019-01-24', '1', '2018/2019', 'eRROR', '', '0000-00-00', '', '', ''),
(101, '18101', 'Credit', 10, 'Second', '34.00', '2019-01-24', '1', '2018/2019', 'Testpayment', 'approved', '2019-01-11', 'hsdd', ' Stanbic', 'Cash'),
(89, '18135', 'Credit', 10, 'Second', '25.00', '2019-01-24', 'cashier', '2018/2019', 'Night task', 'approved', '2019-01-23', 'Kimathi', 'Barclays ', ''),
(90, '18135', 'Credit', 10, 'Second', '35.00', '2019-01-24', 'cashier', '2018/2019', 'Day time task', 'approved', '2017-05-16', 'Kada', 'Barclays ', 'Direct Payment'),
(91, '18103', 'Credit', 10, 'Second', '232.00', '2019-01-24', '1', '2018/2019', 'New fees', '', '0000-00-00', '', '', ''),
(92, '14133', 'Credit', 1, 'Second', '5.00', '2019-01-24', 'cashier', '2018/2019', 'Clear fees', 'approved', '2019-01-10', 'Father ', ' Prudential', 'Cash'),
(93, '14133', 'Credit', 1, 'Second', '107.50', '2019-01-24', 'cashier', '2018/2019', 'Clear fees', 'approved', '2019-01-17', 'dada', ' Prudential', 'Cash'),
(94, '14133', 'Credit', 1, 'Second', '1.00', '2019-01-24', '1', '2018/2019', 'Testpayment', 'approved', '2019-01-10', 'jono', ' Stanbic', 'Cash'),
(95, '14133', 'Credit', 1, 'Second', '1.00', '2019-01-24', '1', '2018/2019', 'Testpayment', 'approved', '2019-01-10', 'Kay', ' Prudential', 'Direct Payment'),
(96, '14133', 'Credit', 1, 'Second', '5.00', '2019-01-24', '1', '2018/2019', 'Testpayment', 'approved', '2019-01-10', 'fdfdas', 'GNBank ', 'Cash'),
(97, '17102', 'Credit', 11, 'Second', '70.00', '2019-01-24', '1', '2018/2019', 'Testpayment', 'approved', '2019-01-17', 'baba', ' Prudential', 'Cash'),
(98, '17102', 'Credit', 11, 'Second', '6.00', '2019-01-24', '1', '2018/2019', 'Testpayment', 'approved', '2019-01-17', 'fsdfa', ' Prudential', 'Cheque'),
(104, '18101', 'Credit', 10, 'Second', '2.00', '2019-01-24', '1', '2018/2019', 'Testpayment', 'approved', '2019-01-10', 'rS', 'GNBank ', 'Cash'),
(105, '18101', 'Credit', 10, 'Second', '4.00', '2019-01-24', '1', '2018/2019', 'Testpayment', 'approved', '2019-01-10', 'GFWERTR', 'GNBank ', 'Cash'),
(99, '18101', 'Credit', 10, 'Second', '11.00', '2019-01-24', '1', '2018/2019', 'Testpayment', 'approved', '2019-01-17', 'fafdfad', ' Prudential', 'Cash'),
(100, '18101', 'Credit', 10, 'Second', '2.00', '2019-01-24', '1', '2018/2019', 'Testpayment', 'approved', '2019-01-02', 'dfds', ' Prudential', 'Cash'),
(102, '18101', 'Credit', 10, 'Second', '2.00', '2019-01-24', '1', '2018/2019', 'Testpayment', 'approved', '2019-01-17', 'dfadf', ' Prudential', 'Cash'),
(103, '18101', 'Credit', 10, 'Second', '7.00', '2019-01-24', '1', '2018/2019', 'Testpayment', 'approved', '2019-01-04', 'hana', ' Prudential', 'Cash'),
(111, '18101', 'Credit', 10, 'Second', '300.00', '2019-01-24', '1', '2018/2019', 'FINNAL PAY', 'approved', '2019-01-02', 'fdsfdafdsfad', ' Stanbic', 'Cheque'),
(106, '18101', 'Credit', 10, 'Second', '1.00', '2019-01-24', '1', '2018/2019', 'partpayment', 'approved', '2019-01-11', 'JOJOJ', ' Stanbic', 'Cash'),
(115, '18101', 'Credit', 10, 'Second', '10.00', '2019-01-28', '1', '2018/2019', 'Testpayment', 'approved', '2019-01-04', 'Looo', 'Cash', 'Cheque'),
(116, '18101', 'Credit', 10, 'Second', '297.00', '2019-01-28', '1', '2018/2019', 'Full payment', 'approved', '2019-01-24', 'Test', 'Cash', 'Cash'),
(117, '18103', 'Credit', 10, 'Second', '251.00', '2019-01-28', '1', '2018/2019', 'Testpayment', 'approved', '2019-01-23', 'dadfada', 'Cheque', 'Cheque'),
(118, '18101', 'Credit', 10, 'Second', '342.00', '2019-01-28', '1', '2018/2019', 'Testpayment', 'approved', '2019-01-18', 'jbkk', 'Prudential', 'Direct Payment'),
(119, '18101', 'Credit', 10, 'Second', '297.00', '2019-01-28', '1', '2018/2019', 'Testpayment', 'approved', '2019-01-14', 'vk', 'Stanbic Bank', 'Cheque'),
(120, '18104', 'Credit', 10, 'Second', '112.00', '2019-01-28', '1', '2018/2019', 'fasdf', 'approved', '2019-01-17', 'sdsadAS', 'Prudential', 'Cheque'),
(121, '18104', 'Credit', 10, 'Second', '112.50', '2019-01-28', '1', '2018/2019', 'FKDFA;SDL', 'approved', '2019-01-25', 'KHHLKHL', 'Stanbic Bank', 'Cheque'),
(122, '18101', 'Credit', 10, 'Second', '10.00', '2019-01-29', '1', '2018/2019', 'Testpayment', 'approved', '2019-01-09', 'rqwere', 'Stanbic Bank', 'Cheque'),
(123, '18101', 'Credit', 10, 'Second', '297.00', '2019-01-29', '1', '2018/2019', 'New fees', 'approved', '2019-01-15', 'depo', 'Stanbic Bank', 'Cheque'),
(124, '18101', 'Credit', 10, 'Second', '342.00', '2019-01-29', '1', '2018/2019', 'Testpayment', 'approved', '2019-01-17', 'Tatu', 'GN Bank', 'Cash'),
(125, '18101', 'Credit', 10, 'Second', '297.00', '2019-01-29', '1', '2018/2019', 'check', '', '0000-00-00', '', '', ''),
(126, '18101', 'Credit', 10, 'Second', '297.00', '2019-01-29', '1', '2018/2019', 'Testpayment', 'approved', '2019-01-26', 'nnnnnnn', 'Stanbic Bank', 'Direct Payment'),
(127, '18101', 'Credit', 10, 'Second', '297.00', '2019-01-29', '1', '2018/2019', 'Ontest', 'approved', '2019-01-25', 'asfasdd', 'Prudential', 'Cheque'),
(128, '18101', 'Reversal', 10, 'Second', '-3761.00', '2019-01-29', '1', '2018/2019', 'freeeeee', '', '0000-00-00', '', '', ''),
(129, '18101', 'Credit', 10, 'Second', '59.00', '2019-01-29', '1', '2018/2019', 'last', 'approved', '2019-01-12', 'love', 'Prudential', 'Cash'),
(130, '18101', 'Credit', 10, 'Second', '10.00', '2019-01-29', '1', '2018/2019', 'Testpayment', 'approved', '2019-01-22', 'name', 'GN Bank', 'Cash'),
(131, '18102', 'Credit', 10, 'Second', '15.00', '2019-01-30', '1', '2018/2019', 'Testpayment', 'approved', '2019-01-16', 'Moses', 'Prudential', 'Cheque'),
(132, '18101', 'Reversal', 10, 'Second', '-12.00', '2019-01-31', '1', '2018/2019', '12', 'approved', '0000-00-00', '', '', ''),
(133, '18101', 'Reversal', 10, 'Second', '-12.00', '2019-01-31', '1', '2018/2019', '12', 'pending', '0000-00-00', '', '', ''),
(134, '18101', 'Reversal', 10, 'Second', '-123.00', '2019-01-31', '1', '2018/2019', '2234', 'pending', '0000-00-00', '', '', ''),
(135, '18101', 'Reversal', 10, 'Second', '-123.00', '2019-01-31', '1', '2018/2019', '2234', 'pending', '0000-00-00', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbllevel`
--

CREATE TABLE IF NOT EXISTS `tbllevel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `LevelName` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `tbllevel`
--

INSERT INTO `tbllevel` (`id`, `LevelName`) VALUES
(1, 'Nursery'),
(2, 'Kindergarten'),
(3, 'Upper Primary'),
(4, 'Junior High'),
(5, 'Lower Primary');

-- --------------------------------------------------------

--
-- Table structure for table `tbloptbill`
--

CREATE TABLE IF NOT EXISTS `tbloptbill` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `BillName` varchar(50) NOT NULL,
  `BillAmount` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC AUTO_INCREMENT=6 ;

--
-- Dumping data for table `tbloptbill`
--

INSERT INTO `tbloptbill` (`id`, `BillName`, `BillAmount`) VALUES
(3, 'feeding', '10.00'),
(4, 'Breakage of Chair', '45.00'),
(5, 'Damage to Computer', '250.00');

-- --------------------------------------------------------

--
-- Table structure for table `tbloptionalstudent`
--

CREATE TABLE IF NOT EXISTS `tbloptionalstudent` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stu_id` varchar(50) NOT NULL,
  `BillId` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC AUTO_INCREMENT=9 ;

--
-- Dumping data for table `tbloptionalstudent`
--

INSERT INTO `tbloptionalstudent` (`id`, `stu_id`, `BillId`) VALUES
(5, '14133', 3),
(6, '18105', 4),
(7, '18101', 3),
(8, '18104', 5);

-- --------------------------------------------------------

--
-- Table structure for table `tblpenalty`
--

CREATE TABLE IF NOT EXISTS `tblpenalty` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stu_id` varchar(50) NOT NULL,
  `Reason` varchar(300) NOT NULL,
  `Amount` decimal(10,2) NOT NULL,
  `Status` tinyint(4) NOT NULL DEFAULT '0',
  `Date` date NOT NULL,
  `BillId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Table structure for table `tblrole`
--

CREATE TABLE IF NOT EXISTS `tblrole` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `RoleName` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `tblrole`
--

INSERT INTO `tblrole` (`id`, `RoleName`) VALUES
(1, 'Administrator'),
(2, 'Teacher'),
(3, 'Cashier'),
(4, 'Parent'),
(5, 'Director');

-- --------------------------------------------------------

--
-- Table structure for table `tblscholar`
--

CREATE TABLE IF NOT EXISTS `tblscholar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stu_id` varchar(50) NOT NULL,
  `scholarId` int(11) NOT NULL,
  `scholarAmount` decimal(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `tblscholar`
--

INSERT INTO `tblscholar` (`id`, `stu_id`, `scholarId`, `scholarAmount`) VALUES
(5, '14133', 2, '0.00'),
(6, '17165', 1, '0.00'),
(8, '18101', 3, '100.00'),
(9, '18102', 3, '110.00'),
(10, '18105', 2, '0.00'),
(11, '18104', 2, '0.00');

-- --------------------------------------------------------

--
-- Table structure for table `tblscholartype`
--

CREATE TABLE IF NOT EXISTS `tblscholartype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `scholarType` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `tblscholartype`
--

INSERT INTO `tblscholartype` (`id`, `scholarType`) VALUES
(1, 'Full Scholarship'),
(2, 'Half Scholarship'),
(3, 'Other');

-- --------------------------------------------------------

--
-- Table structure for table `tblschool`
--

CREATE TABLE IF NOT EXISTS `tblschool` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `SchoolName` varchar(100) NOT NULL,
  `SchoolShortName` varchar(11) NOT NULL,
  `PostAddress` varchar(100) NOT NULL,
  `SchoolEmail` varchar(100) NOT NULL,
  `SchoolMoto` varchar(100) NOT NULL,
  `SchoolPhone` varchar(10) NOT NULL,
  `SchoolLogo` varchar(100) NOT NULL,
  `SchoolWebsite` varchar(100) NOT NULL,
  `nextterm` text NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tblschool`
--

INSERT INTO `tblschool` (`Id`, `SchoolName`, `SchoolShortName`, `PostAddress`, `SchoolEmail`, `SchoolMoto`, `SchoolPhone`, `SchoolLogo`, `SchoolWebsite`, `nextterm`) VALUES
(1, 'Fastlink Academy', 'Fastlink', 'Box 10', 'mail@fastlink.edu.gh', 'Linking the Future Through Education', '0244872634', 'schoollogo.png', 'fastlink.edu.gh', '2019-02-09T14:24');

-- --------------------------------------------------------

--
-- Table structure for table `tblsetting`
--

CREATE TABLE IF NOT EXISTS `tblsetting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Term` varchar(20) NOT NULL,
  `Year` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tblsetting`
--

INSERT INTO `tblsetting` (`id`, `Term`, `Year`) VALUES
(1, 'Second', '2018/2019');

-- --------------------------------------------------------

--
-- Table structure for table `tblstaffrole`
--

CREATE TABLE IF NOT EXISTS `tblstaffrole` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `RoleId` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `tblstaffrole`
--

INSERT INTO `tblstaffrole` (`id`, `username`, `RoleId`) VALUES
(1, 'jsadongu', 1),
(2, 'iopei', 2),
(3, 'mawakere', 3),
(4, 'STF0012', 5),
(5, 'tmabakwile', 1),
(11, 'nathan', 3),
(12, 'Kaykay', 1),
(13, 'jsadongu', 2),
(14, 'tmabakwile', 5);

-- --------------------------------------------------------

--
-- Table structure for table `tblsubcombination`
--

CREATE TABLE IF NOT EXISTS `tblsubcombination` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `SubjectId` int(11) NOT NULL,
  `Classid` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fksub001` (`SubjectId`),
  KEY `fkcla001` (`Classid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=120 ;

--
-- Dumping data for table `tblsubcombination`
--

INSERT INTO `tblsubcombination` (`id`, `SubjectId`, `Classid`) VALUES
(1, 3, 13),
(2, 4, 13),
(3, 5, 13),
(4, 6, 13),
(5, 9, 13),
(6, 3, 14),
(7, 4, 14),
(8, 5, 14),
(9, 6, 14),
(10, 7, 14),
(11, 9, 14),
(12, 8, 14),
(13, 3, 10),
(14, 4, 10),
(15, 5, 10),
(16, 6, 10),
(17, 7, 10),
(18, 3, 11),
(19, 4, 11),
(20, 5, 11),
(21, 6, 11),
(22, 7, 11),
(23, 1, 1),
(24, 5, 1),
(25, 8, 1),
(26, 9, 1),
(27, 10, 1),
(28, 11, 1),
(29, 12, 1),
(30, 13, 1),
(31, 1, 2),
(32, 5, 2),
(33, 8, 2),
(34, 9, 2),
(35, 10, 2),
(36, 12, 2),
(37, 13, 2),
(38, 1, 3),
(39, 5, 3),
(40, 8, 3),
(41, 9, 3),
(42, 10, 3),
(43, 11, 3),
(44, 12, 3),
(45, 13, 3),
(46, 1, 4),
(47, 5, 4),
(48, 16, 4),
(49, 9, 4),
(50, 10, 4),
(51, 11, 4),
(52, 12, 4),
(53, 14, 4),
(54, 13, 4),
(55, 1, 5),
(56, 5, 5),
(57, 16, 5),
(58, 9, 5),
(59, 10, 5),
(60, 11, 5),
(61, 12, 5),
(62, 14, 5),
(63, 13, 5),
(64, 1, 6),
(65, 5, 6),
(66, 16, 6),
(67, 9, 6),
(68, 10, 6),
(69, 11, 6),
(70, 12, 6),
(71, 13, 6),
(72, 14, 6),
(73, 1, 7),
(74, 5, 7),
(75, 16, 7),
(76, 9, 7),
(77, 10, 7),
(78, 11, 7),
(79, 12, 7),
(80, 15, 7),
(81, 17, 7),
(82, 1, 8),
(83, 5, 8),
(84, 16, 8),
(85, 9, 8),
(86, 10, 8),
(87, 11, 8),
(88, 12, 8),
(89, 15, 8),
(90, 17, 8),
(91, 1, 9),
(92, 5, 9),
(93, 16, 9),
(94, 9, 9),
(95, 10, 9),
(96, 11, 9),
(97, 12, 9),
(98, 15, 9),
(99, 17, 9),
(100, 3, 17),
(101, 4, 17),
(102, 5, 17),
(103, 6, 17),
(104, 7, 17),
(105, 3, 18),
(106, 4, 18),
(107, 5, 18),
(108, 6, 18),
(109, 7, 18),
(110, 16, 1),
(111, 1, 22),
(112, 1, 23),
(113, 5, 22),
(114, 5, 23),
(115, 2, 10),
(116, 2, 20),
(117, 2, 21),
(118, 2, 11),
(119, 19, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblsubject`
--

CREATE TABLE IF NOT EXISTS `tblsubject` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `SubjectName` varchar(100) NOT NULL,
  `ShortName` varchar(10) DEFAULT NULL,
  `Status` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- Dumping data for table `tblsubject`
--

INSERT INTO `tblsubject` (`id`, `SubjectName`, `ShortName`, `Status`) VALUES
(1, 'ENGLISH LANGUAGE ', 'ENG.', 0),
(2, 'MUSIC & MOVEMENT ', 'MUS & MOV', 1),
(3, 'LANGUAGE & LITERACY', 'LANG & LIT', 0),
(4, 'ENVIRONMENTAL STUDIES', 'ENVI`TAL', 1),
(5, 'MATHEMATICS ', 'MATHS', 0),
(7, 'CREATIVE ACTIVITIES', 'CRE. ACT', 1),
(8, 'NATURAL SCIENCE', 'N SCIEN', 0),
(9, 'INFORMATION & COM TECH', 'ICT', 1),
(10, 'RELIGIOUS & MORAL EDUCATION ', 'RME', 1),
(11, 'FRENCH', 'FRENCH', 1),
(12, 'KASEM', 'KASEM', 1),
(13, 'CREATIVE ART', 'CRE. ART', 1),
(14, 'CITIZENSHIP', 'CIT`SHIP', 1),
(15, 'SOCIAL STUDIES', 'SOCIAL', 0),
(16, 'INTEGRATED  SCIENCE', 'SCIEN', 0),
(17, 'BASIC DESIGN & TECHNOLOGY ', 'BDT', 1),
(19, 'Latin', 'lat', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbltermlyfee`
--

CREATE TABLE IF NOT EXISTS `tbltermlyfee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stu_id` int(11) NOT NULL,
  `term` varchar(10) NOT NULL,
  `acyear` varchar(25) NOT NULL,
  `termlyfee` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `tbltermlyfee`
--

INSERT INTO `tbltermlyfee` (`id`, `stu_id`, `term`, `acyear`, `termlyfee`) VALUES
(6, 14133, 'First', '2018/2019', '150.00'),
(7, 17102, 'First', '2018/2019', '310.00'),
(8, 17101, 'First', '2018/2019', '310.00'),
(9, 18101, 'First', '2018/2019', '310.00'),
(10, 18102, 'First', '2018/2019', '200.00'),
(11, 18103, 'First', '2018/2019', '310.00'),
(12, 18105, 'First', '2018/2019', '265.00'),
(13, 16101, 'First', '2018/2019', '310.00'),
(14, 15101, 'First', '2018/2019', '310.00'),
(15, 8101, 'First', '2018/2019', '910.00'),
(16, 17105, 'First', '2018/2019', '310.00'),
(17, 18101, 'Second', '2018/2019', '359.00'),
(18, 18102, 'Second', '2018/2019', '-35.00'),
(19, 13101, 'Second', '2018/2019', '200.00'),
(20, 18103, 'Second', '2018/2019', '483.00'),
(21, 18135, 'Second', '2018/2019', '175.00'),
(22, 14133, 'Second', '2018/2019', '112.50'),
(23, 17102, 'Second', '2018/2019', '75.00'),
(24, 18104, 'Second', '2018/2019', '212.50'),
(25, 18105, 'Second', '2018/2019', '110.00');

-- --------------------------------------------------------

--
-- Table structure for table `tblyearlybill`
--

CREATE TABLE IF NOT EXISTS `tblyearlybill` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `BillName` varchar(50) NOT NULL,
  `BillAmount` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tblyearlybill`
--

INSERT INTO `tblyearlybill` (`id`, `BillName`, `BillAmount`) VALUES
(2, 'school fees', '310.00');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `gender` varchar(10) NOT NULL DEFAULT 'Male',
  `password` varchar(150) NOT NULL,
  `contact` decimal(10,0) NOT NULL,
  `type` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `photo` varchar(1000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `name`, `gender`, `password`, `contact`, `type`, `email`, `photo`) VALUES
(1, 'kasuli', 'Lateef Knight Rider', 'Male', 'kasuli', '249361597', 'Super Admin', 'admin@kasuli.com', 'kasuli.png');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
