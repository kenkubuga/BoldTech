		<?php
session_start();
error_reporting(0);
include('includes/config.php');
			//$cid=intval($_GET['aid']);
			$cid=intval($_GET['id']);
			$sid=intval($_GET['sid']);
			$samount=intval($_GET['samount']);
			$dat= date('Y/m/d');
			$status = 'approved';
			$sql="UPDATE tblfeepayment
			SET status = :st WHERE id=:cid ";
			$query = $dbh->prepare($sql);
			$query->bindParam(':cid',$cid,PDO::PARAM_STR);
			$query->bindParam(':st',$status,PDO::PARAM_STR);
			$query->execute();
			
			$fee=($samount*(-1));
			$bal=ArrearsAmount1($sid);
			$mainbal = $bal + $fee;
			Update_Arrears($sid,$mainbal,$dat);
			echo "<script> location.href='http://smis.fastlink.edu.gh/approve_reversal.php'; </script>";
			exit();
		?>