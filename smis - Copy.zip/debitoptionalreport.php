<?php
session_start();
error_reporting(0);
include('includes/config.php');
$term=CurrentTerm();
$acyr=CurrentACYear();
$rdate = date("d-M-Y");
DEFINE('BASENAMESS',basename(__FILE__));
if(strlen($_SESSION['alogin'])=="")
    {   
    header("Location: index.php"); 
    }
    else{
?>
<!DOCTYPE html>
<head>
<title><?php echo(isset(School()->SchoolName))? School()->SchoolName:"SMS"; ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Kasuli A-L Hotel Management System, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- bootstrap-css -->
<link rel="stylesheet" type="text/css" href="js/DataTables/datatables.min.css"/>
<link rel="stylesheet" href="css/bootstrap.min.css" >
<!-- //bootstrap-css -->
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href="css/style-responsive.css" rel="stylesheet"/>
<!-- font CSS -->
<link href='//fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
<!-- font-awesome icons -->
<link rel="stylesheet" href="css/kas.css" type="text/css"/>
<link rel="stylesheet" href="css/font.css" type="text/css"/>
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons -->
<script src="js/jquery2.0.3.min.js"></script>
<link href="src/jquery.bootstrap-touchspin.css" rel="stylesheet" type="text/css" media="all">
<script src="src/jquery.bootstrap-touchspin.js"></script>
</head>
<body>


<section id="container">
<!--header start-->
<?php include('includes/topbar.php');?>
<!--header end-->
<!--sidebar start-->
<?php include('includes/sidebar.php');?>
<!--sidebar end-->
<!--main content start-->
<section id="main-content">
	<section class="wrapper">
		<div class="form-w3layouts">
            <!-- page start-->

            <div class="row">
                
    <div class="col-lg-12"> <section class="panel"> <header class="panel-heading"> 
      Debit History as of 
      <?php echo $rdate; ?>
	  <?php echo $acyr ;?>
      </header> 
      
      <div class="panel-body"> 
        <table id="example" class="gridtable" cellspacing="0" width="100%">
          <thead>
            <tr> 
              <th>#</th>
              <th>Student ID</th>
              <th>FullName</th>
              <th>Class</th>
              <th>Term</th>
              <th>Year</th>
			  <th>Description</th>
			  <th>Amount</th>
			  <th>Balance Before</th>
			  
			  <th>Balance After</th>
              
              
            </tr>
          </thead></thead>
          <tbody>
            <?php $sql = "SELECT
				optionalfees.stu_id,
				optionalfees.term,
				optionalfees.acyear,
				optionalfees.balbefore,
				optionalfees.amount,
				optionalfees.billdesc,
				optionalfees.class_id,
				optionalfees.level,
				optionalfees.balafter
				
				FROM
				optionalfees
				";
				$query = $dbh->prepare($sql);
				$query->execute();
				$results=$query->fetchAll(PDO::FETCH_OBJ);
				$totPrevBal = 0;
				$totPayable = 0;
				$totPaid = 0;
				$totBal = 0;
				$cnt=1;
				if($query->rowCount() > 0)
				{
				foreach($results as $result)
				{ 
				$totalfee = $result->class_total_fee;  
            $indexno = htmlentities($result->stu_id);
			      //echo $indexno;
				
			
			
			
			?>
            <tr> 
              <td align="center"> 
                <?php echo htmlentities($cnt);?>
              </td>
              <td align="center"> 
                <?php echo htmlentities($result->stu_id);?>
              </td>
			  <td align="center"> 
                <?php echo htmlentities(GetStudentName($result->stu_id));?>
              </td>
			  
              <td align="left"> 
                <?php echo htmlentities(StudentClass($result->class_id));?>
              </td>
              <td align="left"> 
                <?php echo htmlentities($result->term);?>
              </td>
              <td align="center"> 
                <?php echo htmlentities($result->acyear);?>
              </td>
              
			  <td align="center"> 
			  
                <?php echo htmlentities($result->billdesc); ?>
              </td>
			  <td align="center"> 
			  <?php echo htmlentities($result->amount); ?>
                
              </td> 
			  
              <td align="center"> 
                <?php echo htmlentities($result->balbefore); 
				$totPayable = $totPayable + $currArrears;
					?>
              </td> 
              <td align="center"> 
                <?php echo htmlentities($result->balafter); ?>
              </td>
               
            </tr>
			
				<?php $cnt=$cnt+1;}}
				//}?>
			
          </tbody>
        </table>
      </div>
      </section> </div>
</div>
<!-- page end-->
</div>
</section>

















<!-- footer -->
<?php include('includes/footer.php');?>
  <!-- / footer -->
</section>
<!--main content end-->
</section>
<script src="js/bootstrap.js"></script>
<script src="js/jquery.dcjqaccordion.2.7.js"></script>
<script src="js/scripts.js"></script>
<script src="js/jquery.slimscroll.js"></script>
<script src="js/jquery.nicescroll.js"></script>
<!--[if lte IE 8]><script language="javascript" type="text/javascript" src="js/flot-chart/excanvas.min.js"></script><![endif]-->
<script src="js/jquery.scrollTo.js"></script>
<script src="js/DataTables/datatables.min.js"></script>
<script>
	$(function($) {
		$('#example').DataTable({

			dom: 'Bfrtip',
			buttons: [
				'excelHtml5',
				'csvHtml5',
				'pdfHtml5'
			],

			"pager": 150,
			"pageLength" : 100
			
		});
	});
</script>
</body>
</html>
<?php }?>