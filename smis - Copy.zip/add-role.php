<?php
session_start();
error_reporting(0);
DEFINE('BASENAMESS',basename(__FILE__));
include('includes/config.php');
if(strlen($_SESSION['alogin'])=="")
    {   
    header("Location: index.php"); 
	}else{
		if(isset($_POST['submit']))
		{
		    try{
		$username=$_POST['username'];
		$role=$_POST['role']; 
			if(Assignrole_exist($username,$role)===false)
			{
			
                  $sql = "UPDATE tblstaffrole SET RoleId=? WHERE username=?";
$q = $dbh->prepare($sql);
$q->execute(array($role,$username));
	
				if($q)
				{
					$msg="User role updated successfully";
				}
				else 
				{
					$error="Something went wrong. Please try again";
				}
			}else
			{
				$error = "Role already assigned to the selected staff";
			}
		}
catch (exception $e) {
    echo $e;
    //echo $e->getMessage();
}	
catch (InvalidArgumentException $e) {
    echo $e;
    //echo $e->getMessage();
}
		}
?>
<!DOCTYPE html>
<head>
<title><?php echo(isset(School()->SchoolName))? School()->SchoolName:"SMS"; ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Kasuli A-L Hotel Management System, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- bootstrap-css -->
<link rel="stylesheet" href="css/bootstrap.min.css" >
<!-- //bootstrap-css -->
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href="css/style-responsive.css" rel="stylesheet"/>
<!-- font CSS -->
<link href='//fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
<!-- font-awesome icons -->
<link rel="stylesheet" href="css/font.css" type="text/css"/>
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons -->
<script src="js/jquery2.0.3.min.js"></script>
  <link href="src/jquery.bootstrap-touchspin.css" rel="stylesheet" type="text/css" media="all">
  <script src="src/jquery.bootstrap-touchspin.js"></script>
        <script>
		function getSubject(val,cid) {
		var cid=$(".cid").val();
		var val=$(".subid").val();;
		var abh=val+'$'+cid;
		//alert(abh);
			$.ajax({
			type: "POST",
			url: "get_subject.php",
			data:'subjectid='+abh,
			success: function(data){
				$("#reslt").html(data);   
			}
			});
		}
		</script>
</head>
<body>
<section id="container">
<!--header start-->
<?php include('includes/topbar.php');?>
<!--header end-->
<!--sidebar start-->
<?php include('includes/sidebar.php');?>
<!--sidebar end-->
<!--main content start-->
<section id="main-content">
	<section class="wrapper">
		<div class="form-w3layouts">
            <!-- page start-->
            <div class="row">
                <div class="col-lg-12">
                    <section class="panel">
                        <header class="panel-heading">
                            Assign Roles
                        </header>
                        <div class="panel-body">
<?php if($msg){?>
<div class="alert alert-success left-icon-alert" role="alert">
 <strong>Well done! </strong><?php echo htmlentities($msg); ?>
 </div><?php } 
else if($error){?>
    <div class="alert alert-danger left-icon-alert" role="alert">
	<strong>Sorry! </strong> <?php echo htmlentities($error); ?>
</div>
<?php } ?>
<form class="form-horizontal" method="post" enctype="multipart/form-data">
<div class="form-group">
	<label for="default" class="col-sm-2 control-label">Staff</label>
	<div class="col-sm-6">
 <select name="username" class="form-control cid select2" id="default" required="required">
<option value="">Select Staff</option>
<?php $sql = "SELECT
			staff.username,
			staff.fullname
			FROM
			staff
			WHERE
			staff.role <> 4";
$query = $dbh->prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
if($query->rowCount() > 0)
{
foreach($results as $result)
{   ?>
<option value="<?php echo htmlentities($result->username); ?>"><?php echo htmlentities($result->fullname); ?></option>
<?php }} ?>
 </select>
</div>
</div>
<div class="form-group">
<label for="default" class="col-sm-2 control-label">Role</label>
<div class="col-sm-6">
 <select name="role" class="form-control subid select2" id="default" required="required">
<option value="">Select Role</option>
<?php $sql = "SELECT tblrole.id, tblrole.RoleName FROM tblrole WHERE tblrole.id <> 4";
$query = $dbh->prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
if($query->rowCount() > 0)
{
foreach($results as $result)
{   ?>
<option value="<?php echo htmlentities($result->id); ?>"><?php echo htmlentities($result->RoleName); ?></option>
<?php }} ?>
 </select>
		</div>
	</div>
	
	<div class="form-group">
		<div class="col-sm-offset-2 col-sm-10">
			<button type="submit" name="submit" id="submit" class="btn btn-primary btn-labeled">Save <span class="btn-label btn-label-right"><i class="fa fa-save"></i></span></button>
		</div>
	</div> 
</form>
			</div>
		</section>
	</div>
</div>
<!-- page end-->
</div>
</section>
<!-- footer -->
<?php include('includes/footer.php');?>
  <!-- / footer -->
</section>
<!--main content end-->
</section>
<script src="js/bootstrap.js"></script>
<script src="js/jquery.dcjqaccordion.2.7.js"></script>
<script src="js/scripts.js"></script>
<script src="js/jquery.slimscroll.js"></script>
<script src="js/jquery.nicescroll.js"></script>
<script src="js/jquery.scrollTo.js"></script>
</body>
</html>
<?php }?>