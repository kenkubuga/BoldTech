<?php
if(isset($_POST['sendmessage'])){

//$username = "boldfast";
//$sourceAddress = "FastLink";
$shortMessage = $_POST["comment"];
//$sMessage = preg_replace('/\s+/', '%20', $shortMessage);
//$apikey = "fX9uSP8GMme6VUQdHJLzYnrKFZsWT017O2E5xwphIqtvAoc43g";
$destinationAddress = $_POST["destinationAddress"];


//$shortMessage =$_POST['shortMessage'];
//$sMessage = preg_replace('/\s+/', '%20', $shortMessage);
$senderid = 'FastLink'; 

$destswithspace = $_POST['destinationAddress'];

//Stripped it of space
$destinationAddress = preg_replace('/\s/', '', $destswithspace);
$destinationAddress = str_replace("+", "", $destinationAddress);
$destinationAddress = str_replace("-", "", $destinationAddress);

$destinationAddress = str_replace("/", ",", $destinationAddress);

// Explode to an array
$destinationAddressArray = explode (",", $destinationAddress);


//remove duplicates
$destinationAddressArray = array_unique($destinationAddressArray);
 $newDestArray = array_filter($destinationAddressArray, function($k) {
    return $k != '';
});

//SEND SMS V2
$curl = curl_init();
curl_setopt_array($curl, [
    CURLOPT_URL => 'https://sms.arkesel.com/api/v2/sms/send',
    CURLOPT_HTTPHEADER => ['api-key: OmJHV0R6SGNDTEFGckt2NGI='],
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => '',
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => 'POST',
    CURLOPT_POSTFIELDS => http_build_query([
        'sender' => $senderid,
        'message' => $shortMessage,
        'recipients' => $newDestArray
    ]),
]);

$response = curl_exec($curl);
curl_close($curl);
$bal=json_decode($response,true);
$resp=$bal['status'];

// SEND SMS

header("location:smsparentpro.php?msgark=".$resp); 
//	echo "<script type='text/javascript'> document.location = 'smsparentpro.php?errmsg=success'; </script>";
}
?>