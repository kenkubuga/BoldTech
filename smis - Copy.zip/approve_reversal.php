<?php
session_start();
error_reporting(0);
include('includes/config.php');
DEFINE('BASENAMESS',basename(__FILE__));
if(strlen($_SESSION['alogin'])=="")
    {   
    header("Location: index.php"); 
    }
    else{
?>
<!DOCTYPE html>
<head>
<title><?php echo(isset(School()->SchoolName))? School()->SchoolName:"SMS"; ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Kasuli A-L Hotel Management System, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- bootstrap-css -->
<link rel="stylesheet" type="text/css" href="js/DataTables/datatables.min.css"/>
<link rel="stylesheet" href="css/bootstrap.min.css" >
<!-- //bootstrap-css -->
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href="css/style-responsive.css" rel="stylesheet"/>
<!-- font CSS -->
<link href='//fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
<!-- font-awesome icons -->
<link rel="stylesheet" href="css/kas.css" type="text/css"/>
<link rel="stylesheet" href="css/font.css" type="text/css"/>
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons -->
<script src="js/jquery2.0.3.min.js"></script>
<link href="src/jquery.bootstrap-touchspin.css" rel="stylesheet" type="text/css" media="all">
<script src="src/jquery.bootstrap-touchspin.js"></script>
</head>
<body>
<section id="container">
<!--header start-->
<?php include('includes/topbar.php');?>
<!--header end-->
<!--sidebar start-->
<?php include('includes/sidebar.php');?>
<!--sidebar end-->
<!--main content start-->
<section id="main-content">
	<section class="wrapper">
		<div class="form-w3layouts">
            <!-- page start-->
            <div class="row">
                
    <div class="col-lg-12"> <section class="panel"> <header class="panel-heading"> 
      Manage Payment Reversal </header> 
      <div class="panel-body"> 
        <?php if($msg){?>
        <div class="alert alert-success left-icon-alert" role="alert"> <strong>Well 
          done! </strong>
          <?php echo htmlentities($msg); ?>
        </div>
        <?php } 
else if($error){?>
        <div class="alert alert-danger left-icon-alert" role="alert"> <strong>Oh 
          snap! </strong> 
          <?php echo htmlentities($error); ?>
        </div>
        <?php } ?>
        <table id="example" class="gridtable" cellspacing="0" width="100%">
          <thead>
            <tr> 
              <th>#</th>
              <th>Full Name</th>
              <th>Term</th>
              <th>Amount</th>
              <th>Cashier</th>
              <th>Date</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <?php $sql = "SELECT tblfeepayment.id,tblfeepayment.stu_id, tblfeepayment.transtype, tblfeepayment.classid, tblfeepayment.term, tblfeepayment.amount, tblfeepayment.Rdate, tblfeepayment.cashier,tblfeepayment.status FROM tblfeepayment WHERE tblfeepayment.status = 'pending'";
$query = $dbh->prepare($sql);
//$query->bindParam('d','pending');
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{ $sid = $result->staff_id; ?>
            <tr class="record"> 
              <td>
                <?php echo htmlentities($cnt);?>
              </td>
              <td>
                <?php echo htmlentities(GetStudentName($result->stu_id));?>
              </td>
              <td>
                <?php echo htmlentities($result->term);?>
              </td>
              <td>
                <?php echo htmlentities($result->amount);?>
              </td>
              <td>
                <?php echo htmlentities(GetCashierName($result->cashier));?>
              </td>
              <td>
                <?php echo htmlentities($result->Rdate);?>
              </td>
              <td><span class="label label-danger">
                <?php echo htmlentities($result->status);?>
                </span></td>
              <td> <?php
echo "<a href='app_resersal.php?id=".$result->id."&sid=".$result->stu_id."&samount=".$result->amount."' onClick=\"javascript:return confirm('Are you sure you want to approve this reversal? It cannot be undone!');\"><button class='btn btn-warning btn-sm btn-labeled pull-right'><i style='font-size:15px;color:white' title='Approve Reversal'></i> Approve </button></a>";

?> 
</td>
            </tr>
            <?php $cnt=$cnt+1;}} ?>
          </tbody>
        </table>
      </div>
      </section> </div>
</div>
<!-- page end-->
</div>
</section>
<!-- footer -->
<?php include('includes/footer.php');?>
  <!-- / footer -->
</section>
<!--main content end-->
</section>
<script src="js/bootstrap.js"></script>
<script src="js/jquery.dcjqaccordion.2.7.js"></script>
<script src="js/scripts.js"></script>
<script src="js/jquery.slimscroll.js"></script>
<script src="js/jquery.nicescroll.js"></script>
<!--[if lte IE 8]><script language="javascript" type="text/javascript" src="js/flot-chart/excanvas.min.js"></script><![endif]-->
<script src="js/jquery.scrollTo.js"></script>
<script type="text/javascript">
$(function() {
$(".aid").click(function(){
var element = $(this);
var a_id = element.attr("id");
var data = 'aid=' + a_id;
 if(confirm("Are you sure you want to approve this reversal? It cannot be undone!"))
		  {

 $.ajax({
   type: "GET",
   url: "app_resersal.php",
   data: data,
   success: function(){ 
   
   }
 });
 $(this).parents(".record").animate({ backgroundColor: "#fbc7c7" }, "fast")
.animate({ opacity: "hide" }, "slow");
 }

return false;

});

});
</script>
<script src="js/DataTables/datatables.min.js"></script>
<script>
	$(function($) {
		$('#example').DataTable();

		$('#example2').DataTable( {
			"scrollY":        "300px",
			"scrollCollapse": true,
			"paging":         false
		} );

		$('#example3').DataTable();
	});
</script>
</body>
</html>
<?php }?>