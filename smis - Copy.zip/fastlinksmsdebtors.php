<?php
if(isset($_POST['sendmessage'])){

$username = "boldfast";
$sourceAddress = "FastLink";
$shortMessage = $_POST["comment"];
$apikey = "fX9uSP8GMme6VUQdHJLzYnrKFZsWT017O2E5xwphIqtvAoc43g";
$destinationAddress = $_POST["destinationAddress"];
$messageDescription = "default";
$messageType = "quick";

//The JSON data for each message
$jsonData= array(

    'username' =>  $username,
    
    'sourceAddress' =>  $sourceAddress,
    'shortMessage' =>  $shortMessage,
     'apikey' =>  $apikey,
    'destinationAddress' =>  $destinationAddress,
    'messageDescription' =>  $messageDescription,
    'messageType' => $messageType
);
//API Url
$url = 'https://boldsms.com/smssendingscript.php';

//Initiate cURL.
$ch = curl_init($url);


//Encode the array into JSON.
$jsonDataEncoded = json_encode($jsonData);

//Tell cURL that we want to send a POST request.
curl_setopt($ch, CURLOPT_POST, 1);

//Attach our encoded JSON string to the POST fields.
curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonDataEncoded);

//Set the content type to application/json
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'


)); 
  curl_setopt($ch, CURLOPT_TIMEOUT, 4); 
    curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch,  CURLOPT_RETURNTRANSFER, true);
   curl_setopt($ch, CURLOPT_FORBID_REUSE, true);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 1);
    curl_setopt($ch, CURLOPT_DNS_CACHE_TIMEOUT, 10); 

    curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);

//Execute the request
 
 
 curl_exec($ch);
curl_close($ch);
echo "<script type='text/javascript'> document.location = 'smsdebtors1.php?errmsg=success'; </script>";
}