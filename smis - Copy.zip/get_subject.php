<?php
include('includes/config.php');
/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
if(!empty($_POST["classid100"])) 
{
 $id= $_POST['classid100'];
 $dta=explode("$",$id);
$username1=$dta[0];
$cid=$dta[1];	
 $sql = "SELECT 
tblclassubject.ClassId,
tblclassubject.SubjectId,
tblsubjects.SubjectName
FROM
tblclassubject
INNER JOIN tblsubjects ON tblclassubject.SubjectId = tblsubjects.id
WHERE
tblclassubject.ClassId = :cid AND
tblclassubject.StaffId = :stts";
$query = $dbh->prepare($sql);
$query-> bindParam(':cid',$cid, PDO::PARAM_STR);
$query-> bindParam(':stts',$username1, PDO::PARAM_STR);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
if($query->rowCount() > 0)
{
	 ?><option value="">Select Subject</option><?php
foreach($results as $result)
{   ?>
<option value="<?php echo htmlentities($result->SubjectId); ?>"><?php echo htmlentities($result->SubjectName); ?></option>
<?php }
}
}
/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
if(!empty($_POST["classid"])) 
{
 $cid=intval($_POST['classid']);
 if(!is_numeric($cid)){
 
 	echo htmlentities("invalid Class");exit;
 }
 else{
 $status=0;	
 $stmt = $dbh->prepare("SELECT tblsubjects.SubjectName,tblsubjects.id FROM tblsubjectcombination join  tblsubjects on  tblsubjects.id=tblsubjectcombination.SubjectId WHERE tblsubjectcombination.ClassId=:cid and tblsubjectcombination.status!=:stts order by tblsubjects.SubjectName");
 $stmt->execute(array(':cid' => $cid,':stts' => $status));
 ?><option value="">Select Subject</option><?php
 while($row=$stmt->fetch(PDO::FETCH_ASSOC))
 {
  ?>
  <option value="<?php echo htmlentities($row['id']); ?>"><?php echo htmlentities($row['SubjectName']); ?></option>
  <?php
 }
}}
/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
if(!empty($_POST["studclass"])) 
{
 $id= $_POST['studclass'];
 $dta=explode("$",$id);
$cid=$dta[0];
$sid=$dta[1];
$yer=$dta[2];
$ter=$dta[3];
$ay=$dta[4];
$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
 $query = $dbh->prepare("SELECT
tblresult.yearLvl,
tblresult.Term,
tblresult.ClassId,
tblresult.SubjectId,
tblresult.acyear
FROM
tblresult
WHERE
tblresult.yearLvl = :yr AND
tblresult.Term = :ter AND
tblresult.ClassId = :cid AND
tblresult.SubjectId = :sid AND
tblresult.acyear = :ay");
//$query= $dbh -> prepare($sql);
//print_r($data);
$query-> bindParam(':cid', $cid, PDO::PARAM_STR);
$query-> bindParam(':sid', $sid, PDO::PARAM_STR);
$query-> bindParam(':yr', $yer, PDO::PARAM_STR);
$query-> bindParam(':ter', $ter, PDO::PARAM_STR);
$query-> bindParam(':ay', $ay, PDO::PARAM_STR);
$query-> execute();
$results = $query -> fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query -> rowCount() > 0)
{ 
?>
<p>
<?php
echo "<span style='color:red'> Results Already Published .</span>";
 echo "<script>$('#submit').prop('disabled',true);</script>";
 echo "<script>$('#csv_file').prop('disabled',true);</script>";
 ?></p>
<?php }else{
?>
<p>
<?php
 echo "<script>$('#submit').prop('disabled',false);</script>";
 echo "<script>$('#csv_file').prop('disabled',false);</script>";
 ?></p>
 <?php
}
}
/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
if(!empty($_POST["examatt"])) 
{
	$id= $_POST['examatt'];
	$dta=explode("$",$id);
	$cid=$dta[0];
	$sid=$dta[1];
	$yer=$dta[2];
	$ter=$dta[3];
	if(!empty($cid) && !empty($ter) && !empty($yer) && !empty($sid))
	{
		$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$query = $dbh->prepare("SELECT
		tblstudents.StudentName,
		tblstudents.IndexNo
		FROM
		tblstudents
		WHERE
		tblstudents.ClassId = :cid
		ORDER BY
		tblstudents.StudentName ASC");
		$query-> bindParam(':cid', $cid, PDO::PARAM_STR);
		$query-> execute();
		$results = $query -> fetchAll(PDO::FETCH_OBJ);
		$cnt=1;
		if($query -> rowCount() > 0)
		{ 
			$b="SELECT
				tblprogram.ProgramName,
				tblsubjects.SubjectName,
				tblstaff.StaffName,
				tblclasses.yearLvl,
				tblclasses.Section
				FROM
				tblclasses
				INNER JOIN tblclassubject ON tblclassubject.ClassId = tblclasses.id
				INNER JOIN tblstaff ON tblstaff.StaffId = tblclassubject.StaffId
				INNER JOIN tblsubjects ON tblsubjects.id = tblclassubject.SubjectId
				INNER JOIN tblprogram ON tblprogram.id = tblclasses.ProgrammmeId
				WHERE
				tblclassubject.ClassId = :cid AND
				tblclassubject.SubjectId = :sid
				LIMIT 1";
			$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			$stmts = $dbh->prepare($b);
			$stmts-> bindParam(':cid', $cid, PDO::PARAM_INT);
			$stmts-> bindParam(':sid', $sid, PDO::PARAM_INT);
			$stmts-> execute();
			$stmt = $stmts -> fetchAll(PDO::FETCH_OBJ);
			if($stmts -> rowCount() > 0)
			{
				foreach($stmt as $stm)
				{
					$classname=$stm->ProgramName." ".$stm->yearLvl.$stm->Section;
				}
			}
			?>
			<div class="col-ms-offset-2 col-ms-10">                                                           
				<button class="btn btn-success btn-labeled pull-right" onclick="PrintDiv('result')">Print<span class="btn-label btn-label-right"><i class="fa fa-print"></i></span></button>
			</div>
			<div id="result">
			<h3 align="center"><?php echo(isset(School()->SchoolName))? School()->SchoolName:"SMS"; ?></h3>
			<h3 align="center">EXAM ATTENDANCE LIST</h3><br>
			<table cellspacing="0" width="100%">
				<tr height="10px">
					<td valign="bottom">
						<b>SUBJECT: <?php echo(isset($stm->SubjectName))? $stm->SubjectName:"..............................."; ?></b>
					</td>
					<td valign="center">
						<b>CLASS: <?php echo(isset($classname))? $classname:ClassName($cid); ?></b>
					</td>
					<td valign="center">
						<b>TERM:<?php echo " ".$ter;?></b>
					</td>
				</tr>
				<tr>
					<td colspan="3">.</td>
				</tr>
				<tr>
					<td valign="bottom" colspan="2">
						<b>SUBJECT TEACHER: <?php echo(isset($stm->StaffName))? $stm->StaffName:"............................................."; ?></b>
					</td>
					<td valign="bottom">
						<b>INVIGILATOR:........................................</b>
					</td>
				</tr>
			</table><br>
			<table class="gridtable" cellspacing="0" width="100%">
			<thead>
				<tr>
					<th>#</th>
					<th>Sch. Num.</th>
					<th>Name</th>
					<th>C.Score(100%)</th>
					<th>E.Score(100%)</th>
					<th>Student Signature</th>
				</tr>
			</thead>
			<tbody>
			<?php 
			foreach($results as $result)
			{
				?>
				<tr>
				<td><?php echo htmlentities($cnt);?></td>
				<td><?php echo htmlentities($result->StudentName);?></td>
				<td><?php echo htmlentities($result->IndexNo);?></td>
				<td></td>
				<td></td>
				<td></td>
				</tr>
				<?php
				$cnt++;
			}?>
			</tbody>
			</table>
			</div>
			<?php
		}else{
			?>
			<div class="form-group">
			  <label for="date" class="col-sm-3 control-label "></label>
				<div class="col-sm-8">
					<div  id="reslt">
					<span style='color:red'> No students in the selected</span>
					</div>
				</div>
			</div>
			 <?php
		}
	}
}
  /*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
if(!empty($_POST["subjectid"])) 
{
 $id= $_POST['subjectid'];
 $dta=explode("$",$id);
$cid=$dta[1];
$sid=$dta[0];
$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
 $query = $dbh->prepare("SELECT
tblsubjectcombination.ClassId,
tblsubjectcombination.SubjectId
FROM
tblsubjectcombination
WHERE
tblsubjectcombination.ClassId = :cid AND
tblsubjectcombination.SubjectId = :sid");
//$query= $dbh -> prepare($sql);
//print_r($data);
$query-> bindParam(':cid', $cid, PDO::PARAM_STR);
$query-> bindParam(':sid', $sid, PDO::PARAM_STR);
$query-> execute();
$results = $query -> fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query -> rowCount() > 0)
{ 
?>
<p>
<?php
echo "<span style='color:red'> The subject is already assigned to the class .</span>";
 echo "<script>$('#submit').prop('disabled',true);</script>";
 ?></p>
<?php }else{
	?>
<p>
<?php
 echo "<script>$('#submit').prop('disabled',false);</script>";
 ?></p>
<?php
}
  }
/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
  if(!empty($_POST["studclass11"])) 
{
 $id= $_POST['studclass11'];
 $dta=explode("$",$id);
$cid=$dta[0];
$sid=$dta[1];
$yer=GetYear($cid);
$ter=$dta[2];
$ay=$dta[3];
$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
 $query = $dbh->prepare("SELECT
tblresult.yearLvl,
tblresult.Term,
tblresult.ClassId,
tblresult.SubjectId,
tblresult.acyear
FROM
tblresult
WHERE
tblresult.yearLvl = :yr AND
tblresult.Term = :ter AND
tblresult.ClassId = :cid AND
tblresult.SubjectId = :sid AND
tblresult.acyear = :ay");
//$query= $dbh -> prepare($sql);
//print_r($data);
$query-> bindParam(':cid', $cid, PDO::PARAM_STR);
$query-> bindParam(':sid', $sid, PDO::PARAM_STR);
$query-> bindParam(':yr', $yer, PDO::PARAM_STR);
$query-> bindParam(':ter', $ter, PDO::PARAM_STR);
$query-> bindParam(':ay', $ay, PDO::PARAM_STR);
$query-> execute();
$results = $query -> fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query -> rowCount() > 0)
{ 
?>
<p>
<?php
echo "<span style='color:red'> Results Already Published .</span>";
 echo "<script>$('#submit').prop('disabled',true);</script>";
 echo "<script>$('#csv_file').prop('disabled',true);</script>";
 ?></p>
<?php }else{
	 echo "<script>$('#submit').prop('disabled',false);</script>";
	echo "<script>$('#csv_file').prop('disabled',false);</script>";
}
}

if(!empty($_POST["classid111"])) 
{
 $cid=intval($_POST['classid111']);
 if(!is_numeric($cid)){
 
 	echo htmlentities("invalid Class");exit;
 }
 else{
 $stmt = $dbh->prepare("SELECT StudentName,IndexNo FROM tblstudents WHERE ClassId= :id order by StudentName");
 $stmt->execute(array(':id' => $cid));
 ?><option value="">Select Student </option><?php
 ?><option value="*">All</option><?php
 while($row=$stmt->fetch(PDO::FETCH_ASSOC))
 {
  ?>
  <option value="<?php echo htmlentities($row['IndexNo']); ?>"><?php echo htmlentities($row['StudentName']); ?></option>
  <?php
 }
}

}
/*========================================Allah is The Greatest===========*/ 
if(!empty($_POST["studclass120"])) 
{
	$id= $_POST['studclass120'];
	$dta=explode("$",$id);
	$cid=$dta[0];
	$suid=$dta[1];
	$yer=$dta[2];
	$ter=$dta[3];
	$ay=$dta[4];
	$stid=$dta[5];
	if(!empty($cid) && !empty($ter) && !empty($ay) && !empty($suid) && !empty($yer) && !empty($stid))
	{
		if($stid != "*")
		{
			if(studentresult_exist($stid,$cid,$ter,$ay,$suid)===true)
			{ ?>
			<div class="form-group">
			  <label for="camark" class="col-sm-4 control-label ">Class Score(30%)</label>
				<div class="col-sm-4">
				<input type="text"  name="camarks" id="camark" min="0" maxlength="5" class="form-control" onChange="return thirty(this)" onkeypress="return isNumberKey(event,this)" required="required" value="<?php echo htmlentities(ResultsData($stid,$ay,$suid,$ter)->camarks);?>" placeholder="Enter Class Score(30%)" maxlength="5" autocomplete="off">
				</div>
			</div> 
			<div class="form-group">
			  <label for="endmark" class="col-sm-4 control-label ">End of Term(70%)</label>
				<div class="col-sm-4">
				<input type="text" name="endmarks" id="endmark" min="0" maxlength="5" class="form-control" onChange="return seventy(this)" onkeypress="return isNumberKey(event,this)" placeholder="Enter Exam Score(70%)" value="<?php echo htmlentities(ResultsData($stid,$ay,$suid,$ter)->endmark);?>" required="required" autocomplete="off">
				<input type="hidden" name="resultid" value="<?php echo htmlentities(ResultsData($stid,$ay,$suid,$ter)->id);?>">
				</div>
			</div>
			<div class="form-group">
				<div class="col-sm-offset-4 col-sm-4">
					<button type="submit" name="singleedit" id="submit" class="btn btn-primary btn-labeled">Upadate Result <span class="btn-label btn-label-right"><i class="fa fa-pencil"></i></span></button>
				</div>
			</div>
			<?php
			}else
			{
				?>
				<div class="form-group">
				  <label for="date" class="col-sm-4 control-label "></label>
					<div class="col-sm-4">
						<div >
						<span style='color:red'> No results for this Students yet .</span>
						</div>
					</div>
				</div>
				<?php	
			}
		}else
		{
			$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			$query = $dbh->prepare("SELECT
			tblstudents.IndexNo,
			tblstudents.StudentName
			FROM
			tblstudents
			WHERE
			tblstudents.ClassId = :cid
			ORDER BY
			tblstudents.IndexNo ASC");
			$query-> bindParam(':cid', $cid, PDO::PARAM_STR);
			$query-> execute();
			$results = $query -> fetchAll(PDO::FETCH_OBJ);
			$cnt=1;
			if($query -> rowCount() > 0)
			{ 
				?>
				<table class="gridtable" cellspacing="0" width="100%">
				<thead>
					<tr>
						<th>#</th>
						<th>Name</th>
						<th>School Num.</th>
						<th>Class Score(30%)</th>
						<th>Exam Score(70%)</th>
					</tr>
				</thead>
				<tbody>
				<?php
				foreach($results as $result)
				{
					$indexnno = $result->IndexNo;
					?>
					<tr>
					<?php if(studentresult_exist($indexnno,$cid,$ter,$ay,$suid)===true)
					{ ?>
						<td><?php echo htmlentities($cnt);?></td>
						<td><?php echo htmlentities($result->StudentName);?></td>
						<td><?php echo htmlentities($result->IndexNo);?></td>
						<td><input type="text"  name="camarks[]" id="camarks[]" value="<?php echo htmlentities(ResultsData($indexnno,$ay,$suid,$ter)->camarks);?>" onkeypress="return isNumberKey(event,this)"  onchange="camarks(this);" value="" class="form-control" required="required" placeholder="Enter Class Score" maxlength="5" autocomplete="off"></td>
						<td><input type="text"  name="endmarks[]" id="endmarks[]" value="<?php echo htmlentities(ResultsData($indexnno,$ay,$suid,$ter)->endmark);?>" onkeypress="return isNumberKey(event,this)" onchange="endmarks(this);" value="" class="form-control" required="required" placeholder="Enter Exam Score" maxlength="5" autocomplete="off">
						<input type="hidden" name="resultid[]" value="<?php echo htmlentities(ResultsData($indexnno,$ay,$suid,$ter)->id);?>"></td>
					<?php 
					}else
					{ ?>
						<td><?php echo htmlentities($cnt);?></td>
						<td><?php echo htmlentities($result->StudentName);?></td>
						<td><?php echo htmlentities($result->IndexNo);?></td>
						<td colspan="2" align="center"><span style='color:red'> Student Results is not uploaded .</span></td>
					<?php 
					} ?>
					</tr>
					<?php
					$cnt=$cnt+1;
				}
				?>
				</tbody>
				</table><br>
				<div class="form-group">
				<div class="col-sm-offset-4 col-sm-4">
					<button type="submit" name="bulkedit" id="submit" class="btn btn-primary btn-labeled">Upadate Result <span class="btn-label btn-label-right"><i class="fa fa-upload"></i></span></button>
				</div>
				</div>
				<?php
			}else
			{
				?>
				<div class="form-group">
				  <label for="date" class="col-sm-4 control-label "></label>
					<div class="col-sm-4">
						<div >
						<span style='color:red'> No Students in this class yet .</span>
						</div>
					</div>
				</div>
				<?php
			}	
		}
	}
}
/*========================================Allah is The Greatest===========*/ 
?>