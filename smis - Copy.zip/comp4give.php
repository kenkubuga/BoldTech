<?php
session_start();
session_regenerate_id();
//error_reporting(0);
$eee=date("Y/m/d");
include('includes/config.php');
DEFINE('BASENAMESS',basename(__FILE__));
if(strlen($_SESSION['alogin'])=="")
    {   
    header("Location: index.php"); 
    }
    else{
		$username=$_SESSION['alogin'];
		DEFINE('UIDs',$username);
		if(uname_exist1(UIDs)===true)
		{
			$cashier=(User(UIDs)->name);
		}
		elseif(staff_exist(UIDs)===true)
		{
			if(SchoolAdmin(UIDs)===true)
			{
				$cashier=StaffData(UIDs)->staff_id;
			}
			elseif(IsCashier(UIDs)===true)
			{
				$cashier=StaffData(UIDs)->staff_id;	
			}
			else
			{
				echo "<script>alert('Sorry!! You have no right to Process any transaction');</script>";
				echo "<script type='text/javascript'> document.location = 'logout.php'; </script>";
			}
		}
		else
		{
			echo "<script>alert('Sorry!! You're not a user in the system');</script>";
			echo "<script type='text/javascript'> document.location = 'logout.php'; </script>";
		}



?>


<?php 
		$get_id=$_GET['id'];

		if(isset($_POST['submit']))
		{
			$level = clean($_POST['class_level']);
			$classid = clean($_POST['classid']);
			$term = CurrentTerm();
			$acyear = CurrentACYear();
			$insert = new SchoolData();
			$Rdate=date('Y-m-d');
			$studentid = $get_id;
			define('STID',$studentid);
			$reason = clean($_POST['reason']);
			$fee = clean($_POST['fee']);
			$transtype='Cancel';
			$status = 'approved';
			$paydate = clean($_POST['paydate']);
			$NameDep=clean($_POST['NameDep']);
			$paymode = clean($_POST['paymode']);
			$mainba=ArrearsAmount1($studentid);
			$Rembal = $mainba - $fee;
			
			$sql="INSERT INTO  tblfeepayment(stu_id,transtype,classid,term,initialamount,amount,Rdate,cashier,acyear,reason)
				VALUES(:studentid,:transtype,:classid,:term,:ini_fee,:amount,:Rdate,:cashier,:acyear,:reason)";
				$query = $dbh->prepare($sql);
			$query->bindParam(':studentid',$studentid,PDO::PARAM_STR);
			$query->bindParam(':transtype',$transtype,PDO::PARAM_STR);
			$query->bindParam(':classid',$classid,PDO::PARAM_STR);
			$query->bindParam(':term',$term,PDO::PARAM_STR);
			$query->bindParam(':ini_fee',$mainba,PDO::PARAM_STR);
			$query->bindParam(':amount',$fee,PDO::PARAM_STR);
			$query->bindParam(':Rdate',$Rdate,PDO::PARAM_STR);
			$query->bindParam(':cashier',$username,PDO::PARAM_STR);
			$query->bindParam(':acyear',$acyear,PDO::PARAM_STR);
			$query->bindParam(':reason',$reason,PDO::PARAM_STR);
			$query->execute();
			Update_Arrears1($studentid,$Rembal,$Rdate);
			//echo "<script> location.href='debt4give.php'; </script>";
			echo "<script type='text/javascript'> document.location = 'debt4give.php'; </script>";
		}



		
		?>

<!DOCTYPE html>
<head>
<title><?php echo(isset(School()->SchoolName))? School()->SchoolName:"SMS"; ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Kasuli A-L Hotel Management System, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />

<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- bootstrap-css -->
<link rel="stylesheet" type="text/css" href="js/DataTables/datatables.min.css"/>
<link rel="stylesheet" href="css/bootstrap.min.css" >
<!-- //bootstrap-css -->
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href="css/style-responsive.css" rel="stylesheet"/>
<!-- font CSS -->
<link href='//fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
<!-- font-awesome icons -->
<link rel="stylesheet" href="css/kas.css" type="text/css"/>
<link rel="stylesheet" href="css/font.css" type="text/css"/>
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons -->
<script src="js/jquery2.0.3.min.js"></script>
<link href="src/jquery.bootstrap-touchspin.css" rel="stylesheet" type="text/css" media="all">
<script src="src/jquery.bootstrap-touchspin.js"></script>
<script language=Javascript>
   <!--
   function isNumberKey(evt,element)
   {
	  var charCode = (evt.which) ? evt.which : evt.keyCode;
	  if ((charCode != 46 || $(element).val().indexOf('.') != -1) && charCode > 31 
		&& (charCode < 48 || charCode > 57))
		 return false;

	  return true;
   }
   //-->
</script>
<script>
function getPayMode(val) {
$.ajax({
type: "POST",
url: "t.php",
data:'classid='+val,
success: function(data){
$("#acyearlvl").html(data);

}
});
}
</script>
</head>
<body>


<section id="container">
<!--header start-->
<?php include('includes/topbar.php');?>
<!--header end-->
<!--sidebar start-->
<?php include('includes/sidebar.php');?>
<!--sidebar end-->
<!--main content start-->


<section id="main-content">
	<section class="wrapper">
		<div class="form-w3layouts">
            <!-- page start-->
            <div class="row">
                
    <div class="col-lg-12"> <section class="panel"> <header class="panel-heading"> 
      Forgive Dept </header> 
      <div class="panel-body"> 
        <?php if($msg){?>
        <div class="alert alert-success left-icon-alert" role="alert"> <strong>Congrats 
          !</strong> 
          <?php echo htmlentities($msg); ?>
        </div>
        <?php } 
else if($error){?>
        <div class="alert alert-danger left-icon-alert" role="alert"> <strong>Oh 
          snap!</strong> 
          <?php echo htmlentities($error); ?>
        </div>
        <?php } ?>
        <div class="agile-tables"> 
          <div class="w3l-table-info"> 
            <h2><i class="fa fa-user"></i> Student's details</h2>
            <br/>
            <?php $sql = "SELECT
			
			student.stu_id,
			student.surname,
			student.firstname,
			student.class,
			student.status,
			student.guardian_name,
			student.guardian_contact,
			student.fees_paid,
			stu_class.class_id,
			stu_class.LevelId,
			stu_class.class_name,
			stu_class.class_total_fee
			FROM
			student
			INNER JOIN stu_class ON student.class = stu_class.class_id WHERE student.stu_id = :id";
			$query = $dbh->prepare($sql);
			$query->bindParam(':id',$get_id,PDO::PARAM_STR);
			$query->execute();
			$results=$query->fetchAll(PDO::FETCH_OBJ);
			$cnt=1;
			if($query->rowCount() > 0)
			{
			foreach($results as $result)
			{
				$studentidsss = $_GET['id'];
				$cid = $result->class;
				$totalfee = $result->class_total_fee;
				$feepaid = $result->fees_paid;
				echo "Name: ".$result->surname." ". $result->firstname."<br/>";
				if(scholar_exist($studentidsss)===true){
					$schamount = ScholarStudent($studentidsss)->scholarAmount;
					if($schamount){
						$xt= ' | Amount GH₵ '.$schamount;
					}else{
						$xt='';
					}
					echo htmlentities('Student is on Scholarship | Type '.ScholarStudent($studentidsss)->scholarType.$xt).'<br/>';
				}
				echo "Last Class: ". $result->class_name."<br/>";
				if(termly_fee_exist1($studentidsss)===true){
				    //$at=ArrearsAmount($studentidsss)-$schamount;
					echo 'Total Debt GH₵ '.ArrearsAmount1($studentidsss).'<br/>';
				}else{
					echo 'Fees to be Paid GH₵ '.ArrearsAmount1($studentidsss).'<br/>';
				}
			}
			}
				?>

            <form action="" method= "post">
              <div class="form-group"> 
                <input type="hidden" name="classid" value="<?php echo $result->class_id;?>" />
                <input type="hidden" name="class_level" value="<?php echo $result->LevelId;?>" />
              </div>
              <div class="form-group"> 
                <div class="col-md-12"> 
                  <label class="col-md-2 control-label">Amount to forgive</label>
                  <div class="col-md-6"> 
                    <div class="input-group"> <span class="input-group-addon"> 
                      <i class="fa fa-money" aria-hidden="true"></i> </span> 
                      <input type="text" name="fee" onkeypress="return isNumberKey(event,this)" class="form-control" id="fee" maxlength="10" required="required" autocomplete="off">
                    </div>
                  </div>
                </div>
              </div>
              <div class="form-group"> 
                <div class="col-md-12"> 
                  <label class="col-md-2 control-label">Reason</label>
                  <div class="col-md-6"> 
                    <div class="input-group"> <span class="input-group-addon"> 
                      <i class="fa fa-file-o" aria-hidden="true"></i> </span> 
                      <input type="text" name="reason" class="form-control" id="fee" required="required">
                    </div>
                  </div>
                </div>
              </div>
              <div class="form-group"> 
                <div class="col-md-12"> 
                  <label class="col-md-2 control-label">Date of Debt Forgiveness</label>
                  <div class="col-md-6"> 
                    <div class="input-group"> <span class="input-group-addon"> 
                      <i class="fa fa-file-o" aria-hidden="true"></i> </span> 
                      <input type="date" value="" name="paydate" class="form-control" id="paydate"  maxlength="50" required="required" autocomplete="off" >
                    </div>
                  </div>
                </div>
              </div><div class="form-group">
              <div id="acyearlvl"> </div>
              <div class="row"> 
                <div class="col-sm-8 col-sm-offset-2"> 
                  <button type="submit" name="submit" id="SubmitB" onclick="myFunction()" class="btn-primary btn">Submit</button>
                </div>
              </div>
            </form>
          </div>
        </div>
        <!-- //tables -->
      </div>
    </div>
					</section>
				</div>
			</div>
			<!-- page end-->
			</div>
			</section>
			
			<!-- footer -->
			<?php include('includes/footer.php');?>
			  <!-- / footer -->
			</section>
			<!--main content end-->
			</section>
			<script src="js/bootstrap.js"></script>
			<script src="js/jquery.dcjqaccordion.2.7.js"></script>
			<script src="js/scripts.js"></script>
			<script src="js/jquery.slimscroll.js"></script>
			<script src="js/jquery.nicescroll.js"></script>
			<!--[if lte IE 8]><script language="javascript" type="text/javascript" src="js/flot-chart/excanvas.min.js"></script><![endif]-->
			<script src="js/jquery.scrollTo.js"></script>
			<script src="js/DataTables/datatables.min.js"></script>
			<script>
				$(function($) {
					$('#example').DataTable({
			
						dom: 'Bfrtip',
						buttons: [
							'excelHtml5',
							'csvHtml5',
							'pdfHtml5'
						],
			
						"pager": 150,
						"pageLength" : 100
						
					});
				});
			</script>
			<script>
function myFunction() {
  var SubmitBtElement = document.getElementById("SubmitB");
  SubmitBtElement.style.display = "None";
}
</script>
			</body>
			</html>
			<?php }?>