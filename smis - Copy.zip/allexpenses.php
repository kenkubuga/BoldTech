<?php
session_start();
error_reporting(0);
include('includes/config.php');
DEFINE('BASENAMESS',basename(__FILE__));
if(strlen($_SESSION['alogin'])=="")
    {   
    header("Location: index.php"); 
    }
    else{
		 $d1=(isset($_GET['d1']))? clean($_GET['d1']):"";
		 $d2=(isset($_GET['d2']))? clean($_GET['d2']):"";
?>
<!DOCTYPE html>
<head>
<title><?php echo(isset(School()->SchoolName))? School()->SchoolName:"SMS"; ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Kasuli A-L Hotel Management System, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- bootstrap-css -->
<link rel="stylesheet" type="text/css" href="js/DataTables/datatables.min.css"/>
<link rel="stylesheet" href="css/bootstrap.min.css" >
<link rel="stylesheet" type="text/css" href="dp/jquery.datetimepicker.css"/>
<!-- //bootstrap-css -->
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href="css/style-responsive.css" rel="stylesheet"/>
<!-- font CSS -->
<link href='//fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
<!-- font-awesome icons -->
<link rel="stylesheet" href="css/kas.css" type="text/css"/>
<link rel="stylesheet" href="css/font.css" type="text/css"/>
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons -->
<script src="js/jquery2.0.3.min.js"></script>
<link href="src/jquery.bootstrap-touchspin.css" rel="stylesheet" type="text/css" media="all">
<script src="src/jquery.bootstrap-touchspin.js"></script>
</head>
<body>
<section id="container">
<!--header start-->
<?php include('includes/topbar.php');?>
<!--header end-->
<!--sidebar start-->
<?php include('includes/sidebar.php');?>
<!--sidebar end-->
<!--main content start-->
<section id="main-content">
	<section class="wrapper">
		<div class="form-w3layouts">
            <!-- page start-->
            <div class="row">
                <div class="col-lg-12">
                    <section class="panel">
                        <header class="panel-heading">
                            Expenses Record
                        </header>
                        <div class="panel-body">
<?php if($msg){?>
<div class="alert alert-success left-icon-alert" role="alert">
 <strong>Well done! </strong><?php echo htmlentities($msg); ?>
 </div><?php } 
else if($error){?>
    <div class="alert alert-danger left-icon-alert" role="alert">
	<strong>Oh snap! </strong> <?php echo htmlentities($error); ?>
</div>
<?php } ?>
<div class="position-center">
	<form class="form-inline" method="GET" action="allexpenses.php">
		
	
</form>
</div><br>
	<table id="example" class="gridtable" cellspacing="0" style="width:100%">
			<thead>
				<tr>
					<th>#</th>
					<th>Type</th>
					<th>Description</th>
          <th>Spending Officer</th>
					<th>Amount</th>
					<th>Date</th>
					<th>Made By</th>
				</tr>
			</thead>
			<tbody>
<?php
$sql = "SELECT
tblexpenses.id,
tblexpenses.type,
tblexpenses.reason,
tblexpenses.officer,
tblexpenses.amount,
tblexpenses.cashier,
tblexpenses.rdate
FROM
tblexpenses
WHERE
tblexpenses.rdate BETWEEN :a AND :b";
$query = $dbh->prepare($sql);
$query->bindParam(':a', $d1);
$query->bindParam(':b', $d2);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{ ?>
<tr class="record">
<td><?php echo htmlentities($cnt);?></td>
<td><?php echo htmlentities($result->type);?></td>
<td><?php echo htmlentities($result->reason);?></td>
<td><?php echo htmlentities($result->officer);?></td>
<td><?php echo htmlentities($result->amount);?></td>
<td>               <?php $kdate = htmlentities($result->rdate);
                  $newDate = date("d-M-Y", strtotime($kdate));
					echo $newDate;?></td>
<td><?php echo htmlentities($result->cashier);?></td>
</tr>
<?php $cnt=$cnt+1;}} ?>

			</tbody>
			<tfoot>
		<tr>
                <th colspan="4" style="text-align:right">Total:</th>
                <th></th>
            </tr>
		</tfoot>
		</table>
		
			</div>
		</section>
	</div>
</div>
<!-- page end-->
</div>
</section>
<!-- footer -->
<?php include('includes/footer.php');?>
  <!-- / footer -->
</section>
<!--main content end-->
</section>
<script src="js/bootstrap.js"></script>
<script src="js/jquery.dcjqaccordion.2.7.js"></script>
<script src="js/scripts.js"></script>
<script src="js/jquery.slimscroll.js"></script>
<script src="js/jquery.nicescroll.js"></script>
<!--[if lte IE 8]><script language="javascript" type="text/javascript" src="js/flot-chart/excanvas.min.js"></script><![endif]-->
<script src="js/jquery.scrollTo.js"></script>
<script src="dp/jquery.datetimepicker.full.js"></script>
<script src="js/DataTables/datatables.min.js"></script>
<script>
	$(document).ready(function() {
    $('#example').DataTable( {
		"lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
			
			
			
        "footerCallback": function ( row, data, start, end, display ) {
            var api = this.api(), data;
 
            // Remove the formatting to get integer data for summation
            var intVal = function ( i ) {
                return typeof i === 'string' ?
                    i.replace(/[\$,]/g, '')*1 :
                    typeof i === 'number' ?
                        i : 0;
            };
 
            // Total over all pages
            total = api
                .column( 4 )
                .data()
                .reduce( function (a, b) {
                    return intVal(a) + intVal(b);
                }, 0 );
 
            // Total over this page
            pageTotal = api
                .column( 4, { page: 'current'} )
                .data()
                .reduce( function (a, b) {
                    return intVal(a) + intVal(b);
                }, 0 );
 
            // Update footer
            $( api.column( 4 ).footer() ).html(
                'GH₵'+pageTotal +' (GH₵'+ total +' total)'
            );
        }
    } );
} );
</script>
<script>
  var birthdate = $('#Birthdate').val();
    var today = new Date();
    var dd = today.getDate();
    var mm = today.getMonth()+1;
    var yy = today.getFullYear();
    var tdate = yy+"-"+mm+"-"+dd;

$('#Birthdate').datetimepicker({
  yearOffset:0,
  lang:'ch',
  timepicker:false,
  format:'Y-m-d',
  formatDate:'Y-m-d',
  //minDate:'-1980/01/01', // yesterday is minimum date
  maxDate: tdate, // and tommorow is maximum date calendar
});

$('#JoinDate').datetimepicker({
  yearOffset:0,
  lang:'ch',
  timepicker:false,
  format:'Y-m-d',
  formatDate:'Y-m-d',
  //minDate:'-1980/01/01', // yesterday is minimum date
  maxDate: tdate // and tommorow is maximum date calendar
});

$('#LeaveDate').datetimepicker({
  yearOffset:0,
  lang:'ch',
  timepicker:false,
  format:'Y-m-d',
  formatDate:'Y-m-d',
  maxDate: tdate
});
</script>

</body>
</html>
<?php }?>