<?php  
ini_set('display_errors', 1);
include('includes/config.php');
require_once 'PHPExcel.php';
if(isset($_GET['cid']))
{
	$classid=$_GET['cid'];
	$objPHPExcel = new PHPExcel();
	$result = $dbh->prepare("SELECT
	student.surname,
	student.stu_id,
	student.firstname,
	student.admission_year,
	stu_class.class_name,
	student.class,
	student.guardian_name,
	student.guardian_contact,
	student.fees_paid,
	student.`status`
	FROM
	student
	INNER JOIN stu_class ON student.class = stu_class.class_id
	WHERE
	student.class = :class");
	$result->bindParam(':class', $classid);
	$result->execute();	

	$objPHPExcel = new PHPExcel();
	$ews = $objPHPExcel->getSheet(0);
	$ews->setTitle(class_name($classid));
	for ($col = ord('A'); $col <= ord('E'); $col++)
	{
		$ews->getColumnDimension(chr($col))->setAutoSize(true);
	}
	$header = 'A1:E1';
	$ews->getStyle($header)->getFill()->setFillType(\PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setARGB('00ffff00');
	$style = array(
    'font' => array('bold' => true,),
    'alignment' => array('horizontal' => \PHPExcel_Style_Alignment::HORIZONTAL_CENTER,),
    );
	$ews->getStyle($header)->applyFromArray($style);
	$rowCount = 2;
	$objPHPExcel->getActiveSheet()->SetCellValue('A1','Sch. Num');
	$objPHPExcel->getActiveSheet()->SetCellValue('B1','Student Name');
	$objPHPExcel->getActiveSheet()->SetCellValue('C1','Admission Year');
	$objPHPExcel->getActiveSheet()->SetCellValue('D1','Guardian Name');
	$objPHPExcel->getActiveSheet()->SetCellValue('E1','Guardian Contact');
 	for($i=0; $row = $result->fetch(); $i++){
		$objPHPExcel->getActiveSheet()->SetCellValue('A'.$rowCount, $row['stu_id']);
		$objPHPExcel->getActiveSheet()->SetCellValue('B'.$rowCount, $row['surname']." ".$row['firstname']);
		$objPHPExcel->getActiveSheet()->SetCellValue('C'.$rowCount, $row['admission_year']);
		$objPHPExcel->getActiveSheet()->SetCellValue('D'.$rowCount, $row['guardian_name']);
		$objPHPExcel->getActiveSheet()->SetCellValue('E'.$rowCount, $row['guardian_contact']);

		$rowCount++;
	}
	$filename = class_name($classid);
	$filename = preg_replace('/\s+/', '', $filename);
	header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
	header('Content-Disposition: attachment;filename="'.$filename.'.xlsx"');
	header('Cache-Control: max-age=0');

	$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
	ob_end_clean();
	$objWriter->save("php://output");	
	$objPHPExcel->disconnectWorksheets();// Good to disconnect
	$objPHPExcel->garbageCollect(); // Trow every garbage away
	unset($objWriter, $objPHPExcel);
}
?>