<?php
if(isset($_POST['sendmessage'])){

$shortMessage = $_POST["comment"];
$sMessage = preg_replace('/\s+/', '%20', $shortMessage);
//$apikey = "fX9uSP8GMme6VUQdHJLzYnrKFZsWT017O2E5xwphIqtvAoc43g";
$destinationAddress = $_POST["destinationAddress"];
//$messageDescription = "default";
//$messageType = "quick";

// SEND SMS
function smsRoute($descontact,$mainMsg) {
    global $resp;
    $curl = curl_init();
    curl_setopt_array($curl, array(
    CURLOPT_URL => 'https://sms.arkesel.com/sms/api?action=send-sms&api_key=OmJHV0R6SGNDTEFGckt2NGI=&to='.$descontact.'&from=FastLink&sms='.$mainMsg,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => '',
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 10,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => 'GET', ));
    $response = curl_exec($curl);
    curl_close($curl);
    //echo $response;
    //convert the original object data from arkesel to array
    $bal=json_decode($response,true);
    //select only the data part
    //$countries = $bal['data'];
    //take the sms balance
     $resp=$bal['message'];
    
}
 // original string
 $b = str_replace( ',', '', $destinationAddress );
    //$lastFour = substr($destinationAddress, 0, 10);
    //print_r(str_split($b,10));
    //echo count(str_split($b,10));
    //print_r(array_slice(str_split($b,10), 0, 10)); 
    //print_r(array_chunk(str_split($b,10), 100));
    foreach(array_chunk(str_split($b,10), 100) as $curta ) {
        //print_r($curta);
        //echo $string = json_encode($curta);
        $array_as_string = implode(",",$curta);
        smsRoute($array_as_string,$sMessage);
        //echo '<hr>';
        
    }
//echo $response;
	
    //$live_url="https://boldsms.com/smssendingscript.php?username=boldfast&apikey=fX9uSP8GMme6VUQdHJLzYnrKFZsWT017O2E5xwphIqtvAoc43g&sourceAddress=FastLink&shortMessage=$journalName2&destinationAddress=$destinationContact&messageDescription=default&messageType=quick"; 
	//$live_url="https://sms.arkesel.com/sms/api?action=send-sms&api_key=OmJHV0R6SGNDTEFGckt2NGI=&to=$destinationAddress&from=FastLink&sms=$shortMessage";
	//$parse_url=file_get_contents($live_url);
	//$parse_url=file($live_url);
	header("location:smsclasspro.php?msgark=".$resp);
	//echo "<script type='text/javascript'> document.location = 'smsclasspro.php?errmsg=success'; </script>";
}