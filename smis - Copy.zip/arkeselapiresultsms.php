<?php
if(isset($_POST['studentid'])){
include('includes/config.php');
//$username = "boldfast";
//$sourceAddress = "FastLink";
//exit;
$studentid = $_POST["studentid"];
$classid = $_POST["classid"];
$levelid = $_POST["levelid"];
$acyear = $_POST["acyear"];
$term = $_POST["term"];
$termwithoutspace = preg_replace('/\s/', '', $term);
//$urllink="https://parents.fastlink.edu.gh/smis/presultsprevnew.php?stuid=16102&term={$termwithoutspace}&class={$classid}&acyear={$acyear}";
//echo $urllink;

function makeUrltoLink($string) {
 // The Regular Expression filter
 $reg_pattern = "/(((http|https|ftp|ftps)\:\/\/)|(www\.))[a-zA-Z0-9\-\.]+\.[a-zA-Z]{2,3}(\:[0-9]+)?(\/\S*)?/";
 
 // make the urls to hyperlinks
 return preg_replace($reg_pattern, '<a href="$0" target="_blank" rel="noopener noreferrer">Download Report</a>', $string);
}
 
//echo $convertedStr = makeUrltoLink($urllink);
//$sMessage = preg_replace('/\s+/', '%20', $shortMessage);
//$apikey = "fX9uSP8GMme6VUQdHJLzYnrKFZsWT017O2E5xwphIqtvAoc43g";
if($studentid=="*"){
    $stuid = $_POST["destinationAddress"];
}else{
    $stuid=$studentid;
}

// Explode to an array
$stuidArray = explode (",", $stuid);
$recipients = [];

foreach ($stuidArray as $value) {

$results = $dbh->prepare("SELECT
				student.stu_id,
				student.surname,
				student.firstname,
				student.guardian_contact
				
				
				FROM
				student WHERE student.stu_id =:a
				");
			$results->bindParam(':a', $value);
			$results->execute();
			for($i=0; $rows = $results->fetch(); $i++){
		
			 $contact=$rows['guardian_contact'];
			 //$contact='0264887736';
			 $te=$rows['surname'];
			 $te1=$rows['firstname'];
			 //echo $value;
			$mainlink="https://parents.fastlink.edu.gh/smis/presultsprevnew.php?stuid={$value}&term={$termwithoutspace}&class={$classid}&acyear={$acyear}";
			$convertedStr = makeUrltoLink($mainlink);
			$recipients[$contact] = [
            'surname' => $te,
            'firstname' => $te1,
            'urllink' => $convertedStr,
        ];
        //echo urlencode($convertedStr);
        //echo $convertedStr;
        //$url=$_POST["url_value"];
        
  //$short_url=substr(md5($convertedStr.mt_rand()),0,8);
 //echo $conv = makeUrltoLink($short_url);
			}
}
//print_r($recipients);
//exit;

//$shortMessage =$_POST['shortMessage'];
//$sMessage = preg_replace('/\s+/', '%20', $shortMessage);
$senderid = 'FastLink'; 

//$destswithspace = $_POST['destinationAddress'];

//Stripped it of space
/*$destinationAddress = preg_replace('/\s/', '', $destswithspace);
$destinationAddress = str_replace("+", "", $destinationAddress);
$destinationAddress = str_replace("-", "", $destinationAddress);

$destinationAddress = str_replace("/", ",", $destinationAddress);

// Explode to an array
$destinationAddressArray = explode (",", $destinationAddress);


//remove duplicates
$destinationAddressArray = array_unique($destinationAddressArray);
 $newDestArray = array_filter($destinationAddressArray, function($k) {
    return $k != '';
});*/


// SEND SMS USING TEMPLATE
$curl = curl_init();

curl_setopt_array($curl, [
    CURLOPT_URL => 'https://sms.arkesel.com/api/v2/sms/template/send',
    CURLOPT_HTTPHEADER => ['api-key: OmJHV0R6SGNDTEFGckt2NGI='],
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => '',
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => 'POST',
    CURLOPT_POSTFIELDS => http_build_query([
        'sender' => $senderid,
        'message' => 'Click the link below to download <%surname%>  <%firstname%> report for ' .$term.', '.$acyear.': <%urllink%>',
        'recipients' => $recipients
    ]),
]);

$response = curl_exec($curl);
curl_close($curl);
$bal=json_decode($response,true);
$resp=$bal['status'];


//echo $response;
//exit;
/*
//SEND SMS V2
$curl = curl_init();
curl_setopt_array($curl, [
    CURLOPT_URL => 'https://sms.arkesel.com/api/v2/sms/send',
    CURLOPT_HTTPHEADER => ['api-key: OmJHV0R6SGNDTEFGckt2NGI='],
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => '',
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => 'POST',
    CURLOPT_POSTFIELDS => http_build_query([
        'sender' => $senderid,
        'message' => $shortMessage,
        'recipients' => $newDestArray
    ]),
]);

$response = curl_exec($curl);
curl_close($curl);
$bal=json_decode($response,true);
$resp=$bal['status'];
*/
// SEND SMS

header("location:classresultprevsms.php?msgark=".$resp); 
//	echo "<script type='text/javascript'> document.location = 'smsparentpro.php?errmsg=success'; </script>";
}
?>