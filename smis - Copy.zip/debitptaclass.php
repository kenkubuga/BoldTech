<?php
session_start();
error_reporting(0);
include('includes/config.php');

DEFINE('BASENAMESS',basename(__FILE__));
if(strlen($_SESSION['alogin'])=="")
    {   
    header("Location: index.php"); 
    }
    else{
		if(isset($_POST['submit']))
		{
			$username=$_SESSION['alogin'];
			$classid = $_POST['acyearlvl'];
			$studentid = $_POST['studentid'];
			$toclassid = $_POST['classid'];
			$acyear = $_POST['acyear'];
			$term = $_POST['term'];
			$dat= date('Y-m-d');
			$insert = new SchoolData();
			$reason = clean($_POST['reason']);
			$fee = clean($_POST['fee']);
			$source = 'PTA';
			$bef=0.0;
			$beff=0.0;
			$befff=0.0;
			$sch=0.0;
			$transtype='PTA';
			$transt='Debit';
			//$fee=0;
			//$reason='Term Fees';
			if($studentid != "*")
			{
				if($classid != 0)
				{
					     //$eee=date("Y/m/d");
						//$rrr=0.0;
						$stu_class_id = class_id($studentid);
						//$termfees = class_fee($stu_class_id);
						$bal=ArrearsAmountpta($studentid);
						
					    //$sch=ScholarshipAmount($studentid);
						$mainbal=$fee+$bal;
						//$mainbal1=$termfees-$scholar;
						$sql="INSERT INTO debitstudentpta(stu_id,class_id,level,term,year,bal_before,amount,bal_after,debitdate,reason,transtype)VALUES(:staffid,:classid,:level,:term,:year,:before,:amount,:after,:debitdat,:reason,:transtype)";
						$query = $dbh->prepare($sql);
						$query->bindParam(':staffid',$studentid,PDO::PARAM_STR);
						$query->bindParam(':classid',$classid,PDO::PARAM_STR);
						$query->bindParam(':level',$toclassid,PDO::PARAM_STR);
						//$query->bindParam(':level',$ttt,PDO::PARAM_STR);
						$query->bindParam(':term',$term,PDO::PARAM_STR);
						$query->bindParam(':year',$acyear,PDO::PARAM_STR);
						$query->bindParam(':before',$bal,PDO::PARAM_STR);
						$query->bindParam(':amount',$fee,PDO::PARAM_STR);
						$query->bindParam(':reason',$reason,PDO::PARAM_STR);
						$query->bindParam(':after',$mainbal,PDO::PARAM_STR);
						$query->bindParam(':debitdat',$dat,PDO::PARAM_STR);
						$query->bindParam(':transtype',$transtype,PDO::PARAM_STR);
						
						//$query->bindParam(':actual',$actual,PDO::PARAM_STR);
						//$query->bindParam(':remark',$remark,PDO::PARAM_STR);
						if($query->execute()==true){
							if(arrears_existpta($studentid)==true){
								Update_Arrearspta($studentid,$mainbal,$dat);
								$msg="Student debited successfully";
							}else{
								Insert_Arrearspta($studentid,$mainbal,$dat);
								$msg="Student debited successfully";
							}
							
							$sql1="INSERT INTO  tblfeepayment(stu_id,transtype,source,classid,term,initialamount,amount,Rdate,cashier,acyear,reason)
				VALUES(:studentid,:transtype,:source,:classid,:term,:ini_fee,:amount,:Rdate,:cashier,:acyear,:reason)";
				$data = array(
					':studentid' => $studentid,
					':transtype' => $transt,
					':source' => $source,
					':classid' => $stu_class_id,
					':term' => $term,
					':ini_fee' => $bal,
					':amount' => $fee,
					':Rdate' => $dat,
					':cashier' => $username,
					':acyear' => $acyear,
					':reason' => $reason);
					if($insert->ExecSql($sql1,$data)!==false){}	
							
						}else
						{
							$msg="Check your inputs";
						}
						
				
				}else
				{
					
						$error="Something went wrong. Please try again";
						
						
				}
			}else
			{
				$sql = "SELECT student.stu_id FROM student WHERE student.class = :classid";
				$query2 = $dbh->prepare($sql);
				$query2->bindParam(':classid',$classid,PDO::PARAM_STR);
				$query2->execute();
				$results1=$query2->fetchAll(PDO::FETCH_OBJ);
				if($query2->rowCount() > 0)
				{
					foreach($results1 as $result2)
					{
						
						$studentid = $result2->stu_id;
						$stu_class_id = class_id($studentid);
						//$termfees = class_fee($stu_class_id);
						//$termfees = TotalPayableFee($studentid);
						$bal=ArrearsAmountpta($studentid);
					
						$mainbal=$fee+$bal;
						$stu_class_id = class_id($studentid);
						$sql="INSERT INTO debitstudentpta(stu_id,class_id,level,term,year,bal_before,amount,bal_after,debitdate,reason,transtype)VALUES(:staffid,:classid,:level,:term,:year,:before,:amount,:after,:debitdat,:reason,:transtype)";
						$query = $dbh->prepare($sql);
						$query->bindParam(':staffid',$studentid,PDO::PARAM_STR);
						$query->bindParam(':classid',$classid,PDO::PARAM_STR);
						$query->bindParam(':level',$toclassid,PDO::PARAM_STR);
						//$query->bindParam(':level',$ttt,PDO::PARAM_STR);
						$query->bindParam(':term',$term,PDO::PARAM_STR);
						$query->bindParam(':year',$acyear,PDO::PARAM_STR);
						$query->bindParam(':before',$bal,PDO::PARAM_STR);
						$query->bindParam(':amount',$fee,PDO::PARAM_STR);
						$query->bindParam(':reason',$reason,PDO::PARAM_STR);
						$query->bindParam(':after',$mainbal,PDO::PARAM_STR);
						$query->bindParam(':debitdat',$dat,PDO::PARAM_STR);
						$query->bindParam(':transtype',$transtype,PDO::PARAM_STR);
						
					
						if($query->execute()==true)
						{
						
						if(arrears_existpta($studentid)==true){
								Update_Arrearspta($studentid,$mainbal,$dat);
								$msg="Student debited successfully";
							}else{
								Insert_Arrearspta($studentid,$mainbal,$dat);
								$msg="Student debited successfully";
							}
							
							$sql2="INSERT INTO  tblfeepayment(stu_id,transtype,source,classid,term,initialamount,amount,Rdate,cashier,acyear,reason)
				VALUES(:studentid,:transtype,:source,:classid,:term,:ini_fee,:amount,:Rdate,:cashier,:acyear,:reason)";
				$data2 = array(
					':studentid' => $studentid,
					':transtype' => $transt,
					':source' => $source,
					':classid' => $stu_class_id,
					':term' => $term,
					':ini_fee' => $bal,
					':amount' => $fee,
					':Rdate' => $dat,
					':cashier' => $username,
					':acyear' => $acyear,
					':reason' => $reason);
						//$query->bindParam(':actual',$actual,PDO::PARAM_STR);
						//$query->bindParam(':remark',$remark,PDO::PARAM_STR);
						if($insert->ExecSql($sql2,$data2)!==false){}	
							
						}
						else 
						{
						$error="Something went wrong. Please try again";
						}
						
					}
					
			
				}
			}
			
			
		}
?>
<!DOCTYPE html>
<head>
<title><?php echo(isset(School()->SchoolName))? School()->SchoolName:"SMS"; ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="boldtech, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- bootstrap-css -->
<link rel="stylesheet" href="css/bootstrap.min.css" >
<!-- //bootstrap-css -->
<!-- Custom CSS -->
<link rel="stylesheet" type="text/css" href="dp/jquery.datetimepicker.css"/>
<link rel="stylesheet" href="css/select2/select2.min.css" >
<link rel="stylesheet" href="css/select2/select2.js" >
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href="css/style-responsive.css" rel="stylesheet"/>
<!-- font CSS -->
<link href='//fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
<!-- font-awesome icons -->
<link rel="stylesheet" href="css/font.css" type="text/css"/>
<link rel="stylesheet" href="css/kas.css" type="text/css"/>
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons -->
<script src="js/jquery2.0.3.min.js"></script>
  <link href="src/jquery.bootstrap-touchspin.css" rel="stylesheet" type="text/css" media="all">
  <script src="src/jquery.bootstrap-touchspin.js"></script>
<script>
function getAcyear(val) {
$.ajax({
type: "POST",
url: "y.php",
data:'classid='+val,
success: function(data){
$("#acyearlvl").html(data);

}
});
}
</script>
<!-- script -->
<script>
function getClass(val) {
$.ajax({
type: "POST",
url: "y.php",
data:'classid1='+val,
success: function(data){
$("#studentid").html(data);

}
});
}
</script>





</head>
<body>
<section id="container">
<!--header start-->
<?php include('includes/topbar.php');?>
<!--header end-->
<!--sidebar start-->
<?php include('includes/sidebar.php');?>
<!--sidebar end-->
<!--main content start-->
<section id="main-content">
	<section class="wrapper">
		<div class="form-w3layouts">
            <!-- page start-->
            <div class="row">
                
    <div class="col-lg-12"> <section class="panel"> <header class="panel-heading"> 
      Debit Student By Class (PTA)</header> 
      <div class="panel-body"> 
        <?php if($msg){?>
        <div class="alert alert-success left-icon-alert" role="alert"> <strong>Well 
          done! </strong>
          <?php echo htmlentities($msg); ?>
        </div>
        <?php } 
else if($error){?>
        <div class="alert alert-danger left-icon-alert" role="alert"> <strong>Sorry! 
          </strong> 
          <?php echo htmlentities($error); ?>
        </div>
        <?php } ?>
        
        <form method="post" enctype="multipart/form-data"  class="form-horizontal">
          <div class="form-group"> 
            <label class="col-md-2 control-label">Level</label>
            <div class="col-md-6"> 
              <div class="input-group"> <span class="input-group-addon"> <i class="fa fa-wpforms" aria-hidden="true"></i> 
                </span> 
                <select name="classid" id="classid" required="required" onBlur="getresult(this.value)" onChange="getAcyear(this.value);" class="form-control clid">
                  <option value="">Select Level</option>
                  <?php $sql = "SELECT id,LevelName from tbllevel";
	$query = $dbh->prepare($sql);
	$query->execute();
	$results=$query->fetchAll(PDO::FETCH_OBJ);
	if($query->rowCount() > 0)
	{
	foreach($results as $result)
	{   ?>
                  <option value="<?php echo htmlentities($result->id); ?>"> 
                  <?php echo htmlentities($result->LevelName); ?>
                  </option>
                  <?php }} ?>
                </select>
              </div>
            </div>
          </div>
          <div class="form-group"> 
            <label class="col-md-2 control-label">Class</label>
            <div class="col-md-6"> 
              <div class="input-group"> <span class="input-group-addon"> <i class="fa fa-bar-chart-o" aria-hidden="true"></i> 
                </span> 
                <select name="acyearlvl" id="acyearlvl" required="required" onChange="getClass(this.value)" class="form-control acyearlvl">
                </select>
              </div>
            </div>
          </div>
         
         
          <div class="form-group"> 
            <label class="col-md-2 control-label">Student</label>
            <div class="col-md-6"> 
              <div class="input-group"> <span class="input-group-addon"> <i class="fa fa-female" aria-hidden="true"></i> 
                </span> 
                <select name="studentid" id="studentid"   required="required" class="form-control">
                </select>
              </div>
            </div>
          </div>
          
		  <div class="form-group"> 
            <label class="col-md-2 control-label">Term</label>
            <div class="col-md-6"> 
              <div class="input-group"> <span class="input-group-addon"> <i class="fa fa-map-marker" aria-hidden="true"></i> 
                </span> 
                <select name="term" id="term" onChange="getresult(this.value)" required="required" class="form-control term">
                  <option value="">Select Term</option>
                  <option value="First Term">First Term</option>
                  <option value="Second Term">Second Term</option>
                  <option value="Third Term">Third Term</option>
                </select>
              </div>
            </div>
          </div>
         
			
			<div class="form-group"> 
            <label class="col-md-2 control-label">Academic Year</label>
            <div class="col-md-6"> 
              <div class="input-group"> <span class="input-group-addon"> <i class="fa fa-yoast" aria-hidden="true"></i> 
                </span> 
                <select name="acyear" id="acyear" onChange="getresult(this.value)" required="required" class="form-control acyear">
                  <?php $acyear = date('Y');
	  $month = date("m"); ?>
                  <option value="">Select Academic Year</option>
                  <?php if($month>=9){ ?>
                  <option value="<?php echo htmlentities($acyear."-".($acyear+1));?>"> 
                  <?php echo htmlentities($acyear."-".($acyear+1));?>
                  </option>
                  <?php }?>
                  <option value="<?php echo htmlentities(($acyear-1)."-".$acyear);?>"> 
                  <?php echo htmlentities(($acyear-1)."-".$acyear);?>
                  </option>
                  <?php
		$counter = 4;
		for($a=0;$a<=$counter;$a++)
		{
			$acyear = $acyear-1;
	  ?>
                  <option value="<?php echo htmlentities(($acyear-1)."-".$acyear);?>"> 
                  <?php echo htmlentities(($acyear-1)."-".$acyear);?>
                  </option>
                  <?php
		}?>
                </select>
              </div>
            </div>
          </div>
		  
		  <div class="form-group"> 
                <div class="col-md-12"> 
                  <label class="col-md-2 control-label">Amount</label>
                  <div class="col-md-6"> 
                    <div class="input-group"> <span class="input-group-addon"> 
                      <i class="fa fa-money" aria-hidden="true"></i> </span> 
                      <input type="text" name="fee" onkeypress="return isNumberKey(event,this)" class="form-control" id="fee" maxlength="10" required="required" autocomplete="off">
                    </div>
                  </div>
                </div>
              </div>
              <div class="form-group"> 
                <div class="col-md-12"> 
                  <label class="col-md-2 control-label">Narration</label>
                  <div class="col-md-6"> 
                    <div class="input-group"> <span class="input-group-addon"> 
                      <i class="fa fa-file-o" aria-hidden="true"></i> </span> 
                      <input type="text" name="reason" class="form-control" id="fee" required="required">
                    </div>
                  </div>
                </div>
              </div>
	</div>
          <div class="row"> 
            <div class="col-sm-8 col-sm-offset-2"> 
              <button type="submit" id="submit" name="submit" class="btn-primary btn">Submit</button>
              <button type="reset" class="btn-inverse btn">Reset</button>
            </div>
          </div>
        </form>
      </div>
    </div>
</div>
</div>
</div>

			</div>
		</section>
	</div>
</div>
<!-- page end-->
</div>
</section>
<!-- footer -->
<?php include('includes/footer.php');?>
  <!-- / footer -->
</section>
<!--main content end-->
</section>
<script src="js/bootstrap.js"></script>
<script src="js/jquery.dcjqaccordion.2.7.js"></script>
<script src="js/scripts.js"></script>
<script src="js/jquery.slimscroll.js"></script>
<script src="js/jquery.nicescroll.js"></script>
<script src="js/jquery.scrollTo.js"></script>
<script src="js/select2/select2.min.js"></script>
<script>
	$(function($) {
		$(".select2").select2();
		$(".js-states-limit").select2({
			maximumSelectionLength: 2
		});
		$(".js-states-hide").select2({
			minimumResultsForSearch: Infinity
		});
	});
</script>
<script>
  function camarks(input) {
    if (input.value < 0) input.value = 0;
    if (input.value > 100) input.value = 100;
  }
</script>
<script>
  function endmarks(input) {
    if (input.value < 0) input.value = 0;
    if (input.value > 100) input.value = 100;
  }
</script>
</body>
</html>
<?php }?>