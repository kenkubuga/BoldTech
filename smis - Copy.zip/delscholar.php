		<?php
session_start();
error_reporting(0);
include('includes/config.php');
			$cid=intval($_GET['id']);
			$sid=intval($_GET['sid']);
			$dat= date('Y/m/d');
			$bal=ArrearsAmount1($sid);
			$sch=ScholarshipAmount($sid);
			$mainbal = $sch + $bal;
			
			if(termly_debit_exist($sid)==true){
				Update_Arrears1($sid,$mainbal,$dat);
				$sql="delete from tblscholar where id=:cid ";
				$query = $dbh->prepare($sql);
				$query->bindParam(':cid',$cid,PDO::PARAM_STR);
			$query->execute();
				echo "<script> location.href='http://smis.fastlink.edu.gh/scholarships.php'; </script>";
	        exit();
			}else{
			$sql="delete from tblscholar where id=:cid ";
			$query = $dbh->prepare($sql);
			$query->bindParam(':cid',$cid,PDO::PARAM_STR);
			$query->execute();
		echo "<script> location.href='http://smis.fastlink.edu.gh/scholarships.php'; </script>";
		exit();
			} 
		?>