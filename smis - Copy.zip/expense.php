<?php
session_start();
error_reporting(0);
DEFINE('BASENAMESS',basename(__FILE__));
include('includes/config.php');
if(strlen($_SESSION['alogin'])=="")
    {   
    header("Location: index.php"); 
    }
    else{
		$username=$_SESSION['alogin'];
		DEFINE('UIDs',$username);
		if(uname_exist1(UIDs)===true)
		{
			$cashier=(User(UIDs)->name);
		}
		elseif(staff_exist(UIDs)===true)
		{
			if(SchoolAdmin(UIDs)===true)
			{
				$cashier=StaffData(UIDs)->fullname;
			}
			elseif(IsCashier(UIDs)===true)
			{
				$cashier=StaffData(UIDs)->fullname;	
			}
			else
			{
				echo "<script>alert('Sorry!! You have no right to Process any transaction');</script>";
				echo "<script type='text/javascript'> document.location = 'logout.php'; </script>";
			}
		}
		else
		{
			echo "<script>alert('Sorry!! You're not a user in the system');</script>";
			echo "<script type='text/javascript'> document.location = 'logout.php'; </script>";
		}
		if(isset($_POST['submit']))
		{
			try
			{
				$type=$_POST['type'];
				$reason=$_POST['reason'];
				$ExpenseName=$_POST['ExpenseName'];
				$officer = $_POST['officer'];
				$fee=$_POST['fee']; 
				$rdate=date('Y-m-d');
				$insert = new SchoolData();
				$sql="INSERT INTO tblexpenses(type,reason,officer,amount,rdate,cashier,ExpenseName) VALUES(:type,:reason,:officer,:amount,:rdate,:cashier,:ExpenseName)";
				$data=array(':type' => $type,':reason' => $reason,':officer'=>$officer, ':amount' => $fee,':rdate' => $rdate,':cashier' => $cashier,':ExpenseName' => $ExpenseName);
				if($insert->ExecSql($sql,$data)!==false)
				{
					$msg = "Expenses added successfully";
				}else{
					$error = "Something went wrong! Please try again";
				}
			}
			catch (PDOException $e)
			{
				exit("Error: " . $e->getMessage());
			}
		}
?>
<!DOCTYPE html>
<head>
<title><?php echo(isset(School()->SchoolName))? School()->SchoolName:"SMS"; ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="BoldTech School Mgt System, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- bootstrap-css -->
<link rel="stylesheet" href="css/bootstrap.min.css" >
<!-- //bootstrap-css -->
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href="css/style-responsive.css" rel="stylesheet"/>
<!-- font CSS -->
<link href='//fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
<!-- font-awesome icons -->
<link rel="stylesheet" href="css/font.css" type="text/css"/>
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons -->
<script src="js/jquery2.0.3.min.js"></script>
<link href="src/jquery.bootstrap-touchspin.css" rel="stylesheet" type="text/css" media="all">
<script src="src/jquery.bootstrap-touchspin.js"></script>
<script language=Javascript>
   <!--
   function isNumberKey(evt,element)
   {
	  var charCode = (evt.which) ? evt.which : evt.keyCode;
	  if ((charCode != 46 || $(element).val().indexOf('.') != -1) && charCode > 31 
		&& (charCode < 48 || charCode > 57))
		 return false;

	  return true;
   }
   //-->
</script>
<script>
function specExpen(val) {
$.ajax({
type: "POST",
url: "t.php",
data:'ExpenseName='+val,
success: function(data){
$("#acyearlvl2").html(data);

}
});
}
</script>

</head>
<body>
<section id="container">
<!--header start-->
<?php include('includes/topbar.php');?>
<!--header end-->
<!--sidebar start-->
<?php include('includes/sidebar.php');?>
<!--sidebar end-->
<!--main content start-->
<section id="main-content">
	<section class="wrapper">
		<div class="form-w3layouts">
            <!-- page start-->
            <div class="row">
                
    <div class="col-lg-12"> <section class="panel"> <header class="panel-heading"> 
      Add Expenses </header> 
      <div class="panel-body"> 
        <?php if($msg){?>
        <div class="alert alert-success left-icon-alert" role="alert"> <strong>Congrats 
          </strong> 
          <?php echo htmlentities($msg); ?>
        </div>
        <?php } 
else if($error){?>
        <div class="alert alert-danger left-icon-alert" role="alert"> <strong>Oh 
          snap! </strong> 
          <?php echo htmlentities($error); ?>
        </div>
        <?php } ?>
        <form class="form-horizontal" method="post" enctype="multipart/form-data">
          <div class="form-group"> 
				

            <label class="col-md-2 control-label">Expense Type</label>
				
            <div class="col-md-6"> 
              <div class="input-group"> <span class="input-group-addon"> <i class="fa fa-wpforms" aria-hidden="true"></i> 
                </span> 
                <select name="type" id="schoolname" required="required" onChange="specExpen(this.value);" class="form-control term">
                  <option value="">Select Expense Type</option>
                  <?php $sql = "SELECT id,ExpenseName from tblexpensetype";
					$query = $dbh->prepare($sql);
					$query->execute();
					$results=$query->fetchAll(PDO::FETCH_OBJ);
					if($query->rowCount() > 0)
					{
					foreach($results as $result)
					{   ?>
                  <option value="<?php echo htmlentities($result->ExpenseName); ?>"> 
                  <?php echo htmlentities($result->ExpenseName); ?>
                  </option>
                  <?php }} ?>
                </select>
              </div>
            </div>
          </div>
              <div id="acyearlvl2"></div>


              <div class="form-group"> 
                <label class="col-md-2 control-label">Description</label>
                <div class="col-md-6"> <input type="text" name="reason" id="shortname" value="" title="Description of the expenses" autocomplete="off" value="" class="form-control" placeholder="Description" required="required"> 
                </div>
              </div>
              <div class="form-group"> 
                <label class="col-md-2 control-label">Spending Officer</label>
                <div class="col-md-6"> 
                  <input type="text" name="officer" id="" autocomplete="off" value="" class="form-control" placeholder="Enter name of spending officer" required="required">
                </div>
              </div>
              <div class="form-group"> 
                <label class="col-md-2 control-label">Amount</label>
                <div class="col-md-6"> 
                  <div class="input-group"> <span class="input-group-addon"> <i class="fa fa-money" aria-hidden="true"></i> 
                    </span> 
                    <input type="text" value="" name="fee" class="form-control" id="fee" onkeypress="return isNumberKey(event,this)"  maxlength="10" required="required" autocomplete="off">
                  </div>
                </div>
              </div>
            </div>
          </div>










          <div class="form-group"> 
            <div class="col-md-9 col-md-offset-3"> 
              <button type="submit" name="submit" class="btn btn-success btn-labeled">Submit 
              <span class="btn-label btn-label-right"><i class="fa fa-save"></i></span></button>
            </div>
          </div>
        </form>
      </div>
      </section> </div>
</div>
<!-- page end-->
</div>
</section>
<!-- footer -->
<?php include('includes/footer.php');?>
  <!-- / footer -->
</section>
<!--main content end-->
</section>
<script src="js/bootstrap.js"></script>
<script src="js/jquery.dcjqaccordion.2.7.js"></script>
<script src="js/scripts.js"></script>
<script src="js/jquery.slimscroll.js"></script>
<script src="js/jquery.nicescroll.js"></script>
<script src="js/jquery.scrollTo.js"></script>
</body>
</html>
<?php }?>