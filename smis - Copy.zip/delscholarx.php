		<?php
session_start();
error_reporting(0);
include('includes/config.php');
			$cid=intval($_GET['id']);
			$sid=intval($_GET['sid']);
			$clid=intval($_GET['clid']);
			//$term=CurrentTerm();
            //$acyear=CurrentACYear();
			$bal=0;
			$username='kofi';
			$classid = 6;
			$studentid = $sid;
			$acyear = '2020/2021';
			$term = 'First';
			$dat= date('Y-m-d');
			$transtype='Cancel';
			$fee=ArrearsAmount1($sid);
			$reason='Cancellation of debt';
			$sql="INSERT INTO  tblfeepayment(stu_id,transtype,classid,term,initialamount,amount,Rdate,cashier,acyear,reason)
				VALUES(:studentid,:transtype,:classid,:term,:ini_fee,:amount,:Rdate,:cashier,:acyear,:reason)";
				$query = $dbh->prepare($sql);
			$query->bindParam(':studentid',$studentid,PDO::PARAM_STR);
			$query->bindParam(':transtype',$transtype,PDO::PARAM_STR);
			$query->bindParam(':classid',$classid,PDO::PARAM_STR);
			$query->bindParam(':term',$term,PDO::PARAM_STR);
			$query->bindParam(':ini_fee',$fee,PDO::PARAM_STR);
			$query->bindParam(':amount',$fee,PDO::PARAM_STR);
			$query->bindParam(':Rdate',$dat,PDO::PARAM_STR);
			$query->bindParam(':cashier',$username,PDO::PARAM_STR);
			$query->bindParam(':acyear',$acyear,PDO::PARAM_STR);
			$query->bindParam(':reason',$reason,PDO::PARAM_STR);
			$query->execute();
			//Update_Arrears1($sid,$bal,$dat);
			echo "<script> location.href='http://smis.fastlink.edu.gh/debt4give.php'; </script>";
		exit();
			
						
		?>