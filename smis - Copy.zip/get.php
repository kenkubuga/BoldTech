<?php
include('includes/config.php');
if(!empty($_POST["studclas"])):
$id= $_POST['studclas'];
$dta=explode("$",$id);
$hid=$dta[0];
$count=$dta[1];
$rid=$dta[2];
	if(RoomTypeCount($rid)!=0):
		if(!empty($hid)):
			$ini = substr($hid,0,1);
				$ini =strtoupper($ini);
				$rn= AnyRoomNumber($rid);
					if($count!=0):
					$numbers = preg_replace('/[^0-9]/', '', $rn);
					$letters = preg_replace('/[^a-zA-Z]/', '', $rn);
 ?>
					<?php for($a=1;$a<=$count;$a++):
					$initial=$letters.$a; ?>
						<div class="col-lg-2">
							<input type="text" value="<?php echo htmlentities($initial);?>" name="roomid[]" class="form-control">
						</div>
					<?php endfor;?>
<?php
					endif;
		endif;
	else:
		if(!empty($hid)):
			if($count!=0):
			 $ini = substr($hid,0,1);
				$ini =strtoupper($ini);
?>
			<div class="form-group">
				<label class="col-lg-2 control-label" for="inputSuccess">Rooms Numbers</label>
				<div class="col-lg-8">
				<span class="help-block"><i>Enter actual numbers/IDs for all the rooms that you have.</i></span>
					<div class="row">
					<?php for($a=1;$a<=$count;$a++):
					$inia=$ini.$a; ?>
						<div class="col-lg-2">
							<input type="text" value="<?php echo htmlentities($inia);?>" name="roomid[]" class="form-control">
						</div>
					<?php endfor;?>
					</div>
				</div>
			</div>
<?php 
			endif;
		endif;
	endif;
endif;
//////////////////////////////////////////////////////////////////////////////////////////
if(!empty($_POST["studclass"])):
$id= $_POST['studclass'];
$dta=explode("$",$id);
$hid=$dta[0];
$count=$dta[1];
if(!empty($hid)):
if($count!=0):
$ini = substr($hid,0,1);
$ini =strtoupper($ini);
?>
<div class="form-group">
	<label class="col-lg-2 control-label" for="inputSuccess">Rooms Numbers</label>
	<div class="col-lg-8">
	<span class="help-block"><i>Enter actual numbers/IDs for all the rooms that you have.</i></span>
		<div class="row">
		<?php for($a=1;$a<=$count;$a++):
		$inia=$ini.$a; ?>
			<div class="col-lg-2">
				<input type="text" value="<?php echo htmlentities($inia);?>" name="roomid[]" class="form-control">
			</div>
		<?php endfor;?>
		</div>
	</div>
</div>
<?php 
endif;
endif;
endif;
//////////////////////////////////////////////////////////////////////////
if(!empty($_POST["maxi"])):
$id= $_POST['maxi'];
$dta=explode("$",$id);
$max=$dta[0];
$kids=$dta[1];
$adults=$dta[2];
if($max!=0):
$total = $kids + $adults;
if($total>$max):
echo "<span style='color:red'><i> Adults + Kids are more than Max occupancy</i></span>";
 echo "<script>$('#submit').prop('disabled',true);</script>";
else:
echo "<script>$('#submit').prop('disabled',false);</script>"; 
endif;
endif;
endif;
////////////////////////////DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD
if(!empty($_POST["classid"])):
	$rid = $_POST['classid'];
	if(RoomAdults($rid)<=1):?>
		<option value="<?php echo htmlentities (RoomAdults($rid));?>">
		<?php echo htmlentities (RoomAdults($rid));?>
		</option>
		<?php 
	else:
		$adults = RoomAdults($rid);
		for($a=1;$a<=$adults;$a++):
		?><option value="<?php echo htmlentities ($a);?>">
		<?php echo htmlentities ($a);?>
		</option><?php
		endfor;
	endif;
endif;
////////////////////////////DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD
if(!empty($_POST["classid1"])):
	$rid = $_POST['classid1'];
	if(RoomChildren($rid)<=1):?>
		<option value="<?php echo htmlentities (RoomChildren($rid));?>">
		<?php echo htmlentities (RoomChildren($rid));?>
		</option>
		<?php 
	else:
		$adults = RoomChildren($rid);
		for($a=0;$a<=$adults;$a++):
		?><option value="<?php echo htmlentities ($a);?>">
		<?php echo htmlentities ($a);?>
		</option><?php
		endfor;
	endif;
endif;
////////////////////////////DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD
?>
