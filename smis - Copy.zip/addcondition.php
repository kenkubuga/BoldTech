<?php
session_start();
error_reporting(0);
include('includes/config.php');

DEFINE('BASENAMESS',basename(__FILE__));
if(strlen($_SESSION['alogin'])=="")
    {   
    header("Location: index.php"); 
    }else{
    
			$username=$_SESSION['alogin'];
			$classid = $_POST['name'];
			$studentid = $_POST['address'];
			$insert = new SchoolData();
			
			
			
			
						
						$sql="INSERT INTO tblcond(medical,edu)VALUES(:staffid,:classid)";
						$query = $dbh->prepare($sql);
						$query->bindParam(':staffid',$classid,PDO::PARAM_STR);
						$query->bindParam(':classid',$studentid,PDO::PARAM_STR);
						
						
						
				
						
						
						if($query->execute()==true)
						{
							header("location: students.php");
							}else{
								echo "error";
							}
							
							}
							
							
					
					
						
				
				
			
			

	
?>

