<?php
session_start();
error_reporting(0);
DEFINE('BASENAMESS',basename(__FILE__));
include('includes/config.php');
if(strlen($_SESSION['alogin'])=="")
    {   
    header("Location: index.php"); 
	}else{ if(isset($_GET['fid'])){ DEFINE('FID',$_GET['fid']);}else{ DEFINE('FID','');}
		if(isset($_GET['fid']))
		{
			$classDetails= FeeDetails(FID)->Classid;
			if($classDetails=="*")
			{
				$feeclassname="All";
			}else
			{
				$feeclassname=class_name($classDetails);
			}
		}
		if(isset($_POST['submit']))
		{ 
			$feename = clean($_POST['feename']);
			$fee = clean($_POST['fee']);
			$class = clean($_POST['class']);
			$level = clean($_POST['classid']);
			$id = clean($_GET['fid']);
			$insert = new SchoolData();
			$sql="UPDATE `tblfee` SET `FeeName`=:feename,`Fee`=:fee,`Classid`=:class,`LevelId`=:level WHERE (`id`=:id)";
			$data = array(':feename' => $feename,':fee' => $fee,':class' => $class,':level' => $level,':id' => $id);
			if($insert->ExecSql($sql,$data)!==false)
			{
				$class=FeeDetails(FID)->Classid;
				$level=FeeDetails(FID)->LevelId;
				if($class!="*")
				{
					$classfee = SumFee($class);
					$allclassfee = SumAllFee($level);
					$totalfee =$classfee+$allclassfee;
					$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
					$sql="UPDATE `stu_class` SET `class_total_fee`=:total WHERE (`class_id`=:classid) LIMIT 1";
					$query = $dbh->prepare($sql);
					$query->bindParam(':total',$totalfee,PDO::PARAM_STR);
					$query->bindParam(':classid',$class,PDO::PARAM_STR);
					$query->execute();
					$msg="Fee added successfully";
				}else
				{
					$stmt = $dbh->prepare("SELECT stu_class.class_id FROM stu_class WHERE stu_class.LevelId = :id");
					$stmt->execute(array(':id' => $level));
					while($row=$stmt->fetch(PDO::FETCH_ASSOC))
					{
						$classid=$row['class_id'];
						$classfee = SumFee($classid);
						$allclassfee = SumAllFee($level);
						$totalfee =$classfee+$allclassfee;
						$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
						$sql="UPDATE `stu_class` SET `class_total_fee`=:total WHERE (`class_id`=:classid) LIMIT 1";
						$query = $dbh->prepare($sql);
						$query->bindParam(':total',$totalfee,PDO::PARAM_STR);
						$query->bindParam(':classid',$classid,PDO::PARAM_STR);
						$query->execute();
					}
					$msg="Bill Updated successfully";
				}
			}
			else 
			{
				$error="Something went wrong. Please try again";
			}
		}
?>
<!DOCTYPE html>
<head>
<title><?php echo(isset(School()->SchoolName))? School()->SchoolName:"SMS"; ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Kasuli A-L Hotel Management System, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- bootstrap-css -->
<link rel="stylesheet" href="css/bootstrap.min.css" >
<!-- //bootstrap-css -->
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href="css/style-responsive.css" rel="stylesheet"/>
<!-- font CSS -->
<link href='//fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
<!-- font-awesome icons -->
<link rel="stylesheet" href="css/font.css" type="text/css"/>
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons -->
<script src="js/jquery2.0.3.min.js"></script>
  <link href="src/jquery.bootstrap-touchspin.css" rel="stylesheet" type="text/css" media="all">
  <script src="src/jquery.bootstrap-touchspin.js"></script>
	<script>
		function getAcyear(val) {
    $.ajax({
    type: "POST",
    url: "y.php",
    data:'billid='+val,
    success: function(data){
        $("#acyearlvl").html(data);
        
    }
    });
		$.ajax({
        type: "POST",
        url: "smsStudent.php",
        data:'classid1='+val,
        success: function(data){
            $("#subject").html(data);
            
        }
        });
}
    </script>
<script language=Javascript>
   <!--
   function isNumberKey(evt,element)
   {
	  var charCode = (evt.which) ? evt.which : evt.keyCode;
	  if ((charCode != 46 || $(element).val().indexOf('.') != -1) && charCode > 31 
		&& (charCode < 48 || charCode > 57))
		 return false;

	  return true;
   }
   //-->
</script>
</head>
<body>
<section id="container">
<!--header start-->
<?php include('includes/topbar.php');?>
<!--header end-->
<!--sidebar start-->
<?php include('includes/sidebar.php');?>
<!--sidebar end-->
<!--main content start-->
<section id="main-content">
	<section class="wrapper">
		<div class="form-w3layouts">
            <!-- page start-->
            <div class="row">
                <div class="col-lg-12">
                    <section class="panel">
                        <header class="panel-heading">
                            Update Bills
                        </header>
                        <div class="panel-body">
<?php if($msg){?>
<div class="alert alert-success left-icon-alert" role="alert">
 <strong>Well done! </strong><?php echo htmlentities($msg); ?>
 </div><?php } 
else if($error){?>
    <div class="alert alert-danger left-icon-alert" role="alert">
	<strong>Sorry! </strong> <?php echo htmlentities($error); ?>
</div>
<?php } ?>
		<form method="post" enctype="multipart/form-data" action="" class="form-horizontal">
			<div class="form-group">    
			<label class="col-md-2 control-label">Bill Name</label>
            <div class="col-md-6">
              <div class="input-group">             
                  <span class="input-group-addon">
              <i class="fa fa-user" aria-hidden="true"></i>
              </span>
              <input type="text" value="<?php echo(isset(FeeDetails(FID)->FeeName))? FeeDetails(FID)->FeeName:""; ?>" name="feename" class="form-control" id="feename" maxlength="50" required="required" autocomplete="off">
              </div>
            </div>
            </div>
			<div class="form-group">    
			<label class="col-md-2 control-label">Bill Amount</label>
            <div class="col-md-6">
              <div class="input-group">             
                  <span class="input-group-addon">
              <i class="fa fa-money" aria-hidden="true"></i>
              </span>
              <input type="text" value="<?php echo(isset(FeeDetails(FID)->Fee))? FeeDetails(FID)->Fee:""; ?>" name="fee" class="form-control" id="fee" onkeypress="return isNumberKey(event,this)"  maxlength="10" required="required" autocomplete="off">
              </div>
            </div>
            </div>
	<div class="form-group">    
	<label class="col-md-2 control-label">Level</label>
	<div class="col-md-6">
	  <div class="input-group">             
		  <span class="input-group-addon">
	  <i class="fa fa-wpforms" aria-hidden="true"></i>
	  </span>
	  <select name="classid" id="classid" required="" onChange="getAcyear(this.value);" class="form-control">
		  <option value="<?php echo(isset(FeeDetails(FID)->LevelId))? FeeDetails(FID)->LevelId:""; ?>"><?php echo(isset(FeeDetails(FID)->LevelId))? LevelName(FeeDetails(FID)->LevelId):"Select Level"; ?></option>
	<?php $sql = "SELECT id,LevelName from tbllevel";
	$query = $dbh->prepare($sql);
	$query->execute();
	$results=$query->fetchAll(PDO::FETCH_OBJ);
	if($query->rowCount() > 0)
	{
	foreach($results as $result)
	{   ?>
	<option value="<?php echo htmlentities($result->id); ?>"><?php echo htmlentities($result->LevelName); ?></option>
	<?php }} ?>
	 </select>
	  </div>
	</div>
	</div>
			<div class="form-group">    
			<label class="col-md-2 control-label">Class</label>
            <div class="col-md-6">
              <div class="input-group">             
                  <span class="input-group-addon">
              <i class="fa fa-cogs" aria-hidden="true"></i>
              </span>
              <select name="class" id="class" required="" class="form-control">
                <option value="<?php echo(isset(FeeDetails(FID)->Classid))? FeeDetails(FID)->Classid:""; ?>"><?php echo(isset($feeclassname))? $feeclassname:"Select Class"; ?></option>
              </select>
              </div>
            </div>
            </div>
		<div class="row">
			<div class="col-sm-8 col-sm-offset-3">
				<button type="submit" name="submit" class="btn-primary btn">Submit</button>
				<button type="reset" class="btn-inverse btn">Reset</button>
			</div>
		</div>
	</form>
			</div>
		</section>
	</div>
</div>
<!-- page end-->
</div>
</section>
<!-- footer -->
<?php include('includes/footer.php');?>
  <!-- / footer -->
</section>
<!--main content end-->
</section>
<script src="js/bootstrap.js"></script>
<script src="js/jquery.dcjqaccordion.2.7.js"></script>
<script src="js/scripts.js"></script>
<script src="js/jquery.slimscroll.js"></script>
<script src="js/jquery.nicescroll.js"></script>
<script src="js/jquery.scrollTo.js"></script>
</body>
</html>
<?php }?>