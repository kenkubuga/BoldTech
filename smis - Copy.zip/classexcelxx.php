<?php include_once('config.php'); include('Classes/PHPExcel.php');
$classid=$_GET['cid'];
$objPHPExcel	=	new	PHPExcel();
$result			=	$db->query("SELECT student.surname,
	student.stu_id,
	student.firstname,
	student.admission_year,
	stu_class.class_name,
	student.class,
	student.guardian_name,
	student.guardian_contact,
	student.fees_paid,
	student.`status`
	FROM
	student
	INNER JOIN stu_class ON student.class = stu_class.class_id
	WHERE 
	student.class = '$classid'") or die(mysql_error());

$objPHPExcel->setActiveSheetIndex(0);


$objPHPExcel->getActiveSheet()->SetCellValue('A1','Sch. Num');
	$objPHPExcel->getActiveSheet()->SetCellValue('B1','Student Name');
	$objPHPExcel->getActiveSheet()->SetCellValue('C1','Admission Year');
	$objPHPExcel->getActiveSheet()->SetCellValue('D1','Guardian Name');
	$objPHPExcel->getActiveSheet()->SetCellValue('E1','Guardian Contact');

$objPHPExcel->getActiveSheet()->getStyle("A1:E1")->getFont()->setBold(true);

$rowCount	=	2;
while($row	=	$result->fetch_assoc()){
	$objPHPExcel->getActiveSheet()->SetCellValue('A'.$rowCount, mb_strtoupper($row['stu_id'],'UTF-8'));
	$objPHPExcel->getActiveSheet()->SetCellValue('B'.$rowCount, mb_strtoupper($row['surname']." ".$row['firstname'],'UTF-8'));
	$objPHPExcel->getActiveSheet()->SetCellValue('C'.$rowCount, mb_strtoupper($row['admission_year'],'UTF-8'));
		$objPHPExcel->getActiveSheet()->SetCellValue('D'.$rowCount, mb_strtoupper($row['guardian_name'],'UTF-8'));
		$objPHPExcel->getActiveSheet()->SetCellValue('E'.$rowCount, mb_strtoupper($row['guardian_contact'],'UTF-8'));
		
	$rowCount++;
}


$objWriter	=	new PHPExcel_Writer_Excel2007($objPHPExcel);


header('Content-Type: application/vnd.ms-excel'); //mime type
header('Content-Disposition: attachment;filename="you-file-name.xlsx"'); //tell browser what's the file name
header('Cache-Control: max-age=0'); //no cache
$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');  
$objWriter->save('php://output');
?>