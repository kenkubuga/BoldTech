		<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(isset($_GET['sid']))
{
	$cid=intval($_GET['sid']);
	$sql="delete from tblsubject where id=:cid ";
	$query = $dbh->prepare($sql);
	$query->bindParam(':cid',$cid,PDO::PARAM_STR);
	$query->execute();
}
?>