<?php
include('includes/config.php');
if(!empty($_POST["classid"])) 
{
 $cid=intval($_POST['classid']);
 if(!is_numeric($cid)){
 
 	echo htmlentities("invalid Class");exit;
 }
 else{
 $stmt = $dbh->prepare("SELECT StudentName,IndexNo FROM tblstudents WHERE ClassId= :id order by StudentName");
 $stmt->execute(array(':id' => $cid));
 ?><option value="">Select Student </option><?php
 while($row=$stmt->fetch(PDO::FETCH_ASSOC))
 {
  ?>
  <option value="<?php echo htmlentities($row['IndexNo']); ?>"><?php echo htmlentities($row['StudentName']); ?></option>
  <?php
 }
}

}
// Code for Subjects
if(!empty($_POST["class100"])) 
{
 $id= $_POST['class100'];
 $dta=explode("$",$id);
$username1=$dta[0];
$cid=$dta[1];	
 $sql = "SELECT
tblclasses.id,
tblclasses.yearLvl,
tblclasses.Section
FROM
tblclasses
WHERE
tblclasses.ProgrammmeId = :stts AND
tblclasses.yearLvl = :cid";
$query = $dbh->prepare($sql);
$query-> bindParam(':stts',$username1, PDO::PARAM_STR);
$query-> bindParam(':cid',$cid, PDO::PARAM_STR);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
if($query->rowCount() > 0)
{
	 ?><option value="">Select Class</option><?php
foreach($results as $result)
{   ?>
<option value="<?php echo htmlentities($result->id); ?>"><?php echo htmlentities($result->yearLvl); ?><?php echo htmlentities($result->Section); ?></option>
<?php }
}
}
if(!empty($_POST["classid2"])) 
{
 $id= $_POST['classid2'];
 $dta=explode("$",$id);
$username1=$dta[0];
$cid=$dta[1];	
 $sql = "SELECT 
tblclassubject.ClassId,
tblclassubject.SubjectId,
tblsubjects.SubjectName
FROM
tblclassubject
INNER JOIN tblsubjects ON tblclassubject.SubjectId = tblsubjects.id
WHERE
tblclassubject.ClassId = :cid AND
tblclassubject.StaffId = :stts";
$query = $dbh->prepare($sql);
$query-> bindParam(':cid',$cid, PDO::PARAM_STR);
$query-> bindParam(':stts',$username1, PDO::PARAM_STR);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
if($query->rowCount() > 0)
{
	 ?><option value="">Select Subject</option><?php
foreach($results as $result)
{   ?>
<option value="<?php echo htmlentities($result->SubjectId); ?>"><?php echo htmlentities($result->SubjectName); ?></option>
<?php }
}
}
// Code for Subjects
if(!empty($_POST["classid1"])) 
{
 $cid1=intval($_POST['classid1']);
 if(!is_numeric($cid1)){
 
  echo htmlentities("invalid Class");exit;
 }
 else{
 $status=0;	
 $stmt = $dbh->prepare("SELECT tblsubjects.SubjectName,tblsubjects.id FROM tblsubjectcombination join  tblsubjects on  tblsubjects.id=tblsubjectcombination.SubjectId WHERE tblsubjectcombination.ClassId=:cid and tblsubjectcombination.status!=:stts order by tblsubjects.Status");
 $stmt->execute(array(':cid' => $cid1,':stts' => $status));
 ?>
 <div class="col-sm-6">
<table id="example" class="gridtable" cellspacing="0" width="100%">
 <?php
 while($row=$stmt->fetch(PDO::FETCH_ASSOC))
 {?>
<tr>
<td align=center>
  <b><?php echo htmlentities($row['SubjectName']); ?></b>
</td>
<td>
  <p>Class score(100%) <input type="text"  name="camarks[]" id="camarks[]" onkeypress="return isNumberKey(event,this)"  onchange="camarks(this);" value="" class="form-control groupOfTexbox" required="" placeholder="Enter Class Score" maxlength="5" autocomplete="off"></p><br>
  <p>Exam Score(100%) <input type="text"  name="endmarks[]" id="endmarks[]" onkeypress="return isNumberKey(event,this)" onchange="endmarks(this);" value="" class="groupOfTexbox form-control" required="" placeholder="Enter Exam Score" maxlength="5" autocomplete="off"></p>
</td>
</tr>
<?php  }
?>
</table>
</div><br>
<?php
}
}

if(!empty($_POST["studclass"])) 
{
 $id= $_POST['studclass'];
 $dta=explode("$",$id);
$cid=$dta[0];
$sid=$dta[1];
$yer=$dta[2];
$ter=$dta[3];
$ay=$dta[4];
$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
 $query = $dbh->prepare("SELECT
tblresult.yearLvl,
tblresult.Term,
tblresult.ClassId,
tblresult.StudentId,
tblresult.acyear
FROM
tblresult
WHERE
tblresult.yearLvl = :yr AND
tblresult.Term = :ter AND
tblresult.ClassId = :cid AND
tblresult.StudentId = :sid AND
tblresult.acyear = :ay");
//$query= $dbh -> prepare($sql);
//print_r($data);
$query-> bindParam(':cid', $cid, PDO::PARAM_STR);
$query-> bindParam(':sid', $sid, PDO::PARAM_STR);
$query-> bindParam(':yr', $yer, PDO::PARAM_STR);
$query-> bindParam(':ter', $ter, PDO::PARAM_STR);
$query-> bindParam(':ay', $ay, PDO::PARAM_STR);
$query-> execute();
$results = $query -> fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query -> rowCount() > 0)
{ 
?>
<p>
<?php
echo "<span style='color:red'> Results Already Published .</span>";
 echo "<script>$('#submit').prop('disabled',true);</script>";
 ?></p>
<?php }else{
	 echo "<script>$('#submit').prop('disabled',false);</script>";
}
}
/*========================================Allah is The Greatest===========*/ 
if(!empty($_POST["studclass1"])) 
{
 $id= $_POST['studclass1'];
 $dta=explode("$",$id);
$cid=$dta[0];
$sid=$dta[1];
$yer=GetYear($cid);
$ter=$dta[2];
$ay=$dta[3];
$suid=$dta[4];
$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
 $query = $dbh->prepare("SELECT
tblresult.yearLvl,
tblresult.Term,
tblresult.ClassId,
tblresult.StudentId,
tblresult.acyear
FROM
tblresult
WHERE
tblresult.yearLvl = :yr AND
tblresult.Term = :ter AND
tblresult.ClassId = :cid AND
tblresult.StudentId = :sid AND
tblresult.SubjectId = :suid AND
tblresult.acyear = :ay");
//$query= $dbh -> prepare($sql);
//print_r($data);
$query-> bindParam(':cid', $cid, PDO::PARAM_STR);
$query-> bindParam(':sid', $sid, PDO::PARAM_STR);
$query-> bindParam(':suid', $suid, PDO::PARAM_STR);
$query-> bindParam(':yr', $yer, PDO::PARAM_STR);
$query-> bindParam(':ter', $ter, PDO::PARAM_STR);
$query-> bindParam(':ay', $ay, PDO::PARAM_STR);
$query-> execute();
$results = $query -> fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query -> rowCount() > 0)
{ 
?>
<p>
<?php
echo "<span style='color:red'> Results Already Published .</span>";
 echo "<script>$('#submit').prop('disabled',true);</script>";
 echo "<script>$('#endmarks').prop('disabled',true);</script>";
 echo "<script>$('#camarks').prop('disabled',true);</script>";
 ?></p>
<?php }else{
	 echo "<script>$('#submit').prop('disabled',false);</script>";
	 echo "<script>$('#endmarks').prop('disabled',false);</script>";
	 echo "<script>$('#camarks').prop('disabled',false);</script>";
}
}
/*========================================Allah is The Greatest===========*/ 
if(!empty($_POST["studclass120"])) 
{
	$id= $_POST['studclass120'];
	$dta=explode("$",$id);
	$cid=$dta[0];
	$yer=GetYear($cid);
	$ter=$dta[1];
	$ay=$dta[2];
	$suid=$dta[3];
	if(!empty($cid) && !empty($ter) && !empty($ay) && !empty($suid))
	{
		$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$query = $dbh->prepare("SELECT
		tblstudents.IndexNo,
		tblstudents.StudentName
		FROM
		tblstudents
		WHERE
		tblstudents.ClassId = :cid
		ORDER BY
		tblstudents.IndexNo ASC");
		$query-> bindParam(':cid', $cid, PDO::PARAM_STR);
		$query-> execute();
		$results = $query -> fetchAll(PDO::FETCH_OBJ);
		$cnt=1;
		if($query -> rowCount() > 0)
		{ 
			?>
			<table class="gridtable" cellspacing="0" width="100%">
			<thead>
				<tr>
					<th>#</th>
					<th>Name</th>
					<th>School Num.</th>
					<th>Class Score(30%)</th>
					<th>Exam Score(70%)</th>
					<th>Total Score(100%)</th>
				</tr>
			</thead>
			<tbody>
			<?php
			foreach($results as $result)
			{
				$indexnno = $result->IndexNo;
				?>
				<tr>
				<?php if(studentresult_exist($indexnno,$cid,$ter,$ay,$suid)===true)
				{ ?>
					<td><?php echo htmlentities($cnt);?></td>
					<td><?php echo htmlentities($result->StudentName);?></td>
					<td><?php echo htmlentities($result->IndexNo);?></td>
					<td align="center"><?php echo htmlentities(ResultsData($indexnno,$ay,$suid,$ter)->camarks);?></td>
					<td align="center"><?php echo htmlentities(ResultsData($indexnno,$ay,$suid,$ter)->endmark);?></td>
					<td align="center"><?php echo htmlentities(ResultsData($indexnno,$ay,$suid,$ter)->marks);?></td>
				<?php 
				}else
				{ ?>
					<td><?php echo htmlentities($cnt);?></td>
					<td><?php echo htmlentities($result->StudentName);?></td>
					<td><?php echo htmlentities($result->IndexNo);?></td>
					<td colspan="3" align="center"><span style='color:red'> Student Results is not uploaded .</span></td>
				<?php 
				} ?>
				</tr>
				<?php
				$cnt=$cnt+1;
			}
			?>
			</tbody>
			</table><br>
			<?php
		}else
		{
			?>
			<div class="form-group">
			  <label for="date" class="col-sm-3 control-label "></label>
				<div class="col-sm-6">
					<div >
					<span style='color:red'> No Students in this class yet .</span>
					</div>
				</div>
			</div>
			<?php
		}
	}
}
/*========================================Allah is The Greatest===========*/ 
if(!empty($_POST["studclass12"])) 
{
	$id= $_POST['studclass12'];
	$dta=explode("$",$id);
	$cid=$dta[0];
	$yer=GetYear($cid);
	$ter=$dta[1];
	$ay=$dta[2];
	$suid=$dta[3];
	if(!empty($cid) && !empty($ter) && !empty($ay) && !empty($suid))
	{
		$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$query = $dbh->prepare("SELECT
		tblstudents.IndexNo,
		tblstudents.StudentName
		FROM
		tblstudents
		WHERE
		tblstudents.ClassId = :cid
		ORDER BY
		tblstudents.IndexNo ASC");
		$query-> bindParam(':cid', $cid, PDO::PARAM_STR);
		$query-> execute();
		$results = $query -> fetchAll(PDO::FETCH_OBJ);
		$cnt=1;
		if($query -> rowCount() > 0)
		{ 
			?>
			<table class="gridtable" cellspacing="0" width="100%">
			<thead>
				<tr>
					<th>#</th>
					<th>Name</th>
					<th>School Num.</th>
					<th>Class Score(100%)</th>
					<th>Exam Score(100%)</th>
				</tr>
			</thead>
			<tbody>
			<?php
			foreach($results as $result)
			{
				$indexnno = $result->IndexNo;
				?>
				<tr>
				<?php if(studentresult_exist($indexnno,$cid,$ter,$ay,$suid)===false)
				{ ?>
					<td><?php echo htmlentities($cnt);?></td>
					<td><?php echo htmlentities($result->StudentName);?></td>
					<td><?php echo htmlentities($result->IndexNo);?></td>
					<td><input type="text"  name="camarks[]" id="camarks[]" onkeypress="return isNumberKey(event,this)"  onchange="camarks(this);" value="" class="form-control" required="" placeholder="Enter Class Score" maxlength="5" autocomplete="off"></td>
					<td><input type="text"  name="endmarks[]" id="endmarks[]" onkeypress="return isNumberKey(event,this)" onchange="endmarks(this);" value="" class="form-control" required="" placeholder="Enter Exam Score" maxlength="5" autocomplete="off"></td>
				<?php 
				}else
				{ ?>
					<td><?php echo htmlentities($cnt);?></td>
					<td><?php echo htmlentities($result->StudentName);?></td>
					<td><?php echo htmlentities($result->IndexNo);?></td>
					<td colspan="2"><span style='color:red'> Student Results is already uploaded .</span></td>
				<?php 
				} ?>
				</tr>
				<?php
				$cnt=$cnt+1;
			}
			?>
			</tbody>
			</table><br>
			<?php
		}else
		{
			?>
			<div class="form-group">
			  <label for="date" class="col-sm-3 control-label "></label>
				<div class="col-sm-6">
					<div >
					<span style='color:red'> No Students in this class yet .</span>
					</div>
				</div>
			</div>
			<?php
		}
	}
}
 /*========================================Allah is The Greatest===========*/ 
 if(!empty($_POST["yearLvl"])) 
{
 $cid=intval($_POST['yearLvl']);
 if(!is_numeric($cid)){
 
 	echo htmlentities("invalid Class");exit;
 }
 else{
 $stmt = $dbh->prepare("SELECT
tblclasses.id,
tblclasses.yearLvl,
tblclasses.Section,
tblprogram.ProgramName
FROM
tblclasses
INNER JOIN tblprogram ON tblclasses.ProgrammmeId = tblprogram.id
WHERE tblclasses.yearLvl =:id");
 $stmt->execute(array(':id' => $cid));
 ?><option value="">Select Class </option><?php
 while($row=$stmt->fetch(PDO::FETCH_ASSOC))
 {
  ?>
  <option value="<?php echo htmlentities($row['id']); ?>"><?php echo htmlentities($row['ProgramName']); ?> <?php echo htmlentities($row['yearLvl']); ?><?php echo htmlentities($row['Section']); ?></option>
  <?php
 }
}

}
 /*========================================Allah is The Greatest===========*/ 
  ?>
