
<link href="../style.css" media="screen" rel="stylesheet" type="text/css" />
<form action="addcondition.php" method="post">
<center><h4> Add Medical/Education Status</h4></center>
<hr>
<div id="ac">
<input type="hidden" name="memi" value="" />
<span>Add Medical Condition : </span><input type="text" style="width:265px; height:30px;" name="name" value=""  /><br>
<span>Add Level of Education : </span><input type="text" style="width:265px; height:30px;" name="address" value="" /><br>

<div style="float:right; margin-right:10px;">

<button class="btn btn-success btn-block btn-large" style="width:50px; margin-right: 25px;"> Save </button>
</div>
</div>
</form>
