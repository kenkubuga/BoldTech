<?php
	// include config file
	include('includes/config.php');
	
	$id=$_GET['action'];
	$res=icrypt($id,'e');

	echo "<script type='text/javascript'> document.location = 'receipt.php?action=$res'; </script>";
?>