		<?php
session_start();
error_reporting(0);
include('includes/config.php');
		if(isset($_GET['cid']))
			{
			$sid=$_GET['cid'];
			$sql="delete from tblsubcombination where id=:sid ";
			$query = $dbh->prepare($sql);
			$query->bindParam(':sid',$sid,PDO::PARAM_STR);
			$query->execute();
			}
		?>