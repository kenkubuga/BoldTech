		<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(isset($_GET['sid'])){
	$fee = $_GET['sid'];
	$dta=explode("$",$fee);
	$feeid = $dta[0];
	$get_id = $dta[1];
	$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$date = date("Y-m-d H:i:s");
	$sql="DELETE FROM `paid_fees` WHERE (`id`=:ids) LIMIT 1";
	$query = $dbh->prepare($sql);
	$query->bindParam(':ids',$feeid,PDO::PARAM_STR);
	$query->execute();
	$stu_class_id = class_id($get_id);
	$stu_fees_paid = Total_fee_paid($get_id);
	$stu_class_fee = class_fee($stu_class_id);
	if($stu_fees_paid==$stu_class_fee)
	{
		$status = "Cleared";
	}elseif($stu_fees_paid<$stu_class_fee)
	{
		$status = "Owing";
	}else
	{
		$status = "Owed";
	}
		$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql="update  student set fees_paid=:fee,status=:status where stu_id = :sid";
		$query = $dbh->prepare($sql);
		$query->bindParam(':fee',$stu_fees_paid,PDO::PARAM_STR);
		$query->bindParam(':status',$status,PDO::PARAM_STR);
		$query->bindParam(':sid',$get_id,PDO::PARAM_STR);
		$query->execute();
		//query 2
		echo "<script type='text/javascript'> document.location = 'receipt.php?id=$get_id&f=$fee'; </script>";
}
		?>