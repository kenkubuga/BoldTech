<?php
session_start();
//error_reporting(0);
DEFINE('BASENAMESS',basename(__FILE__));
include('includes/config.php');
require_once "kasulixlsx.class.php";
$level=$_POST['classid'];
$class1=$_POST['acyearlvl'];
$term=$_POST['term'];
$aca=$_POST['acyear'];
if(strlen($_SESSION['alogin'])=="")
    {   
    header("Location: index.php"); 
    }
    else{
		if(isset($_POST['submit']))
		{
			$class1=clean($_POST['acyearlvl']);
			$class = clean($_POST['classid']);
			$acyearlvl = clean($_POST['acyearlvl']);
			$term = clean($_POST['term']);
			$acyear = clean($_POST['acyear']);
			$acyearlv = class_name($acyearlvl);
			$filename=$acyearlv.$term.$acyear;
			$filename = preg_replace('/\s+/', '', $filename);
			$filename = "uploads/".$filename.".xlsx";
			if (!file_exists($filename)) {
				echo "<script>alert('No results found for the selected class');</script>";
			echo "<script type='text/javascript'> document.location = 'classresult.php'; </script>";
			} else {
?>
<!DOCTYPE html>
<head>
<title><?php echo(isset(School()->SchoolName))? School()->SchoolName:"SMS"; ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Kasuli A-L Hotel Management System, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- bootstrap-css -->
<link rel="stylesheet" type="text/css" href="js/DataTables/datatables.min.css"/>

<link rel="stylesheet" href="css/bootstrap.min.css" >
<!-- //bootstrap-css -->
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href="css/style-responsive.css" rel="stylesheet"/>
<!-- font CSS -->
<link href='//fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
<!-- font-awesome icons -->
<link rel="stylesheet" href="css/kas.css" type="text/css"/>
<link rel="stylesheet" href="css/font.css" type="text/css"/>
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons -->
<script src="js/jquery2.0.3.min.js"></script>
<link href="src/jquery.bootstrap-touchspin.css" rel="stylesheet" type="text/css" media="all">
<script src="src/jquery.bootstrap-touchspin.js"></script>
<script type="text/javascript">
function printDiv(id) {
	var data=document.getElementById(id).innerHTML;
	var myWindow = window.open('', '<?php echo(isset(School()->SchoolName))? School()->SchoolName:"SMS"; ?>', 'height=4000,width=6000');
	myWindow.document.write('<html><head><title><?php echo(isset(School()->SchoolName))? School()->SchoolName:"SMS"; ?></title>');
	myWindow.document.write('<link rel="stylesheet" href="css/font-awesome.min.css" media="screen" >');
	myWindow.document.write('<link rel="stylesheet" href="css/bootstrap.min.css" type="text/css" />');
	myWindow.document.write('<link rel="stylesheet" href="css/font.css" media="screen" >');
	myWindow.document.write('<link rel="stylesheet" href="css/style-responsive.css" media="screen" >');
	myWindow.document.write('<link rel="stylesheet" href="css/style.css" type="text/css" />');
	myWindow.document.write('<link rel="stylesheet" href="css/kprint.css" type="text/css" />');
	myWindow.document.write('<link rel="stylesheet" href="css/kas.css" type="text/css" />');
	myWindow.document.write('</head><body >');
	myWindow.document.write(data);
	myWindow.document.write('</body></html>');
	myWindow.document.close();
	myWindow.onload=function(){
		myWindow.focus();
		myWindow.print();
		myWindow.close();
	};
}
</script>
<script>
function getMas(){
	alert ("Do not make any changes to this field");
}
</script>
<script>
function getAcyear(val) {
$.ajax({
type: "POST",
url: "y.php",
data:'classid='+val,
success: function(data){
$("#acyearlvl").html(data);

}
});
}
</script>
</head>
<body>
<section id="container">
<!--header start-->
<?php include('includes/topbar.php');?>
<!--header end-->
<!--sidebar start-->
<?php include('includes/sidebar.php');?>
<!--sidebar end-->
<!--main content start-->
<section id="main-content">
<section class="wrapper">
<div class="form-w3layouts">
<!-- page start-->
<div class="row">
    <div class="col-lg-12"> <section class="panel"> <header class="panel-heading"> 
      <?php
echo "SELECT STUDENT (S)";?>
      </header> 
      <div class="panel-body"> 
        <?php if($msg){?>
        <div class="alert alert-success left-icon-alert" role="alert"> <strong>Well 
          done! </strong> 
          <?php echo htmlentities($msg); ?>
        </div>
        <?php } 
else if($error){?>
        <div class="alert alert-danger left-icon-alert" role="alert"> <strong>Oh 
          snap! </strong> 
          <?php echo htmlentities($error); ?>
        </div>
        <?php } ?>
		<form method="post" enctype="multipart/form-data" action="arkeselapiresultsms.php" class="form-horizontal">
        
        <br>
        <div id ='result' class="noprint"> 
          <center>
            <b> 
            <?php echo htmlentities(strtoupper("You about sending ".class_name($acyearlvl)." Student results"));?>
            </b> 
          </center>
          <br>
          
		  
		  <div class="form-group" hidden> 
            <label class="col-md-2 control-label">Level</label>
            <div class="col-md-6"> 
              <div class="input-group"> <span class="input-group-addon"> <i class="fa fa-wpforms" aria-hidden="true"></i> 
                </span> 
                 <input type="hidden" name="levelid" id="levelid" value="<?php echo $level; ?>" class="form-control" placeholder="">
                <select name="classid1" id="classid1" required="required" onClick="getMas()" onBlur="getresult(this.value)" onChange="getAcyear(this.value);" class="form-control clid">
                  <option value=""></option>
				  <option value="<?php $level ;?>" selected><?php echo class_level($level);?></option>
                  
                </select>
              </div>
            </div>
          </div>
          <div class="form-group" hidden> 
            <label class="col-md-2 control-label">Class</label>
            <div class="col-md-6"> 
              <div class="input-group"> <span class="input-group-addon"> <i class="fa fa-bar-chart-o" aria-hidden="true"></i> 
                </span> 
                <select name="classid" id="classid" required="required" onClick="getMas()" onChange="getClass(this.value)" class="form-control acyearlvl">
				<option value=""></option>
				<option value="<?php echo $class1 ;?>" selected><?php echo class_name($class1) ;?></option>
                </select>
              </div>
            </div>
          </div>
          <div class="form-group" hidden> 
            <label class="col-md-2 control-label">Term</label>
            <div class="col-md-6"> 
              <div class="input-group"> <span class="input-group-addon"> <i class="fa fa-map-marker" aria-hidden="true"></i> 
                </span> 
                <select name="term" id="term" onChange="getresult(this.value)" onClick="getMas()" required="required" class="form-control term">
                  <option value=""></option>
				  <option value="<?php echo $term ;?>" selected><?php echo $term ;?></option>
                  
                </select>
              </div>
            </div>
          </div>
          <div class="form-group" hidden> 
            <label class="col-md-2 control-label">Academic Year</label>
            <div class="col-md-6"> 
              <div class="input-group"> <span class="input-group-addon"> <i class="fa fa-yoast" aria-hidden="true"></i> 
                </span> 
                <select name="acyear" id="acyear" onClick="getMas()" required="required" class="form-control acyear">
                
                  <option value=""></option>
                  <option value="<?php echo $aca ;?>" selected><?php echo $aca ;?></option>
                </select>
              </div>
            </div>
          </div>
       
		  <div class="form-group"> 
            <label class="col-md-2 control-label">Student</label>
            <div class="col-md-6"> 
              <div class="input-group"> <span class="input-group-addon"> <i class="fa fa-female" aria-hidden="true"></i> 
                </span> 
                <select name="studentid" id="studentid" required="required" class="form-control">
				<option value="">Select Student </option>
				<option value="*">All Students</option>
           <table id="example" class="gridtable" cellspacing="0" width="100%">
            <thead>
             <tr>
             <th>#</th>
             <th>Name</th>
             <th>Stud. ID</th>
          <?php
 $stmt = $dbh->prepare("SELECT
tblsubject.ShortName,
tblsubject.`Status`,
tblsubcombination.Classid
FROM
tblsubject
INNER JOIN tblsubcombination ON tblsubject.id = tblsubcombination.SubjectId
WHERE
tblsubcombination.Classid = :cid
ORDER BY
tblsubject.`Status` ASC");
 $stmt->execute(array(':cid' => $acyearlvl));
 $count=$stmt->rowCount();
 ?>
          
          <?php 

				$xlsx = KasuliXLSX::parse($filename);
		$sheetnames = $xlsx->sheetNames();
		$totalsheets=(sizeof($sheetnames)-9);

					for ($k = 0; $k <= $totalsheets-1; $k++)
					{ 
                echo "<th width='6%' style='text-align:center;'>".strtoupper(substr($sheetnames[$k],0,1)).strtolower(substr($sheetnames[$k],1,2))."</th>";?>
              <!--<th><?php //echo htmlentities($sheetnames[$k]);?></th>-->
              <th></th>
          
					<?php }?>
                     </tr>
                     </thead>
                 
                    <?php

			?>
              <tbody> 
              <tr>
                     <td ></td>
                     <td ></td>
                     <td ></td>
                     
                     <?php
					 $t=$totalsheets-1;
                      for ($k = 0; $k <= $totalsheets-1; $k++)
					{if($t==$k){?>
						    <td align="center" width="5%">Total </td>
                           <td align="center" width="5%">Position</td>
						  
                        <?php }else{ ?>
                            <td align="center" width="5%">Score </td>
                           <td align="center" width="5%">Grade</td>
                       <?php } ?>  
						   
                          
					<?php }?>
                     </tr>   
          <?php
	if ( $xlsx = KasuliXLSX::parse($filename) ) {
		$sheetnames = $xlsx->sheetNames();
		$totalsheets=(sizeof($sheetnames)-10);
		$sheetname = $xlsx->sheetNames();
		end($sheetname);
		$key = key($sheetname);
		$f = 0;
			foreach($xlsx->rows($key) as $result)
			{
						if ($f == 0)
						{
							$f++;
							continue;
						}
				$studentid =$result[0];
				$contact[]=$studentid;
	$new_message =implode(",",$contact);
				
				?>
				
				<option value="<?php echo htmlentities($result[0]);?>"> 
                  <?php echo htmlentities($result[1]);?>
                  </option>
				 
          <tr> 
         <td width="2%"></td>
            <td width="10.5%"> 
              <?php echo htmlentities($result[1]);?>
            </td>
           
            <td width="4%"> 
              <?php echo htmlentities($result[0]);?>
            </td>
            <?php 
				for ($k = 0; $k <= $totalsheets; $k++)
				{
					foreach ( $xlsx->rows($k) as $row ) 
					{
						if($row[0] == $studentid){?>
						   <td width='1.5%' align="center"> <?php echo ( ( isset( $row[4] ) ) ? $row[4] : '&nbsp;' ) ?></td>
						   <td width='1.5%'> <?php echo ( ( isset( $row[6] ) ) ? $row[6] : '&nbsp;' ) ?></td>
                           <?php
						 }
					}
				}
				?>
 
          </tr>
          <?php
			} ?>
			</select>
			
              </div>
            </div>
          </div>
          <div class="form-group" hidden>
															
                                                             <textarea class="form-control" rows="4" name="destinationAddress" id="destinationAddress" placeholder="Click on load contact" required><?php echo $new_message; ?></textarea>
															 
														</div>
          <?php 
	}else
	{
		$error = SimpleXLSX::parse_error();
	}
?></tbody>
          </table> </div>
      </div>
	  <div class="row"> 
            <div class="col-sm-8 col-sm-offset-2"> 
              <button type="submit" id="submit" name="submit" class="btn-primary btn">Submit</button>
              <button type="reset" class="btn-inverse btn">Reset</button>
            </div>
          </div>
	  </form>
      </section> </div>
</div>
<!-- page end-->
</div>
</section>
<!-- footer -->
<?php include('includes/footer.php');?>
  <!-- / footer -->
</section>
<!--main content end-->
</section>
<script src="js/bootstrap.js"></script>
<script src="js/jquery.dcjqaccordion.2.7.js"></script>
<script src="js/scripts.js"></script>
<script src="js/jquery.slimscroll.js"></script>
<script src="js/jquery.nicescroll.js"></script>
<!--[if lte IE 8]><script language="javascript" type="text/javascript" src="js/flot-chart/excanvas.min.js"></script><![endif]-->
<script src="js/jquery.scrollTo.js"></script>
<script src="js/DataTables/datatables.min.js"></script>

	<script type="text/javascript" language="javascript" src="js/DataTables/jquery.dataTables.min.js"></script>
	<script type="text/javascript" language="javascript" src="js/DataTables/dataTables.buttons.min.js"></script>
	<script type="text/javascript" language="javascript" src="js/DataTables/buttons.html5.min.js"></script>
	
	
<script>
	$(function($) {
		$('#example').DataTable({

			dom: 'Bfrtip',
			buttons: [
			{
                extend: 'excelHtml5',
                messageTop: '<?php echo " ".$term;?> <?php echo class_name($acyearlvl);?> CLASS RESULTS FOR  <?php echo $acyear; ?> ACADEMIC YEAR'
            },
				
				'csvHtml5',
				'pdfHtml5'
			],

			"pager": 150,
			"pageLength" : 100
			
		});
		
	});
</script>

</body>
</html>
	<?php 	}
		}
	}
?>