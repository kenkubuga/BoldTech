
<?php  

include('includes/config.php');
 require_once 'PHPExcel.php';
if(isset($_GET['cid']))
{
	$classid=$_GET['cid'];
	$objPHPExcel = new PHPExcel();
	$result = $dbh->prepare("SELECT
	student.surname,
	student.stu_id,
	student.firstname,
	student.admission_year,
	stu_class.class_name,
	student.class,
	student.guardian_name,
	student.guardian_contact,
	student.fees_paid,
	student.`status`
	FROM
	student
	INNER JOIN stu_class ON student.class = stu_class.class_id
	WHERE
	student.class = :class");
	$result->bindParam(':class', $classid);
	$result->execute();	

	$objPHPExcel = new PHPExcel();
	$ews = $objPHPExcel->getSheet(0);
	$ews->setTitle(class_name($classid));
	for ($col = ord('A'); $col <= ord('E'); $col++)
	{
		$ews->getColumnDimension(chr($col))->setAutoSize(true);
	}
	$header = 'A1:E1';
	$ews->getStyle($header)->getFill()->setFillType(\PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setARGB('00ffff00');
	$style = array(
    'font' => array('bold' => true,),
    'alignment' => array('horizontal' => \PHPExcel_Style_Alignment::HORIZONTAL_CENTER,),
    );
	$ews->getStyle($header)->applyFromArray($style);
	$rowCount = 2;
	$objPHPExcel->getActiveSheet()->SetCellValue('A1','Sch. Num');
	$objPHPExcel->getActiveSheet()->SetCellValue('B1','Student Name');
	$objPHPExcel->getActiveSheet()->SetCellValue('C1','Admission Year');
	$objPHPExcel->getActiveSheet()->SetCellValue('D1','Guardian Name');
	$objPHPExcel->getActiveSheet()->SetCellValue('E1','Guardian Contact');
 	for($i=0; $row = $result->fetch(); $i++){
		$objPHPExcel->getActiveSheet()->SetCellValue('A'.$rowCount, $row['stu_id']);
		$objPHPExcel->getActiveSheet()->SetCellValue('B'.$rowCount, $row['surname']." ".$row['firstname']);
		$objPHPExcel->getActiveSheet()->SetCellValue('C'.$rowCount, $row['admission_year']);
		$objPHPExcel->getActiveSheet()->SetCellValue('D'.$rowCount, $row['guardian_name']);
		$objPHPExcel->getActiveSheet()->SetCellValue('E'.$rowCount, $row['guardian_contact']);

		$rowCount++;
	}
	$filename = class_name($classid);
	$filename = preg_replace('/\s+/', '', $filename);
	header('Content-Type: application/vnd.openxmlformats-   officedocument.spreadsheetml.sheet');
	header('Content-Disposition: attachment;filename="'.$filename.'.xlsx"');
	header('Cache-Control: max-age=0');

	$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
	ob_end_clean();
	$objWriter->save('Allclasslist//'.$filename.'.xlsx');	
	$objPHPExcel->disconnectWorksheets();// Good to disconnect
	$objPHPExcel->garbageCollect(); // Trow every garbage away
	unset($objWriter, $objPHPExcel);

?>

<head>

<!-- bootstrap-css -->
<link rel="stylesheet" type="text/css" href="js/DataTables/datatables.min.css"/>
<link rel="stylesheet" href="css/bootstrap.min.css" >
<!-- //bootstrap-css -->
<!-- Custom CSS -->


<!-- font CSS -->
<link href='//fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
<!-- font-awesome icons -->
<link rel="stylesheet" href="css/kas.css" type="text/css"/>
<link rel="stylesheet" href="css/font.css" type="text/css"/>
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons -->
<script src="js/jquery2.0.3.min.js"></script>
<link href="src/jquery.bootstrap-touchspin.css" rel="stylesheet" type="text/css" media="all">
<script src="src/jquery.bootstrap-touchspin.js"></script>
</head>
<body>


<!--header end-->
<!--sidebar start-->

<!--sidebar end-->
<!--main content start-->
<section id="main-content">

	
            <!-- page start-->
            
                <div class="col-lg-8">
        
                        
<div style=" height: 100vh; text-align: center; " class="col-md-10">
                        <div><h3>Download Ready:</h3></div>
                        <table class="table table-hover table-responsive table-striped" id='jobappliedTable'>
                            <thead>
                            <th>Post Id</th>
                            <th>FileName</th>
                            
                            <th>Download File</th>
                            
                            
                            </thead>
                            <tbody>
                                
                             <?php 
        
                                
                                $resume=''.$filename.'.xlsx';
                               $mydoc= "$resume";
                                ?>
                                <tr>
                                    <td><?php echo 1;?></td>
                                    <td><?php echo $mydoc;?></td>
                                    
                                    <td><a href="Allclasslist/<?php echo $resume;?>" download><span class="glyphicon glyphicon-download"></span></a></td>
								
                                    
                                    
                                    
                                </tr>
                                
    
 
                              
                                
                            </tbody>
                        </table>
                        
                    </div>   
			
		
	</div>

<!-- page end-->


<!-- footer -->

  <!-- / footer -->
</section>
<!--main content end-->

<script src="js/bootstrap.js"></script>
<script src="js/jquery.dcjqaccordion.2.7.js"></script>
<script src="js/scripts.js"></script>
<script src="js/jquery.slimscroll.js"></script>
<script src="js/jquery.nicescroll.js"></script>
<!--[if lte IE 8]><script language="javascript" type="text/javascript" src="js/flot-chart/excanvas.min.js"></script><![endif]-->
<script src="js/jquery.scrollTo.js"></script>
<script type="text/javascript">
$(function() {
$(".sid").click(function(){
var element = $(this);
var del_id = element.attr("id");
var info = 'sid=' + del_id;
 if(confirm("Sure you want to delete this Student? There is NO undo!"))
		  {

 $.ajax({
   type: "GET",
   url: "delstudent.php",
   data: info,
   success: function(){ 
   
   }
 });
 $(this).parents(".record").animate({ backgroundColor: "#fbc7c7" }, "fast")
.animate({ opacity: "hide" }, "slow");
 }

return false;

});

});
</script>
<script src="js/DataTables/datatables.min.js"></script>
<script>
	$(function($) {
		$('#example').DataTable({
			"pageLength": 50
		});
		
		$('#example2').DataTable( {
			"scrollY":        "300px",
			"scrollCollapse": true,
			"paging":         false
		} );

		$('#example3').DataTable();
	});
</script>
</body>
</html>   
<?php } ?>