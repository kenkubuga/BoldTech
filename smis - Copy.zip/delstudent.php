		<?php
//session_start();
error_reporting(0);
include('includes/config.php');
			$cid=intval($_GET['sid']);
			$sql="delete from student where id=:cid ";
			$query = $dbh->prepare($sql);
			$query->bindParam(':cid',$cid,PDO::PARAM_STR);
			$q=$query->execute();
			if ($q) {
        	  echo "Student has been successfully deleted.";
        	} else {
        	  echo "Error occurred. Try again!!! ";
	}
		?>