		<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(isset($_GET['acid'])){
	$cid=intval($_GET['acid']);
	$sql="UPDATE `tblstaffrole` SET `Status`=0 WHERE (`id`=:cid) LIMIT 1";
	$query = $dbh->prepare($sql);
	$query->bindParam(':cid',$cid,PDO::PARAM_STR);
	$query->execute();
}
if(isset($_GET['deid'])){
	$cid=intval($_GET['deid']);
	$sql="UPDATE `tblstaffrole` SET `Status`=1 WHERE (`id`=:cid) LIMIT 1";
	$query = $dbh->prepare($sql);
	$query->bindParam(':cid',$cid,PDO::PARAM_STR);
	$query->execute();
}
?>