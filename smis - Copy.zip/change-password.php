<?php
session_start();
error_reporting(0);
include('includes/config.php');
DEFINE('BASENAMESS',basename(__FILE__));
if(strlen($_SESSION['alogin'])=="")
    {   
    header("Location: index.php"); 
    }
    else{
		if(isset($_POST['submit']))
		{
			$password=$_POST['password'];
			$newpassword=$_POST['newpassword'];
			$username=$_SESSION['alogin'];
			if(uname_exist1($username)===true)
			{
				if(IsAdmin($username, $password)===true)
				{
					$con="update user set password=:newpassword where username=:username";
					$chngpwd1 = $dbh->prepare($con);
					$chngpwd1-> bindParam(':username', $username, PDO::PARAM_STR);
					$chngpwd1-> bindParam(':newpassword', $newpassword, PDO::PARAM_STR);
					$chngpwd1->execute();
					$msg="Your Password succesfully changed";
				}
				else 
				{
					$error="Your current password is wrong";    
				}
			}elseif(staff_exist($username)===true)
			{
				if(IsStaff($username, $password)===true)
				{
					$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
					$con="UPDATE `staff` SET `password`=:newpassword WHERE (`username`=:indexno) LIMIT 1";
					$chngpwd1 = $dbh->prepare($con);
					$chngpwd1-> bindParam(':indexno', $username, PDO::PARAM_STR);
					$chngpwd1-> bindParam(':newpassword', $newpassword, PDO::PARAM_STR);
					$chngpwd1->execute();
					$msg="Password succesfully changed";	
				}else
				{
					$error="Your current password is wrong";
				}
			}else
			{
				echo "<script type='text/javascript'> document.location = 'logout.php'; </script>";
			}
		}
?>
<!DOCTYPE html>
<head>
<title><?php echo(isset(School()->SchoolName))? School()->SchoolName:"SMS"; ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Visitors Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- bootstrap-css -->
<link rel="stylesheet" href="css/bootstrap.min.css" >
<!-- //bootstrap-css -->
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href="css/style-responsive.css" rel="stylesheet"/>
<!-- font CSS -->
<link href='//fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
<!-- font-awesome icons -->
<link rel="stylesheet" href="css/font.css" type="text/css"/>
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons -->
<script src="js/jquery2.0.3.min.js"></script>
</head>
<body>
<section id="container">
<!--header start-->
<?php include('includes/topbar.php');?>
<!--header end-->
<!--sidebar start-->
<?php include('includes/sidebar.php');?>
<!--sidebar end-->
<!--main content start-->
<section id="main-content">
	<section class="wrapper">
	<div class="form-w3layouts">
        <!-- page start-->
        <!-- page start-->
        <div class="row">
                                    <div class="col-md-8 col-md-offset-2">
                                        <section class="panel">
                                            <div class="panel-heading">
                                                <header class="panel-title">
                                                    <h5>Change Password</h5>
                                                </header>
                                            </div>
           <?php if($msg){?>
<div class="alert alert-success left-icon-alert" role="alert">
 <strong>Well done!</strong><?php echo htmlentities($msg); ?>
 </div><?php } 
else if($error){?>
    <div class="alert alert-danger left-icon-alert" role="alert">
                                            <strong>Oh snap!</strong> <?php echo htmlentities($error); ?>
                                        </div>
                                        <?php } ?>
  
                                            <div class="panel-body">

                                                <form  name="chngpwd" method="post" \ onSubmit="return valid();">
                                                    <div class="form-group has-success">
                                                        <label for="success" class="control-label">Current Password</label>
                                                		<div class="">
                                    <input type="password" name="password" class="form-control" required="required" id="success">
                                                      
                                                		</div>
                                                	</div>
                                                       <div class="form-group has-success">
                                                        <label for="success" class="control-label">New Password</label>
                                                        <div class="">
                                                            <input type="password" name="newpassword" required="required" class="form-control" id="success">
                                                        </div>
                                                    </div>
                                                     <div class="form-group has-success">
                                                        <label for="success" class="control-label">Confirm Password</label>
                                                        <div class="">
                                                            <input type="password" name="confirmpassword" class="form-control" required="required" id="success">
                                                        </div>
                                                    </div>
  <div class="form-group has-success">

                                                        <div class="">
                                                           <button type="submit" name="submit" class="btn btn-success btn-labeled"><span class="btn-label btn-label-right"><i class="fa fa-check"></i></span> Change</button>
                                                    </div>


                                                    
                                                </form>

                                              
                                            </div>
                                        </div>
                                    </section>
                                    <!-- /.col-md-8 col-md-offset-2 -->
        <!-- page end-->
        </div>
</section>
 <!-- footer -->
<?php include('includes/footer.php');?>
  <!-- / footer -->
</section>

<!--main content end-->
</section>
<script src="js/bootstrap.js"></script>
<script src="js/jquery.dcjqaccordion.2.7.js"></script>
<script src="js/scripts.js"></script>
<script src="js/jquery.slimscroll.js"></script>
<script src="js/jquery.nicescroll.js"></script>
<!--[if lte IE 8]><script language="javascript" type="text/javascript" src="js/flot-chart/excanvas.min.js"></script><![endif]-->
<script src="js/jquery.scrollTo.js"></script>
<script>
function passwordeyes() {
    var x = document.getElementById("Psw").type;
    if(x=="password")
      document.getElementById("Psw").type="text";
    else
      document.getElementById("Psw").type="password";
}

</script>
</body>
</html>
<?PHP } ?>