<?php date_default_timezone_set("Africa/Accra"); ?>
<header class="header fixed-top clearfix">
<!--logo start-->
<div class="brand">
    <a href="pdashboard.php" class="logo">
	<img alt="" src="<?php echo(isset(School()->SchoolLogo))? "school/".School()->SchoolLogo:"school/logo.jpg"; ?>" style="width: 30px; height: 30px;" class="img-circle profile-img">
    <?php echo(isset(School()->SchoolShortName))? School()->SchoolShortName:"SMS"; ?>
    </a>
    <div class="sidebar-toggle-box">
        <div class="fa fa-bars"></div>
    </div>
</div>
<!--logo end-->
<?php
$username=$_SESSION['alogin'];
DEFINE('UID',$username);
?>
<div class="top-nav clearfix">
    <!--search & user info start-->
     <ul class="nav pull-right top-menu" style="float:right; margin-right:20px;">
        <!-- user login dropdown start-->
       
        <!-- user login dropdown start-->
        <li class="dropdown">
            <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                <img src="student/<?php echo htmlentities(StudentData(UID)->Photo);?>" style="width: 30px; height: 30px;" class="img-circle profile-img">
		
			    
                <b class="caret"></b>
            </a>
            <ul class="dropdown-menu extended logout">
                
                <li><a href="plogout.php"><i class="fa fa-sign-out"></i> Log Out</a></li>
            </ul>
        </li>
        
        <!-- user login dropdown end -->
    </ul>  
            </a>
            <ul class="dropdown-menu extended logout">
                
                <li><a href="logout.php"><i class="fa fa-sign-out"></i> Log Out</a></li>
            </ul>
        </li>
        <!-- user login dropdown end -->
    </ul>  
    <?php
 $stmt = $dbh->prepare("SELECT
*
FROM
student
WHERE
student.stu_id=:cid LIMIT 1
");
 $stmt->execute(array(':cid' => $username));
 $results=$stmt->fetchAll(PDO::FETCH_OBJ);
if($stmt->rowCount() > 0)
{
foreach($results as $result)
{ 
    ?>
    <div style="float:right; margin-right:20px;">
        <h3><?php echo htmlentities($result->surname);?> <?php echo htmlentities($result->firstname);?></h3>
    </div>
<?php    
}
}
 ?>
    
  
    <!--search & user info end-->
</div>
</header>
<!--header end-->