<?php
$username1=$_SESSION['alogin'];
?>
<!--sidebar start-->
<aside>
	<div id="sidebar" class="nav-collapse">
		<!-- sidebar menu start-->
		<div class="leftside-navigation">
			<ul class="sidebar-menu" id="nav-accordion">
				
				<li>
					<a href="pclassresultprev.php">
						<i class="fa fa-eye"></i>
						<span>View Results</span>
					</a>
				</li>
				<li>
					<a href="ptranshistorys.php">
						<i class="fa fa-money"></i>
						<span>Payment Record</span>
					</a>
				</li>
		
			</ul>
		</div>
	</div>
</aside>

