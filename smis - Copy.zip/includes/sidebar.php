<?php
$username1=$_SESSION['alogin'];
if(uname_exist1($username1)===true)
{
?>
	<!--sidebar start-->
	<aside>
		<div id="sidebar" class="nav-collapse">
			<!-- sidebar menu start-->
			<div class="leftside-navigation">
				<ul class="sidebar-menu" id="nav-accordion">
					<li>
						<a <?php if(BASENAMESS == "dashboard.php"){?>class="active"<?php }?> href="dashboard.php">
							<i class="fa fa-dashboard"></i>
							<span>Dashboard</span>
						</a>
					</li>
					<li>
						<a <?php if(BASENAMESS == "school.php"){?>class="active"<?php }?> href="school.php">
							<i class="fa fa-building-o"></i>
							<span>School Details</span>
						</a>
					</li>                
					<li class="sub-menu">
						<a <?php if(BASENAMESS == "classes.php" || BASENAMESS == "manage-class.php"){?>class="active"<?php }?> href="javascript:;">
							<i class="fa fa-columns"></i>
							<span>Class</span>
						</a>
						<ul class="sub">
							<li><a href="classes.php" <?php if(BASENAMESS == "classes.php"){?>class="active"<?php }?>>
							Add Class</a></li>
							<li><a <?php if(BASENAMESS == "manage-class.php"){?>class="active"<?php }?> href="manage-class.php">
							Manage Classes</a></li>
						</ul>
					</li>
					<li class="sub-menu">
						<a href="javascript:;">
							<i class="fa fa-file-text"></i>
							<span>Subject</span>
						</a>
						<ul class="sub">
							<li><a href="subjects.php">Add Subject</a></li>
							<li><a href="manage-subject.php">Manage Subjects</a></li>
							<li><a href="subjectcon.php">Add Subject combination</a></li>
							<li><a href="manage-consubject.php">Manage Subject combinations</a></li>
						</ul>
					</li>
					<li class="sub-menu">
						<a href="javascript:;">
							<i class="fa fa-male"></i>
							<span>Staff</span>
						</a>
						<ul class="sub">
							<li><a href="staffinfo.php">Add User</a></li>
							<li><a href="manage-staff.php">Manage Users</a></li>
							<li><a href="add-role.php">Assign Role</a></li>
							<li><a href="manage-role.php">Manage Roles</a></li>
							<li><a href="change-staff-password.php">Change User Password</a></li>
						</ul>
					</li>
					<li class="sub-menu">
						<a href="javascript:;">
							<i class="fa fa-users"></i>
							<span>Students</span>
						</a>
						<ul class="sub">
							<li><a href="students.php">Add Student</a></li>
							<li><a href="add-bulk-student.php">Add Bulk Student</a></li>
							<li><a href="manage-students.php">Manage Students</a></li>
						</ul>
					</li>
					<li class="sub-menu">
						<a href="javascript:;">
							<i class="fa fa-money"></i>
							<span>School Fees</span>
						</a>
						<ul class="sub">
							<li><a href="bills.php">Add Fee</a></li>
							<li><a href="manage-bills.php">Manage All Fees</a></li>
							<li><a href="scholar.php">Grant Scholarship </a></li>
							<li><a href="scholarships.php">Scholarships </a></li>
							<!--<li><a href="yearbill.php">Add Yearly bill </a></li>
							<li><a href="manage-yearbill.php">Yearly bills </a></li>-->
							<li><a href="optionalbill.php">Add Optional Fee </a></li>
							
							<li><a href="assignopt.php">Assign Optional Fee </a></li>
							
						</ul>
					</li>
					<li class="sub-menu">
						<a href="javascript:;">
							<i class="fa fa-money"></i>
							<span>Finance Department</span>
						</a>
						<ul class="sub">
							
							<li><a href="billpayment.php">Fee payment </a></li>
							<li><a href="otherInc.php">Other Income </a></li>
							<li><a href="billreverse.php">Reverse payment </a></li>
							<li><a href="allsummary.php">Payment Records </a></li>
							<li><a href="balsheet.php">Balance Sheet</a></li>
                            <li><a href="Allfeespaid.php">Overall Fee Payment Summary</a></li>
							<li><a href="nonfeeincst.php">Non Fee Income Statement</a></li>
							<li><a href="expense.php">Add Expenditure </a></li>
							<li><a href="todayexpenses.php">Today's expenses </a></li> 
						</ul>
					</li>
					<li class="sub-menu">
						<a href="javascript:;">
							<i class="fa fa-file-text-o"></i>
							<span>Academic Reports</span>
						</a>
						<ul class="sub">
							 <!-- <li id="menu-academico-avaliacoes" ><a href="term-info.php">Term Information</a></li> -->
							<li><a href="result-add.php">Upload Classs Results</a></li>
							<li><a href="printresult.php">Print Class Results</a></li>
							<li><a href="classresultprev.php">Print Last Academic Yr Report</a></li>
						</ul>
					</li>
					<li class="sub-menu">
						<a href="javascript:;">
							<i class="fa fa-folder-open-o"></i>
							<span>School Reports</span>
						</a>
						<ul class="sub">
							<li><a href="list_of_parents.php">List of Parents</a></li>
							<li><a href="list_of_staff.php">List of Staff</a></li>
                            <li><a href="students_statistics.php">Students Statistics</a></li>
							<li><a href="todaysummary.php">Today's payments </a></li> 
							<li><a href="classlist.php">Class List</a></li>
							<li><a href="classresult.php">Class Results</a></li>
							<li><a href="classresultwk.php">Weekly Class Results</a></li>
							<li><a href="debtors.php">Debtors</a></li>
							<li><a href="creditors.php">Creditors</a></li>
							<li><a href="payhistory.php">Fee Payment History</a></li>
							<li><a href="studentbill.php">Print Bill </a></li>
							<li><a href="manage-optionalbill.php">Optional Fees </a></li>
							<li><a href="assignopts.php">Students on Optional Fees </a></li>
							<li><a href="transhistory.php">Transactions history</a></li>
							<li><a href="allexpensedate.php">Expenditure Report </a></li>
						</ul>
					</li>  
				</ul>
			</div>
		</div>
	</aside>
<?php 
}elseif(staff_exist(UID)===true)
{
?>
<!--sidebar start-->
<aside>
	<div id="sidebar" class="nav-collapse">
		<!-- sidebar menu start-->
		<div class="leftside-navigation">
			<ul class="sidebar-menu" id="nav-accordion">
				<li>
					<a <?php if(BASENAMESS == "dashboard.php"){?>class="active"<?php }?> href="dashboard.php">
						<i class="fa fa-dashboard"></i>
						<span>Dashboard</span>
					</a>
				</li>
				<?php if(rolestatus('Role1',UID) == true){ ?>
					<li>
						<a <?php if(BASENAMESS == "school.php"){?>class="active"<?php }?> href="school.php">
							<i class="fa fa-building-o"></i>
							<span>School Details</span>
						</a>
					</li>
					<?php }?>
					
						<?php if(classgroup('Role2','Role3',UID) == true){ ?>
					<li class="sub-menu">
				
						<a <?php if(BASENAMESS == "classes.php" || BASENAMESS == "manage-class.php"){?>class="active"<?php }?> href="javascript:;">
							<i class="fa fa-columns"></i>
							<span>Class</span>
						</a>
						
						<ul class="sub">
						<?php if(rolestatus('Role2',UID) == "Yes"){ ?>
							<li><a href="classes.php" <?php if(BASENAMESS == "classes.php"){?>class="active"<?php }?>>
							Add Class</a></li>
							<?php }?>
							<?php if(rolestatus('Role3',UID) == "Yes"){ ?>
							<li><a <?php if(BASENAMESS == "manage-class.php"){?>class="active"<?php }?> href="manage-class.php">
							Manage Classes</a></li>
							<?php }?>
						</ul>
					</li>
					<?php }?>
					
					<?php if(subjectgroup('Role4','Role5','Role6','Role7',UID) == true){ ?>
					<li class="sub-menu">
					
						<a href="javascript:;">
							<i class="fa fa-file-text"></i>
							<span>Subject</span>
						</a>
						
						<ul class="sub">
						<?php if(rolestatus('Role4',UID) == "Yes"){ ?>
							<li><a href="subjects.php">Add Subject</a></li>
							<?php }?>
						<?php if(rolestatus('Role5',UID) == "Yes"){ ?>
							<li><a href="manage-subject.php">Manage Subjects</a></li>
							<?php }?>
						<?php if(rolestatus('Role6',UID) == "Yes"){ ?>
							<li><a href="subjectcon.php">Add Subject combination</a></li>
							<?php }?>
						<?php if(rolestatus('Role7',UID) == "Yes"){ ?>
							<li><a href="manage-consubject.php">Manage Subject combinations</a></li>
							<?php }?>
						</ul>
					</li>
					<?php }?>
					
					<?php if(staffgroup('Role8','Role9','Role10','Role11','Role12',UID) == true){ ?>
					<li class="sub-menu">
				
						<a href="javascript:;">
							<i class="fa fa-male"></i>
							<span>Staff</span>
						</a>
						
						<ul class="sub">
						<?php if(rolestatus('Role8',UID) == "Yes"){ ?>
							<!--<li><a href="staffinfo.php">Add User</a></li>-->
							<li><a href="adduserlist.php">Add User</a></li>
							<?php }?>
						<?php if(rolestatus('Role9',UID) == "Yes"){ ?>
							<li><a href="manage-staff.php">Manage Users</a></li>
							<?php }?>
						<?php if(rolestatus('Role10',UID) == "Yes"){ ?>
							<li><a href="add-role.php">Assign Role</a></li>
							<?php }?>
						<?php if(rolestatus('Role11',UID) == "Yes"){ ?>
							<li><a href="manage-role.php">Manage Roles</a></li>
							<?php }?>
						<?php if(rolestatus('Role12',UID) == "Yes"){ ?>
							<li><a href="change-staff-password.php">Change User Password</a></li>
							<?php }?>
						</ul>
					</li>
					<?php }?>
					
					<?php if(smsgroup('Role13','Role14','Role15','Role16','Role17',UID) == true){ ?>
					<li class="sub-menu">
					
						<a href="javascript:;">
							<i class="fa fa-male"></i>
							<span>SMS</span>
						</a>
						
						<ul class="sub">
						<?php if(rolestatus('Role13',UID) == "Yes"){ ?>
						    <li><a href="smsparentpro.php">SMS To All Parents</a></li>
							<?php }?>
						<?php if(rolestatus('Role14',UID) == "Yes"){ ?>
						    	<li><a href="smsstaffpro.php">SMS To All Staff</a></li>
								<?php }?>
						    	<!--<li><a href="smsclasspro1.php">SMS To Class</a></li>
						    	<li><a href="smsstaff2.php">SMS To All Staff</a></li>
							<li><a href="smsparent2.php">SMS To All Parents</a></li>
							<li><a href="smsstaff2.php">SMS To All Staff</a></li>
							<li><a href="smsdebtore2pro.php">SMS To Debtors</a></li>-->
						<?php if(rolestatus('Role15',UID) == "Yes"){ ?>
							<li><a href="smsclasspro1.php">SMS To Class</a></li>
							<?php }?>
							<?php if(rolestatus('Role15',UID) == "Yes"){ ?>
							<li><a href="classresultprevsms.php">Send Class Results To Parents</a></li>
							<?php }?>
						<?php if(rolestatus('Role16',UID) == "Yes"){ ?>
							<li><a href="smsdebtors1.php">SMS To Debtors</a></li>
							<?php }?>
						<?php if(rolestatus('Role17',UID) == "Yes"){ ?>
								<li><a href="smsbuycredit.php">Buy Credit</a></li>
								<?php }?>
						</ul>
					</li>
					<?php }?>
					
					
					<?php if(lessongroup('Role18','Role19','Role20','Role21','Role22',UID) == true){ ?>
					<li class="sub-menu">
				
						<a href="javascript:;">
							<i class="fa fa-male"></i>
							<span>Staff Assessment</span>
						</a>
					
						<ul class="sub">
						<?php if(rolestatus('Role18',UID) == "Yes"){ ?>
						<li><a href="staffsettings.php">Assign Staff Lessons</a></li>
						<?php }?>
						<?php if(rolestatus('Role19',UID) == "Yes"){ ?>
							<li><a href="viewstaffass.php">Manage Staff Lessons</a></li>
							<?php }?>
							<?php if(rolestatus('Role20',UID) == "Yes"){ ?>
							<li><a href="staffsettings1.php">Assign Suplementary Books </a></li>
							<?php }?>
							<?php if(rolestatus('Role21',UID) == "Yes"){ ?>
							<li><a href="viewstaffassbook.php">Manage Suplimentry Books</a></li>
							<?php }?>
							<?php if(rolestatus('Role22',UID) == "Yes"){ ?>
							<li><a href="viewstaffass1.php">Print Assessment Results</a></li>
							<?php }?>
							
						</ul>
					</li>
					<?php }?>
                     
                     <?php if(studentgroup('Role23','Role24','Role25','Role26','Role27','Role28','Role29','Role30','Role31',UID) == true){ ?>
					<li class="sub-menu">
					
						<a href="javascript:;">
							<i class="fa fa-users"></i>
							<span>Students</span>
						</a>
						
						<ul class="sub">
						<?php if(rolestatus('Role23',UID) == "Yes"){ ?>
							<li><a href="students.php">Add Student</a></li>
							<?php }?>
							<?php if(rolestatus('Role24',UID) == "Yes"){ ?>
							<li><a href="add-bulk-student">Add Bulk Student</a></li>
							<?php }?>
							<?php if(rolestatus('Role25',UID) == "Yes"){ ?>
							<li><a href="manage-students.php">Manage Students</a></li>
							<?php }?>
							<?php if(rolestatus('Role26',UID) == "Yes"){ ?>
                            <li><a href="promote-student.php">Promote Student</a></li>
							<?php }?>
							<?php if(rolestatus('Role27',UID) == "Yes"){ ?>
                            <li><a href="debitform3.php">Debit Student By Class</a></li>
							<?php }?>
							<?php if(rolestatus('Role28',UID) == "Yes"){ ?>
							<li><a href="debitform4.php">Debit Student By Level</a></li>
							<?php }?>
							<?php if(rolestatus('Role29',UID) == "Yes"){ ?>
							<li><a href="debitformstudent.php">Debit Student On Option</a></li>
							<?php }?>
							<?php if(rolestatus('Role30',UID) == "Yes"){ ?>
							<li><a href="debitoptionalreport.php">Optional Debit Report</a></li>
							<?php }?>
							<?php if(rolestatus('Role31',UID) == "Yes"){ ?>
							<li><a href="debitreport.php">Fees Debit Report</a></li>
							<?php }?>
						</ul>
					</li>
					<?php }?>
				
				<?php if(feesgroup('Role32','Role33','Role34','Role35',UID) == true){ ?>
					<li class="sub-menu">
					
						<a href="javascript:;">
							<i class="fa fa-money"></i>
							<span>Fees</span>
						</a>
						
						<ul class="sub">
						<?php if(rolestatus('Role32',UID) == "Yes"){ ?>
							<li><a href="bills.php">Add Fees</a></li>
							<?php }?>
							<?php if(rolestatus('Role33',UID) == "Yes"){ ?>
							<li><a href="manage-bills.php">Manage All Fees</a></li>
							<?php }?>
							<?php if(rolestatus('Role34',UID) == "Yes"){ ?>
							<li><a href="scholar.php">Grant Scholarship </a></li>
							<?php }?>
							<?php if(rolestatus('Role35',UID) == "Yes"){ ?>
							<li><a href="scholarships.php">Scholarships </a></li>
							<?php }?>
							
							<!--<li><a href="manage-studentsold2.php">Print Classlist </a></li>
							
							<li><a href="yearbill.php">Add Yearly bill </a></li>
							<li><a href="manage-yearbill.php">Yearly bills </a></li>
							<li><a href="optionalbill.php">Add Optional Fee </a></li>
							
							<li><a href="assignopt.php">Assign Optional Fee </a></li>-->
							
						</ul>
					</li>
					<?php }?>
					
					<?php if(financegroup('Role36','Role37','Role38','Role39','Role40','Role41','Role42','Role43','Role44','Role45','Role46',UID) == true){ ?>
					<li class="sub-menu">
					
						<a href="javascript:;">
							<i class="fa fa-money"></i>
							<span>Finance Department</span>
						</a>
					
						<ul class="sub">
						<?php if(rolestatus('Role36',UID) == "Yes"){ ?>
							<li><a href="billpayment.php">Fee payment </a></li>
							<?php }?>
							<?php if(rolestatus('Role37',UID) == "Yes"){ ?>
							<li><a href="otherInc.php">Other Income </a></li>
							<?php }?>
							<?php if(rolestatus('Role38',UID) == "Yes"){ ?>
							<li><a href="billreverse.php">Reverse payment </a></li> 
							<?php }?>
							<?php if(rolestatus('Role39',UID) == "Yes"){ ?>
							<li><a href="approve_reversal.php">Approve Reverse payment </a></li>
							<?php }?>	
							<?php if(rolestatus('Role40',UID) == "Yes"){ ?>						
							<li><a href="debt4give.php">Cancel Debt </a></li>
							<?php }?>
							<?php if(rolestatus('Role41',UID) == "Yes"){ ?>
							<li><a href="allsummary.php">Payment Record </a></li>
							<?php }?>
							<?php if(rolestatus('Role42',UID) == "Yes"){ ?>
							<li><a href="balsheet.php">Balance Sheet</a></li>
							<?php }?>
							<?php if(rolestatus('Role43',UID) == "Yes"){ ?>
                            <li><a href="Allfeespaid.php">Overall Fee Payment Summary</a></li>
							<?php }?>
							<?php if(rolestatus('Role44',UID) == "Yes"){ ?>
							<li><a href="nonfeeincst.php">Non Fee Income Statement</a></li>
							<?php }?>
							<?php if(rolestatus('Role45',UID) == "Yes"){ ?>
							<li><a href="expense.php">Add Expense </a></li>
							<?php }?>
							<?php if(rolestatus('Role46',UID) == "Yes"){ ?>
							<li><a href="todayexpenses.php">Today's expenses </a></li>
							<?php }?>
						</ul>
					</li>
						<?php }?>
					
					<?php if(ptagroup('Role47','Role48','Role49','Role50',UID) == true){ ?>
					<li class="sub-menu">
					
						<a href="javascript:;">
							<i class="fa fa-money"></i>
							<span>PTA & Non-Fee</span>
						</a>
						
						<ul class="sub">
						<?php if(rolestatus('Role47',UID) == "Yes"){ ?>
							<li><a href="debitptaclass.php">Debit PTA By Class</a></li>
							<?php }?>
							<?php if(rolestatus('Role48',UID) == "Yes"){ ?>
							<li><a href="debitptalevel.php">Debit PTA By Level</a></li>
							<?php }?>
							<?php if(rolestatus('Role49',UID) == "Yes"){ ?>
							<!--<li><a href="manage-bills.php">Debit On Books & Non-Fees</a></li>-->
							<li><a href="billpaymentpta.php">PTA Payment </a></li>
							<?php }?>
							<!--<li><a href="scholarships.php">Books & Non-Fees Payment</a></li>-->
							<!--<li><a href="yearbill.php">Add Yearly bill </a></li>
							<li><a href="manage-yearbill.php">Yearly bills </a></li>-->
							<?php if(rolestatus('Role50',UID) == "Yes"){ ?>
							<li><a href="debitptareport.php">PTA Report </a></li>
							<?php }?>
							<!--<li><a href="assignopt.php">Assign Optional Fee </a></li>
							<li><a href="debitform3.php">Debit Student</a></li>-->
							
						</ul>
					</li>
					<?php }?>
					
					<?php if(resultsgroup('Role51','Role52','Role48','Role54','Role55',UID) == true){ ?>
					<li class="sub-menu">
					
						<a href="javascript:;">
							<i class="fa fa-file-text-o"></i>
							<span>Results</span>
						</a>
						
						<ul class="sub">
							
<!-- 							<li><a href="termnal.php"> Term Information</a></li> -->
						<?php if(rolestatus('Role51',UID) == "Yes"){ ?>
							<li><a href="result-add.php">Add Termly Result</a></li>
							<?php }?>
							<?php if(rolestatus('Role52',UID) == "Yes"){ ?>
							<li><a href="printresult.php">Print Termly Results</a></li>
							<?php }?>
							<?php if(rolestatus('Role53',UID) == "Yes"){ ?>
							<li><a href="result-addwk.php">Add Weekly Result</a></li>
							<?php }?>
							<?php if(rolestatus('Role54',UID) == "Yes"){ ?>
							<li><a href="printresultwk.php">Print Weekly Results</a></li>
							<?php }?>
							<?php if(rolestatus('Role55',UID) == "Yes"){ ?>
						    <li><a href="classresultprev.php">Print Last Academic Yr Report</a></li>
							<?php }?>
						</ul>
					</li>
					<?php }?>
					
					<?php if(reportgroup('Role56','Role57','Role58','Role59','Role60','Role61','Role62','Role63','Role64','Role65','Role66','Role67','Role68','Role69','Role70',UID) == true){ ?>
					<li class="sub-menu">
					
						<a href="javascript:;">
							<i class="fa fa-folder-open-o"></i>
							<span>Reports</span>
						</a>
					
						<ul class="sub">
						<?php if(rolestatus('Role56',UID) == "Yes"){ ?>
							<li><a href="list_of_parents.php">List of Parents</a></li>
							<?php }?>
							<?php if(rolestatus('Role57',UID) == "Yes"){ ?>
							<li><a href="list_of_staff.php">List of Staff</a></li>
							<?php }?>
							<?php if(rolestatus('Role58',UID) == "Yes"){ ?>
                            <li><a href="students_statistics.php">Students Statistics</a></li>
							<?php }?>
							<?php if(rolestatus('Role59',UID) == "Yes"){ ?>
							<li><a href="todaysummary.php">Today's payments </a></li> 
							<?php }?>
							<?php if(rolestatus('Role60',UID) == "Yes"){ ?>
							<li><a href="classlist.php">Class List</a></li>
							<?php }?>
							<?php if(rolestatus('Role61',UID) == "Yes"){ ?>
							<li><a href="classlistbyadmission.php">Class List By Admission Date</a></li>
							<?php }?>
							<?php if(rolestatus('Role62',UID) == "Yes"){ ?>
 							<li><a href="classresult.php">Class Results</a></li>
							 <?php }?>
							 <?php if(rolestatus('Role63',UID) == "Yes"){ ?>
 							<li><a href="classresultwk.php">Weekly Class Results</a></li>
							 <?php }?>
							 <?php if(rolestatus('Role64',UID) == "Yes"){ ?>
							<li><a href="debtor.php">Debtors</a></li>
							<?php }?>
							<?php if(rolestatus('Role65',UID) == "Yes"){ ?>
							<li><a href="creditors.php">Creditors</a></li>
							<?php }?>
							<?php if(rolestatus('Role66',UID) == "Yes"){ ?>
							<li><a href="payhistory.php">Fee Payment History</a></li>
							<?php }?>
							<?php if(rolestatus('Role67',UID) == "Yes"){ ?>
							<li><a href="payhistory1.php">Fee Payment Check List</a></li>
							<?php }?>
							<?php if(rolestatus('Role68',UID) == "Yes"){ ?>
							<li><a href="studentbill.php">Print Bill </a></li>
							<?php }?>
							<?php if(rolestatus('Role69',UID) == "Yes"){ ?>
							<li><a href="transhistory.php">Transactions history</a></li>
							<?php }?>
							<?php if(rolestatus('Role70',UID) == "Yes"){ ?>
							<li><a href="allexpensedate.php">Expenditure Report </a></li>
							<?php }?>
						</ul>
					</li> 
					<?php }?>
			</u>	
		</div>
	</div>
</aside>
<?php
}else
{
	echo "<script type='text/javascript'> document.location = 'logout.php'; </script>";
}
?>