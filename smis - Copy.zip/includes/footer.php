<div class="footer noprint">
<div class="wthree-copyright noprint">
  <p align="center">Copy Rights © <?php echo date('Y');?> <?php echo(isset(School()->SchoolShortName))? School()->SchoolShortName:"SMS"; ?>. All rights reserved | Design by <a href="http://boldtechgh.com">BOLDTECH</a></p>
</div>
</div>