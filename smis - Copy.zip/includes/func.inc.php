<?php
/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
	function SchoolAdmin($username){
	global $msg, $dbh, $error;
	$sql_select = "SELECT tblstaffrole.RoleId FROM tblstaffrole WHERE tblstaffrole.RoleId = 1 AND tblstaffrole.username = ".$dbh->quote($username)." AND tblstaffrole.`Status`=0 LIMIT 1 ";
	$stmt = $dbh->query($sql_select);
 
	if($stmt === false){
		return NULL;
	}
	$r = $stmt->fetch(PDO::FETCH_ASSOC);
	if($r !== false){
		return true;
	}else
		return false;
}

/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
	function SystemAdmin($username){
	global $msg, $dbh, $error;
	$sql_select = "SELECT tblstaffrole.RoleId FROM tblstaffrole WHERE tblstaffrole.RoleId = 8 AND tblstaffrole.username = ".$dbh->quote($username)." AND tblstaffrole.`Status`=0 LIMIT 1 ";
	$stmt = $dbh->query($sql_select);
 
	if($stmt === false){
		return NULL;
	}
	$r = $stmt->fetch(PDO::FETCH_ASSOC);
	if($r !== false){
		return true;
	}else
		return false;
}


/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
	function getStaffID($username){
		global $msg, $dbh;
		$sql_select = "SELECT staff.staff_id,staff.username
				   FROM staff
				   WHERE username = " . $dbh->quote($username);
		$stmt = $dbh->query($sql_select);
		if($stmt === false){
			return NULL;
		}
		$r = $stmt->fetchAll(PDO::FETCH_OBJ);
		if($r !== false){
			foreach($r as $result)
		{
			$staffid = $result->staff_id;
		}
			return $staffid;
		}else
			return null;
}
/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
	function rolestatus($rolename,$username){
	global $msg, $dbh, $error;
	$staffID =getStaffID($username);
	$sql_select = "SELECT * FROM staff_assigned_roles WHERE staff_assigned_roles.StaffID = ".$dbh->quote($staffID)." AND  staff_assigned_roles.$rolename = 'Yes' LIMIT 1 ";
	$stmt = $dbh->query($sql_select);
 
	if($stmt === false){
		return NULL;
	}
	$r = $stmt->fetch(PDO::FETCH_ASSOC);
	if($r !== false){
		return true;
	}else
		return false;
}

/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
	function classgroup($role2,$role3,$username){
	global $msg, $dbh, $error;
	$staffID =getStaffID($username);
	$sql_select = "SELECT * FROM staff_assigned_roles WHERE staff_assigned_roles.StaffID = ".$dbh->quote($staffID)." AND 
	(staff_assigned_roles.$role2='Yes' OR staff_assigned_roles.$role3='Yes') LIMIT 1";
 $stmt = $dbh->query($sql_select);
	if($stmt === false){
		return NULL;
	}
	$r = $stmt->fetch(PDO::FETCH_ASSOC);
	if($r !== false){
		return true;
	}else
		return false;
}

/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
	function subjectgroup($role4,$role5,$role6,$role7,$username){
	global $msg, $dbh, $error;
	$staffID =getStaffID($username);
	$sql_select = "SELECT * FROM staff_assigned_roles WHERE staff_assigned_roles.StaffID = ".$dbh->quote($staffID)." AND 
	(staff_assigned_roles.$role4='Yes' OR staff_assigned_roles.$role5='Yes' OR staff_assigned_roles.$role6='Yes' OR staff_assigned_roles.$role7='Yes') LIMIT 1";
 $stmt = $dbh->query($sql_select);
	if($stmt === false){
		return NULL;
	}
	$r = $stmt->fetch(PDO::FETCH_ASSOC);
	if($r !== false){
		return true;
	}else
		return false;
}

/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
	function staffgroup($role8,$role9,$role10,$role11,$role12,$username){
	global $msg, $dbh, $error;
	$staffID =getStaffID($username);
	$sql_select = "SELECT * FROM staff_assigned_roles WHERE staff_assigned_roles.StaffID = ".$dbh->quote($staffID)." AND 
	(staff_assigned_roles.$role8='Yes' OR staff_assigned_roles.$role9='Yes' OR staff_assigned_roles.$role10='Yes' OR staff_assigned_roles.$role11='Yes' OR staff_assigned_roles.$role12='Yes') LIMIT 1";
 $stmt = $dbh->query($sql_select);
	if($stmt === false){
		return NULL;
	}
	$r = $stmt->fetch(PDO::FETCH_ASSOC);
	if($r !== false){
		return true;
	}else
		return false;
}

/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
	function smsgroup($role13,$role14,$role15,$role16,$role17,$username){
	global $msg, $dbh, $error;
	$staffID =getStaffID($username);
	$sql_select = "SELECT * FROM staff_assigned_roles WHERE staff_assigned_roles.StaffID = ".$dbh->quote($staffID)." AND 
	(staff_assigned_roles.$role13='Yes' OR staff_assigned_roles.$role14='Yes' OR staff_assigned_roles.$role15='Yes' OR staff_assigned_roles.$role16='Yes' OR staff_assigned_roles.$role17='Yes') LIMIT 1";
 $stmt = $dbh->query($sql_select);
	if($stmt === false){
		return NULL;
	}
	$r = $stmt->fetch(PDO::FETCH_ASSOC);
	if($r !== false){
		return true;
	}else
		return false;
}

/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
	function lessongroup($role18,$role19,$role20,$role21,$role22,$username){
	global $msg, $dbh, $error;
	$staffID =getStaffID($username);
	$sql_select = "SELECT * FROM staff_assigned_roles WHERE staff_assigned_roles.StaffID = ".$dbh->quote($staffID)." AND 
	(staff_assigned_roles.$role18='Yes' OR staff_assigned_roles.$role19='Yes' OR staff_assigned_roles.$role20='Yes' OR staff_assigned_roles.$role21='Yes' OR staff_assigned_roles.$role22='Yes') LIMIT 1";
 $stmt = $dbh->query($sql_select);
	if($stmt === false){
		return NULL;
	}
	$r = $stmt->fetch(PDO::FETCH_ASSOC);
	if($r !== false){
		return true;
	}else
		return false;
}

/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
	function studentgroup($role23,$role24,$role25,$role26,$role27,$role28,$role29,$role30,$role31,$username){
	global $msg, $dbh, $error;
	$staffID =getStaffID($username);
	$sql_select = "SELECT * FROM staff_assigned_roles WHERE staff_assigned_roles.StaffID = ".$dbh->quote($staffID)." AND 
	(staff_assigned_roles.$role23='Yes' OR staff_assigned_roles.$role24='Yes' OR staff_assigned_roles.$role25='Yes' OR staff_assigned_roles.$role26='Yes' OR staff_assigned_roles.$role27='Yes' OR staff_assigned_roles.$role28='Yes' OR staff_assigned_roles.$role29='Yes' OR staff_assigned_roles.$role30='Yes' OR staff_assigned_roles.$role31='Yes') LIMIT 1";
 $stmt = $dbh->query($sql_select);
	if($stmt === false){
		return NULL;
	}
	$r = $stmt->fetch(PDO::FETCH_ASSOC);
	if($r !== false){
		return true;
	}else
		return false;
}

/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
	function feesgroup($role32,$role33,$role34,$role35,$username){
	global $msg, $dbh, $error;
	$staffID =getStaffID($username);
	$sql_select = "SELECT * FROM staff_assigned_roles WHERE staff_assigned_roles.StaffID = ".$dbh->quote($staffID)." AND 
	(staff_assigned_roles.$role32='Yes' OR staff_assigned_roles.$role33='Yes' OR staff_assigned_roles.$role34='Yes' OR staff_assigned_roles.$role35='Yes') LIMIT 1";
 $stmt = $dbh->query($sql_select);
	if($stmt === false){
		return NULL;
	}
	$r = $stmt->fetch(PDO::FETCH_ASSOC);
	if($r !== false){
		return true;
	}else
		return false;
}

/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
	function financegroup($role36,$role37,$role38,$role39,$role40,$role41,$role42,$role43,$role44,$role45,$role46,$username){
	global $msg, $dbh, $error;
	$staffID =getStaffID($username);
	$sql_select = "SELECT * FROM staff_assigned_roles WHERE staff_assigned_roles.StaffID = ".$dbh->quote($staffID)." AND 
	(staff_assigned_roles.$role36='Yes' OR staff_assigned_roles.$role37='Yes' OR staff_assigned_roles.$role38='Yes' OR staff_assigned_roles.$role39='Yes'OR staff_assigned_roles.$role40='Yes' OR staff_assigned_roles.$role41='Yes' OR staff_assigned_roles.$role42='Yes'OR staff_assigned_roles.$role43='Yes'OR staff_assigned_roles.$role44='Yes' OR staff_assigned_roles.$role45='Yes' OR staff_assigned_roles.$role46='Yes') LIMIT 1";
 $stmt = $dbh->query($sql_select);
	if($stmt === false){
		return NULL;
	}
	$r = $stmt->fetch(PDO::FETCH_ASSOC);
	if($r !== false){
		return true;
	}else
		return false;
}

/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
	function ptagroup($role47,$role48,$role49,$role50,$username){
	global $msg, $dbh, $error;
	$staffID =getStaffID($username);
	$sql_select = "SELECT * FROM staff_assigned_roles WHERE staff_assigned_roles.StaffID = ".$dbh->quote($staffID)." AND 
	(staff_assigned_roles.$role47='Yes' OR staff_assigned_roles.$role48='Yes' OR staff_assigned_roles.$role49='Yes'OR staff_assigned_roles.$role50='Yes') LIMIT 1";
 $stmt = $dbh->query($sql_select);
	if($stmt === false){
		return NULL;
	}
	$r = $stmt->fetch(PDO::FETCH_ASSOC);
	if($r !== false){
		return true;
	}else
		return false;
}

/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
	function resultsgroup($role51,$role52,$role53,$role54,$role55,$username){
	global $msg, $dbh, $error;
	$staffID =getStaffID($username);
	$sql_select = "SELECT * FROM staff_assigned_roles WHERE staff_assigned_roles.StaffID = ".$dbh->quote($staffID)." AND 
	(staff_assigned_roles.$role51='Yes' OR staff_assigned_roles.$role52='Yes' OR staff_assigned_roles.$role53='Yes' OR staff_assigned_roles.$role54='Yes'OR staff_assigned_roles.$role55='Yes') LIMIT 1";
 $stmt = $dbh->query($sql_select);
	if($stmt === false){
		return NULL;
	}
	$r = $stmt->fetch(PDO::FETCH_ASSOC);
	if($r !== false){
		return true;
	}else
		return false;
}

/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
	function reportgroup($role56,$role57,$role58,$role59,$role60,$role61,$role62,$role63,$role64,$role65,$role66,$role67,$role68,$role69,$role70,$username){
	global $msg, $dbh, $error;
	$staffID =getStaffID($username);
	$sql_select = "SELECT * FROM staff_assigned_roles WHERE staff_assigned_roles.StaffID = ".$dbh->quote($staffID)." AND 
	(staff_assigned_roles.$role56='Yes' OR staff_assigned_roles.$role57='Yes' OR staff_assigned_roles.$role58='Yes' OR staff_assigned_roles.$role59='Yes'OR staff_assigned_roles.$role60='Yes' OR staff_assigned_roles.$role61='Yes' OR staff_assigned_roles.$role62='Yes' OR staff_assigned_roles.$role63='Yes'OR staff_assigned_roles.$role64='Yes' OR staff_assigned_roles.$role65='Yes' OR staff_assigned_roles.$role66='Yes' OR staff_assigned_roles.$role67='Yes'OR staff_assigned_roles.$role68='Yes' OR staff_assigned_roles.$role69='Yes'OR staff_assigned_roles.$role70='Yes') LIMIT 1";
 $stmt = $dbh->query($sql_select);
	if($stmt === false){
		return NULL;
	}
	$r = $stmt->fetch(PDO::FETCH_ASSOC);
	if($r !== false){
		return true;
	}else
		return false;
}

/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
	function IsCashier($username){
	global $msg, $dbh, $error;
	$sql_select = "SELECT tblstaffrole.RoleId FROM tblstaffrole WHERE tblstaffrole.RoleId = 3 AND tblstaffrole.username = ".$dbh->quote($username)." AND tblstaffrole.`Status`=0 LIMIT 1 ";
	$stmt = $dbh->query($sql_select);
 
	if($stmt === false){
		return NULL;
	}
	$r = $stmt->fetch(PDO::FETCH_ASSOC);
	if($r !== false){
		return true;
	}else
		return false;
}


/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
	function IsClk($username){
	global $msg, $dbh, $error;
	$sql_select = "SELECT tblstaffrole.RoleId FROM tblstaffrole WHERE tblstaffrole.RoleId = 6 AND tblstaffrole.username = ".$dbh->quote($username)." AND tblstaffrole.`Status`=0 LIMIT 1 ";
	$stmt = $dbh->query($sql_select);
 
	if($stmt === false){
		return NULL;
	}
	$r = $stmt->fetch(PDO::FETCH_ASSOC);
	if($r !== false){
		return true;
	}else
		return false;
}
/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
	function IsTeacher($username){
	global $msg, $dbh, $error;
	$sql_select = "SELECT tblstaffrole.RoleId FROM tblstaffrole WHERE tblstaffrole.RoleId = 2 AND tblstaffrole.username = ".$dbh->quote($username)." LIMIT 1 ";
	$stmt = $dbh->query($sql_select);
 
	if($stmt === false){
		return NULL;
	}
	$r = $stmt->fetch(PDO::FETCH_ASSOC);
	if($r !== false){
		return true;
	}else
		return false;
}
/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
	function IsClerk($username){
	global $msg, $dbh, $error;
	$sql_select = "SELECT tblstaffrole.RoleId FROM tblstaffrole WHERE tblstaffrole.RoleId = 6 AND tblstaffrole.username = ".$dbh->quote($username)." LIMIT 1 ";
	$stmt = $dbh->query($sql_select);
 
	if($stmt === false){
		return NULL;
	}
	$r = $stmt->fetch(PDO::FETCH_ASSOC);
	if($r !== false){

		return true;
	}else		return false;
}
/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
	function IsHeadteacher($username){
	global $msg, $dbh, $error;
	$sql_select = "SELECT tblstaffrole.RoleId FROM tblstaffrole WHERE tblstaffrole.RoleId = 7 AND tblstaffrole.username = ".$dbh->quote($username)." LIMIT 1 ";
	$stmt = $dbh->query($sql_select);
 
	if($stmt === false){
		return NULL;
	}
	$r = $stmt->fetch(PDO::FETCH_ASSOC);
	if($r !== false){

		return true;
	}else		return false;
}
/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
	function IsDirector($username){
	global $msg, $dbh, $error;
	$sql_select = "SELECT tblstaffrole.RoleId FROM tblstaffrole WHERE tblstaffrole.RoleId = 5 AND tblstaffrole.username = ".$dbh->quote($username)." AND tblstaffrole.`Status`=0 LIMIT 1 ";
	$stmt = $dbh->query($sql_select);
 
	if($stmt === false){
		return NULL;
	}
	$r = $stmt->fetch(PDO::FETCH_ASSOC);
	if($r !== false){
		return true;
	}else
		return false;
}
/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
function IsParentold($username){
	global $msg, $dbh, $error;
	$sql_select = "SELECT staff.role FROM staff WHERE staff.role = 4 AND staff.username = ".$dbh->quote($username)." LIMIT 1 ";
	$stmt = $dbh->query($sql_select);
 
	if($stmt === false){
		return NULL;
	}
	$r = $stmt->fetch(PDO::FETCH_ASSOC);
	if($r !== false){
		return true;
	}else
		return false;
}

	function IsParent($username){
	global $msg, $dbh, $error;
	$sql_select = "SELECT student.stu_id FROM student WHERE student.stu_id = ".$dbh->quote($username)." LIMIT 1 ";
	$stmt = $dbh->query($sql_select);
 
	if($stmt === false){
		return NULL;
	}
	$r = $stmt->fetch(PDO::FETCH_ASSOC);
	if($r !== false){
		return true;
	}else
		return false;
}

/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
	function CheckStatus($username){
	global $msg, $dbh, $error;
	$sql_select = "SELECT tblstaffrole.Status FROM tblstaffrole WHERE tblstaffrole.`Status`=0 AND tblstaffrole.username = ".$dbh->quote($username)." LIMIT 1";
	$stmt = $dbh->query($sql_select);
 
	if($stmt === false){
		return NULL;
	}
	$r = $stmt->fetch(PDO::FETCH_ASSOC);
	if($r !== false){
		return true;
	}else
		return false;
}
/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
function OptSum($fid){
		global $msg, $dbh,$OptSumss;
		$OptSumss=0;
		$sql_select = "SELECT
		Sum(tbloptbill.BillAmount) AS BillAmount
		FROM
		tbloptbill
		INNER JOIN tbloptionalstudent ON tbloptionalstudent.BillId = tbloptbill.id
		WHERE
		tbloptionalstudent.stu_id = ".$dbh->quote($fid);
		$stmt = $dbh->query($sql_select);
		if($stmt === false){
			return NULL;
		}
		$r = $stmt->fetchAll(PDO::FETCH_OBJ);
		if($r !== false){
			foreach($r as $feess){
				$OptSumss=$feess->BillAmount;
			}
			return $OptSumss;
		}else
			return $OptSumss;
}
/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
function SumPenalty($fid){
		global $msg, $dbh,$SumPenaltyss;
		$SumPenaltyss=0;
		$sql_select = "SELECT
		Sum(tblpenalty.Amount) AS Penalty
		FROM
		tblpenalty
		WHERE
		tblpenalty.stu_id =".$dbh->quote($fid)."AND
		tblpenalty.`Status` = 0";
		$stmt = $dbh->query($sql_select);
		if($stmt === false){
			return NULL;
		}
		$r = $stmt->fetchAll(PDO::FETCH_OBJ);
		if($r !== false){
			foreach($r as $feess){
				$SumPenaltyss=$feess->Penalty;
			}
			return $SumPenaltyss;
		}else
			return $SumPenaltyss;
}
/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
function YearLyBills(){
		global $msg, $dbh,$YearLyBills;
		$YearLyBills=0;
		$sql_select = "SELECT
		Sum(tblyearlybill.BillAmount) AS Yearlybill
		FROM
		tblyearlybill";
		$stmt = $dbh->query($sql_select);
		if($stmt === false){
			return NULL;
		}
		$r = $stmt->fetchAll(PDO::FETCH_OBJ);
		if($r !== false){
			foreach($r as $fe){
				$YearLyBills = $fe->Yearlybill;
			}
			return $YearLyBills;
		}else
			return $YearLyBills;
}
/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
	function arrears_exist($indexno){
	global $msg, $dbh, $error;
 
	$sql_select = "SELECT stu_id
		       FROM studentaccount
		       WHERE stu_id = " . $dbh->quote($indexno) . "
		       LIMIT 1";
 
	$stmt = $dbh->query($sql_select);
 
	if($stmt === false){
		return NULL;
	}
	$r = $stmt->fetch(PDO::FETCH_ASSOC);
	if($r !== false){
		return true;
	}else
		return false;
}

function todaypay_exist($studentid,$fee,$Rdate){
	global $msg, $dbh, $error;
 
	$sql_select = "SELECT *
		       FROM tblfeepayment
		       WHERE stu_id = " . $dbh->quote($studentid) . " AND amount = " . $dbh->quote($fee) . " AND Rdate = " . $dbh->quote($Rdate) . " AND transtype='Credit'
		       ORDER BY id DESC";
 
	$stmt = $dbh->query($sql_select);
 
	if($stmt === false){
		return NULL;
	}
	$r = $stmt->fetch(PDO::FETCH_ASSOC);
	if($r !== false){
		return true;
	}else
		return false;
}

function todaypay_reverse($studentid,$Rdate){
	global $msg, $dbh, $error;
 
	$sql_select = "SELECT *
		       FROM tblfeepayment
		       WHERE stu_id = " . $dbh->quote($studentid) . " AND Rdate = " . $dbh->quote($Rdate) . " AND transtype='Credit'
		       ORDER BY id DESC";
 
	$stmt = $dbh->query($sql_select);
 
	if($stmt === false){
		return NULL;
	}
	$r = $stmt->fetch(PDO::FETCH_ASSOC);
	if($r !== false){
		return true;
	}else
		return false;
}

/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
	function NewPrevArrearsAmount($cid){
		global $msg, $dbh;
		$arrears=0.00;
		$accyearl = '2018/2019';
		$terml='Third';
		$sql_select = "SELECT term, accyear, arrears
				   FROM tblarrears
				   WHERE stu_id = " . $dbh->quote($cid) . "
				   AND accyear = '$accyearl' AND term = '$terml' " ;
		$stmt = $dbh->query($sql_select);
		if($stmt === false){
			return NULL;
		}
		$r = $stmt->fetchAll(PDO::FETCH_OBJ);
		if($r !== false){
			foreach($r as $result)
		{
			$prevarrears = $result->arrears;
		}
			return $prevarrears;
		}else
			return null;
}
/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
	function ArrearsAmount($cid){
		global $msg, $dbh;
		$arrears=0.00;
		$sql_select = "SELECT arrears
				   FROM tblarrears
				   WHERE stu_id = " . $dbh->quote($cid) . "
				   LIMIT 1";
		$stmt = $dbh->query($sql_select);
		if($stmt === false){
			return NULL;
		}
		$r = $stmt->fetchAll(PDO::FETCH_OBJ);
		if($r !== false){
			foreach($r as $result)
		{
			$arrears = $result->arrears;
		}
			return $arrears;
		}else
			return null;
}

/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
	function ArrearsAmount1($cid){
		global $msg, $dbh;
		$arrears=0.00;
		$sql_select = "SELECT amount
				   FROM studentaccount
				   WHERE stu_id = " . $dbh->quote($cid) . "
				   LIMIT 1";
		$stmt = $dbh->query($sql_select);
		if($stmt === false){
			return NULL;
		}
		$r = $stmt->fetchAll(PDO::FETCH_OBJ);
		if($r !== false){
			foreach($r as $result)
		{
			$arrears = $result->amount;
		}
			return $arrears;
		}else
			return null;
}

/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
	function ArrearsAmountpta($cid){
		global $msg, $dbh;
		$arrears=0.00;
		$sql_select = "SELECT amount
				   FROM studentaccountpta
				   WHERE stu_id = " . $dbh->quote($cid) . "
				   LIMIT 1";
		$stmt = $dbh->query($sql_select);
		if($stmt === false){
			return NULL;
		}
		$r = $stmt->fetchAll(PDO::FETCH_OBJ);
		if($r !== false){
			foreach($r as $result)
		{
			$arrears = $result->amount;
		}
			return $arrears;
		}else
			return null;
}


/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
	function PrevArrearsAmount($cid){
		global $msg, $dbh;
		$arrears=0.00;
		$accyearl = CurrentACYear();
		$terml=CurrentTerm();
		$sql_select = "SELECT term, accyear, arrears
				   FROM tblarrears
				   WHERE stu_id = " . $dbh->quote($cid) . "
				   AND accyear != '$accyearl' OR stu_id = " . $dbh->quote($cid) . " AND accyear = '$accyearl' AND term != '$terml' " ;
		$stmt = $dbh->query($sql_select);
		if($stmt === false){
			return NULL;
		}
		$r = $stmt->fetchAll(PDO::FETCH_OBJ);
		if($r !== false){
			foreach($r as $result)
		{
			$prevarrears = $result->arrears;
		}
			return $prevarrears;
		}else
			return null;
}
/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
	function ArrearsTerm($cid){
		global $msg, $dbh, $ArrearsTermss;
		$sql_select = "SELECT term
				   FROM tblarrears
				   WHERE stu_id = " . $dbh->quote($cid) . "
				   LIMIT 1";
		$stmt = $dbh->query($sql_select);
		if($stmt === false){
			return NULL;
		}
		$r = $stmt->fetchAll(PDO::FETCH_OBJ);
		if($r !== false){
			foreach($r as $result)
		{
			$ArrearsTermss = $result->term;
		}
			return $ArrearsTermss;
		}else
			return null;
}


/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
function NewScholarStudent($id){
		global $msg, $dbh,$ScholarStudent111;
		$sql_select = "SELECT
					tblscholar.stu_id,
					tblscholar.scholarAmount
					from tblscholar where
					tblscholar.stu_id= " . $dbh->quote($id) . "
					LIMIT 1";
		$stmt = $dbh->query($sql_select);
		if($stmt === false){
			return NULL;
		}
		$r = $stmt->fetchAll(PDO::FETCH_OBJ);
		if($r !== false){
			foreach($r as $ScholarStudent111)
		{
			
		}
			return $ScholarStudent111;
		}else
			return null;
}


/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
function ScholarStudent($id){
		global $msg, $dbh,$ScholarStudent111;
		$sql_select = "SELECT
					tblscholar.stu_id,
					student.surname,
					student.firstname,
					student.guardian_name,
					student.class,
					student.stu_id,
					tblscholartype.scholarType,
					tblscholar.scholarId,
					tblscholar.id,
					stu_class.class_name,
					stu_class.LevelId,
					stu_class.class_id,
					tblscholar.scholarAmount
					FROM
					tblscholar
					INNER JOIN tblscholartype ON tblscholar.scholarId = tblscholartype.id
					INNER JOIN student ON tblscholar.stu_id = student.stu_id
					INNER JOIN stu_class ON student.class = stu_class.class_id
					WHERE
					tblscholar.stu_id= " . $dbh->quote($id) . "
					LIMIT 1";
		$stmt = $dbh->query($sql_select);
		if($stmt === false){
			return NULL;
		}
		$r = $stmt->fetchAll(PDO::FETCH_OBJ);
		if($r !== false){
			foreach($r as $ScholarStudent111)
		{
			
		}
			return $ScholarStudent111;
		}else
			return null;
}

/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
function SendMessage($fee,$arrears,$stid){
		global $msg, $dbh,$SumPenaltyss;
		$key="LBWl9I1qlSVsV21cQXY92zp8M"; //your unique API key;
$message ="GHC". $fee. " HAS BEEN RECEIVED AS PAYMENT OF YOUR TERM FEES GHC" . $arrears. " BALANCE REMAINING. THANKS";
$sender_id ="FAstLiNk";
$message=urlencode($message); //encode url;

/*******************API URL FOR SENDING MESSAGES********/
$url="https://apps.mnotify.net/smsapi?key=$key&to=$stid&msg=$message&sender_id=$sender_id";


/****************API URL TO CHECK BALANCE****************/
//$url="https://apps.mnotify.net/smsapi/balance?key=$key";


$result=file_get_contents($url); //call url and store result;

switch($result){                                           
    case "1000":
	echo "";
	break;
    case "1002":
	echo "Message not sent";
	break;
    case "1003":
	echo "You don't have enough balance";
	break;
    case "1004":
	echo "Invalid API Key";
	break;
    case "1005":
	echo "Phone number not valid";
	break;
    case "1006":
	echo "Invalid Sender ID";
	break;
    case "1008":
	echo "Empty message";
	break;
}
	

}

/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
function feePaymentAlert($fee,$arrears,$studentid){
		global $msg, $dbh,$SumPenaltyss;
		$name=StudentData($studentid)->guardian_name;
$message ="HI ".$name.", GHC". $fee. " HAS BEEN RECEIVED AS PAYMENT OF YOUR TERM FEES. YOUR CURRENT BALANCE IS GHC" . $arrears;
$senderid ="FAstLiNk";
$contact=StudentData($studentid)->guardian_contact;
$newDestArray =[$contact];
//$message=urlencode($message); //encode url;
//SEND SMS V2
$curl = curl_init();
curl_setopt_array($curl, [
    CURLOPT_URL => 'https://sms.arkesel.com/api/v2/sms/send',
    CURLOPT_HTTPHEADER => ['api-key: OmJHV0R6SGNDTEFGckt2NGI='],
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => '',
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => 'POST',
    CURLOPT_POSTFIELDS => http_build_query([
        'sender' => $senderid,
        'message' => $message,
        'recipients' => $newDestArray
    ]),
]);

$response = curl_exec($curl);
curl_close($curl);
	

}

/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
function SendParentFast($fee,$arrears){
		global $msg, $dbh,$SumPenaltyss;
		$key="LBWl9I1qlSVsV21cQXY92zp8M"; //your unique API key;
$message ="FASTLINK ACADEMY: ". $fee. " HAS BEEN RECEIVED AS PAYMENT OF YOUR TERM FEES, " . $arrears. " BALANCE REMAINING. THANKS";
$sender_id ="FAstLiNk";
$message=urlencode($message); //encode url;

/*******************API URL FOR SENDING MESSAGES********/
$url="https://apps.mnotify.net/smsapi?key=$key&to=$fee&msg=$arrears&sender_id=$sender_id";


/****************API URL TO CHECK BALANCE****************/
//$url="https://apps.mnotify.net/smsapi/balance?key=$key";


$result=file_get_contents($url); //call url and store result;

switch($result){                                           
    case "1000":
	echo "Message sent";
	break;
    case "1002":
	echo "Message not sent";
	break;
    case "1003":
	echo "You don't have enough balance";
	break;
    case "1004":
	echo "Invalid API Key";
	break;
    case "1005":
	echo "Phone number not valid";
	break;
    case "1006":
	echo "Invalid Sender ID";
	break;
    case "1008":
	echo "Empty message";
	break;
}
	

}

function SendParentFastnewold($fee,$arrears){
		$journalName = preg_replace('/\s+/', '%20', $arrears);
	$live_url="https://boldsms.com/smssendingscript.php?username=boldfast&apikey=fX9uSP8GMme6VUQdHJLzYnrKFZsWT017O2E5xwphIqtvAoc43g&sourceAddress=BOLDSMS&shortMessage=$journalName&destinationAddress=$fee&messageDescription=default&messageType=quick"; 
	$parse_url=file($live_url);
	echo $parse_url[0]; 

}

/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.


function SendParentFastnew($fee,$arrears){
    
    $journalName = preg_replace('/\s+/', '%20', $arrears);
    $live_url="http://rslr.connectbind.com:8080/bulksms/bulksms?username=bold-fastlinq&password=f@st1234&type=5&dlr=1&destination=$fee&source=Fastlink&message=$journalName"; 
	$parse_url=file($live_url);
	echo $parse_url[0];   
}

function SendParentFastnew($destinationContact,$sMessage){
    $username = "boldfast";
	$sourceAddress = "FastLink";
	$shortMessage = "$sMessage";
	$apikey = "fX9uSP8GMme6VUQdHJLzYnrKFZsWT017O2E5xwphIqtvAoc43g";
	$destinationAddress = "$destinationContact";
	$messageDescription = "default";
	$messageType = "quick";
	
	//JSON data for each message
	$jsonData = array(
	'username' => $username,
	'sourceAddress' => $sourceAddress,
	'shortMessage' => $shortMessage,
	'apikey' => $apikey,
	'destinationAddress' => $destinationAddress,
	'messageDescription' => $messageDescription,
	'messageType' => $messageType
	);
	
	//api url
	$url = 'https://boldsms.com/smssendingscript.php';
	//initial curl
	$ch = curl_init($url);
	
	//encode the array into JSON
	$jsonDataEncoded = json_encode($jsonData);
	
	curl_setopt($ch, CURLOPT_POST, 1);
	
	curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonDataEncoded);
	curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
	curl_setopt($ch, CURLOPT_TIMEOUT, 4);
	curl_setopt($ch, CURLOPT_HEADER, 0);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_FORBID_REUSE, true);
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 1);
	curl_setopt($ch, CURLOPT_DNS_CACHE_TIMEOUT, 10);
	curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);
	
	//execute request
	curl_exec($ch);
	curl_close($ch);
	

}*/

function SendParentFastnew($fee,$arrears){
    $journalName2 = preg_replace('/\s+/', '%20', $arrears);
		$journalName = $arrears;
		
		if(strlen($journalName2) > 155) {

       $totalMsgPartsNo=ceil(strlen($arrears)/153);
       $totalMessagePartsNoHex=dechex($totalMsgPartsNo);
       
       if(strlen($totalMessagePartsNoHex) == 1) $totalMessagePartsNoHex = "0".$totalMessagePartsNoHex;
       
       $identifyCode = rand(0, 255);//generate randon decimal number from range 0 to 255
	$identifyCodeHex=dechex($identifyCode);//converts from decimal to hexadecimal; 2 digit, so range is  16= 10 ; ff=255
       $messageCharacterIndexStart=0;                   
       
       for ($i = 1 ; $i <= $totalMsgPartsNo; $i++) {
       
              $messagePart=substr($arrears,$messageCharacterIndexStart,153);
								
		$messageCharacterIndexStart += 153; 

              $currentMessagePartsNoHex=dechex($i);

              if(strlen($currentMessagePartsNoHex) == 1) $currentMessagePartsNoHex = "0".$currentMessagePartsNoHex;                                                        
              //Sample UDH: 0500032F0201                                                                                                  
              $UserHeader = '050003'.$identifyCodeHex.$totalMessagePartsNoHex.$currentMessagePartsNoHex; 
              
              $messageUrlencoded = urlencode($messagePart);
              	
	$live_url="https://boldsms.com/smssendingscript.php?username=boldfast&apikey=fX9uSP8GMme6VUQdHJLzYnrKFZsWT017O2E5xwphIqtvAoc43g&sourceAddress=FastLink&shortMessage=$messageUrlencoded&destinationAddress=$fee&messageDescription=default&messageType=quick"; 
	$parse_url=file($live_url);
	echo $parse_url[0]; 
       }

}
else{
    	$live_url="https://boldsms.com/smssendingscript.php?username=boldfast&apikey=fX9uSP8GMme6VUQdHJLzYnrKFZsWT017O2E5xwphIqtvAoc43g&sourceAddress=FastLink&shortMessage=$journalName2&destinationAddress=$fee&messageDescription=default&messageType=quick"; 
	$parse_url=file($live_url);
	echo $parse_url[0]; 

       

}

	


}


/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
	function LastArrears_exist($indexno){
	global $msg, $dbh, $error;
 
	$sql_select = "SELECT stu_id
		       FROM studentaccount
		       WHERE stu_id = " . $dbh->quote($indexno) . "
		       LIMIT 1";
 
	$stmt = $dbh->query($sql_select);
 
	if($stmt === false){
		return NULL;
	}
	$r = $stmt->fetch(PDO::FETCH_ASSOC);
	if($r !== false){
		return true;
	}else
		return false;
}
/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
	function penalty_exist($indexno){
	global $msg, $dbh, $error;
 
	$sql_select = "SELECT stu_id
		       FROM tblpenalty
		       WHERE stu_id = " . $dbh->quote($indexno) . " AND Status=0
		       LIMIT 1";
 
	$stmt = $dbh->query($sql_select);
 
	if($stmt === false){
		return NULL;
	}
	$r = $stmt->fetch(PDO::FETCH_ASSOC);
	if($r !== false){
		return true;
	}else
		return false;
}
/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
	function CurrentTerm(){
		global $msg, $dbh, $CurrentTerm;
		$sql_select = "SELECT tblsetting.Term FROM tblsetting LIMIT 1";
		$stmt = $dbh->query($sql_select);
		if($stmt === false){
			return NULL;
		}
		$r = $stmt->fetchAll(PDO::FETCH_OBJ);
		if($r !== false){
			foreach($r as $result)
		{
			$CurrentTerm = $result->Term;
		}
			return $CurrentTerm;
		}else
			return null;
}
/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
	function CurrentACYear(){
		global $msg, $dbh, $CurrentACYearss;
		$sql_select = "SELECT tblsetting.Year FROM tblsetting LIMIT 1";
		$stmt = $dbh->query($sql_select);
		if($stmt === false){
			return NULL;
		}
		$r = $stmt->fetchAll(PDO::FETCH_OBJ);
		if($r !== false){
			foreach($r as $result)
		{
			$CurrentACYearss = $result->Year;
		}
			return $CurrentACYearss;
		}else
			return null;
}
/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
	function TotalPayableFee($indexno){
	global $msg, $dbh, $error;
	$totalfees=0;
	$penaltybill=0;
	$lastarrears=0;
	$optiobill=0;
	$yeabliss=0;
	$classid=StudentData($indexno)->class;
	$classpayablefee=class_fee($classid);
	$optiobill=OptSum($indexno);
	if(LastArrears_exist($indexno)===true){
		if(CurrentTerm() != ArrearsTerm($indexno))
		{
			$lastarrears=ArrearsAmount($indexno);
		}else{
			$lastarrears=0;
		}
	}
	if(CurrentTerm()=='First'){
		$yeabliss=YearLyBills();
	}
	if(penalty_exist($indexno)===true){
		$penaltybill=SumPenalty($indexno);
	}
	$totalfees=$totalfees+$classpayablefee+$optiobill+$lastarrears+$penaltybill;
	if(scholar_exist($indexno)===true){
		$scholaid=ScholarStudent($indexno)->scholarId;
		if($scholaid==2)
		{
			$totalfees=$totalfees*0.5;
		}elseif($scholaid==3)
		{
			$scholarMoney=ScholarStudent($indexno)->scholarAmount;
			$totalfees=$totalfees-$scholarMoney;
		}else
		{
			$totalfees=0;
		}
	}
	return $totalfees;
}

/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
	function ScholarshipAmount($indexno){
	global $msg, $dbh, $error;
	$totalgranted=0;
	$classid=StudentData($indexno)->class;
	$classpayablefee=class_fee($classid);
	//$optiobill=OptSum($indexno);
	
	$totalgranted=$totalgranted+$classpayablefee;
	if(scholar_exist($indexno)===true){
		$scholaid=ScholarStudent($indexno)->scholarId;
		if($scholaid==1){
			$totalgranted=$totalgranted;
		}
		elseif($scholaid==2)
		{
			$totalgranted=$totalgranted*0.5;
		}elseif($scholaid==3)
		{
			$scholarMoney=ScholarStudent($indexno)->scholarAmount;
			$totalgranted=$scholarMoney;
		}else
		{
			$totalgranted=0;
		}
	}
	return $totalgranted;
}


/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
	function CreditorsTotalFee($indexno){
	global $msg, $dbh, $error;
	$credittotalfees=0;
	$penaltybill=0;
	$lastarrears=0;
	$optiobill=0;
	$yeabliss=0;
	$classid=StudentData($indexno)->class;
	$classpayablefee=class_fee($classid);
	$optiobill=OptSum($indexno);
	if(LastArrears_exist($indexno)===true){
		if(CurrentTerm() != ArrearsTerm($indexno))
		{
			$lastarrears=ArrearsAmount($indexno);
		}else{
			$lastarrears=0;
		}
	}
	if(CurrentTerm()=='First'){
		$yeabliss=YearLyBills();
	}
	if(penalty_exist($indexno)===true){
		$penaltybill=SumPenalty($indexno);
	}
	$credittotalfees=$credittotalfees+$classpayablefee+$optiobill+$penaltybill;

	if(scholar_exist($indexno)===true){
		$scholaid=ScholarStudent($indexno)->scholarId;
		if($scholaid==2)
		{
			$credittotalfees=$credittotalfees*0.5;
		}elseif($scholaid==3)
		{
			$scholarMoney=ScholarStudent($indexno)->scholarAmount;
			$credittotalfees=$credittotalfees-$scholarMoney;
		}else
		{
			$credittotalfees=0;
		}
	}
	return $credittotalfees;
}


/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
	function TermlyFeePaid($indexno){
		global $msg, $dbh, $Totalfeespaid;
		$Totalfeespaid=0;
		$term=CurrentTerm();
		$acyear=CurrentACYear();
		//$transtype='Credit';
		$transtype='Debit';
		$sql_select = "SELECT
		Sum(tblfeepayment.amount) AS Totalfeespaid
		FROM
		tblfeepayment
		WHERE
		tblfeepayment.stu_id = ".$dbh->quote($indexno)." AND
		tblfeepayment.term = ".$dbh->quote($term)." AND
		tblfeepayment.acyear = ".$dbh->quote($acyear)." AND
		tblfeepayment.transtype != ".$dbh->quote($transtype);
		$stmt = $dbh->query($sql_select);
		if($stmt === false){
			return NULL;
		}
		$r = $stmt->fetchAll(PDO::FETCH_OBJ);
		if($r !== false){
			foreach($r as $result)
		{
			$Totalfeespaid = $result->Totalfeespaid;
		}
			return $Totalfeespaid;
		}else
			return $Totalfeespaid;
}


/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
	function termly_fee_exist($indexno){
	global $msg, $dbh, $error;
		$term=CurrentTerm();
		$acyear=CurrentACYear();
	$sql_select = "SELECT
	tbltermlyfee.stu_id
	FROM
	tbltermlyfee
	WHERE
	tbltermlyfee.stu_id = ".$dbh->quote($indexno)." AND
	tbltermlyfee.term = ".$dbh->quote($term)." AND
	tbltermlyfee.acyear = ".$dbh->quote($acyear);
	$stmt = $dbh->query($sql_select);
 
	if($stmt === false){
		return NULL;
	}
	$r = $stmt->fetch(PDO::FETCH_ASSOC);
	if($r !== false){
		return true;
	}else
		return false;
}

/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
	function termly_debit_exist($indexno){
	global $msg, $dbh, $error;
	$trm='Term';
	$rrt=CurrentTerm();
	$eet=str_replace("/","-",CurrentACYear());
		$term=$rrt." ".$trm;
		$acyear=$eet;
	$sql_select = "SELECT
	debitstudent.stu_id
	FROM
	debitstudent
	WHERE
	debitstudent.stu_id = ".$dbh->quote($indexno)." AND
	debitstudent.term = ".$dbh->quote($term)." AND
	debitstudent.year = ".$dbh->quote($acyear);
	$stmt = $dbh->query($sql_select);
 
	if($stmt === false){
		return NULL;
	}
	$r = $stmt->fetch(PDO::FETCH_ASSOC);
	if($r !== false){
		return true;
	}else
		return false;
}

/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
	function termly_fee_exist1($indexno){
	global $msg, $dbh, $error;
		$term=CurrentTerm();
		$acyear=CurrentACYear();
		$term1=$term .' '.'Term';
		$yr=str_replace("/","-","$acyear");
	$sql_select = "SELECT
	debitstudent.stu_id
	FROM
	debitstudent
	WHERE
	debitstudent.stu_id = ".$dbh->quote($indexno)." AND
	debitstudent.term = ".$dbh->quote($term1)." AND
	debitstudent.year = ".$dbh->quote($yr);
	$stmt = $dbh->query($sql_select);
 
	if($stmt === false){
		return NULL;
	}
	$r = $stmt->fetch(PDO::FETCH_ASSOC);
	if($r !== false){
		return true;
	}else
		return false;
}
/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
	function TotalTermlyBill($indexno){
		global $msg, $dbh, $termlyfee111;
		$termlyfee111=0;
		$term=CurrentTerm();
		$acyear=CurrentACYear();
		$sql_select = "SELECT
		tbltermlyfee.termlyfee
		FROM
		tbltermlyfee
		WHERE
		tbltermlyfee.stu_id = ".$dbh->quote($indexno)." AND
		tbltermlyfee.term = ".$dbh->quote($term)." AND
		tbltermlyfee.acyear =".$dbh->quote($acyear);
		$stmt = $dbh->query($sql_select);
		if($stmt === false){
			return NULL;
		}
		$r = $stmt->fetchAll(PDO::FETCH_OBJ);
		if($r !== false){
			foreach($r as $result)
		{
			$termlyfee111 = $result->termlyfee;
		}
			return $termlyfee111;
		}else
			return $termlyfee111;
}
/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
function settle_penalty($id,$billid){
	global $dbh, $msg, $error;
	// construct SQL insert statement
	$sql = "UPDATE `tblpenalty` SET  `Status`=1, `BillId`=" . $dbh->quote($billid) ." WHERE (`stu_id`=".$dbh->quote($id)." AND `Status`=0)";
	if($dbh->exec($sql) === false){
		return false;
	}else{
		return true;
	}
}
/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
	function Penalty_BillId($id){
		global $msg, $dbh, $PenaltyBillIds;
		$sql_select = "SELECT tblfeepayment.id AS PID FROM tblfeepayment WHERE tblfeepayment.stu_id = ".$dbh->quote($id)." ORDER BY tblfeepayment.id DESC LIMIT 1";
		$stmt = $dbh->query($sql_select);
		if($stmt === false){
			return NULL;
		}
		$r = $stmt->fetchAll(PDO::FETCH_OBJ);
		if($r !== false){
			foreach($r as $result)
		{
			$PenaltyBillIds = $result->PID;
		}
			return $PenaltyBillIds;
		}else
			return null;
}
/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
function Update_Arrears($id,$arrears,$dat){
	global $dbh, $msg, $error;
	// construct SQL insert statement
	$sql = "UPDATE `studentaccount` SET `date_as_at`=" . $dbh->quote($dat) .", `amount`=" . $dbh->quote($arrears) ." WHERE (`stu_id`=".$dbh->quote($id).")";
	if($dbh->exec($sql) === false){
		return false;
	}else{
		return true;
	}
}

/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
function Update_Arrears1($id,$arrears,$dat){
	global $dbh, $msg, $error;
	// construct SQL insert statement
	$sql = "UPDATE `studentaccount` SET `date_as_at`=" . $dbh->quote($dat) .", `amount`=" . $dbh->quote($arrears) ." WHERE (`stu_id`=".$dbh->quote($id).")";
	if($dbh->exec($sql) === false){
		return false;
	}else{
		return true;
	}
}

/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
function Update_Arrears2($id,$arrears){
	global $dbh, $msg, $error;
	// construct SQL insert statement
	$sql = "UPDATE `studentaccount` SET `amount`=" . $dbh->quote($arrears) ." WHERE (`stu_id`=".$dbh->quote($id).")";
	if($dbh->exec($sql) === false){
		return false;
	}else{
		return true;
	}
}

/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
function Update_Arrearspta($id,$arrears,$dat){
	global $dbh, $msg, $error;
	// construct SQL insert statement
	$sql = "UPDATE `studentaccountpta` SET `dateof`=" . $dbh->quote($dat) .", `amount`=" . $dbh->quote($arrears) ." WHERE (`stu_id`=".$dbh->quote($id).")";
	if($dbh->exec($sql) === false){
		return false;
	}else{
		return true;
	}
}

/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
function Insert_Arrearspta($id,$arrears,$dat){
	global $dbh, $msg, $error;
	// construct SQL insert statement
	$sql = "INSERT INTO studentaccountpta(stu_id,dateof,amount) VALUES(" . $dbh->quote($id) ."," . $dbh->quote($dat) .",".$dbh->quote($arrears).")";
	if($dbh->exec($sql) === false){
		return false;
	}else{
		return true;
	}
}

/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
function Insert_Arrears1($id,$arrears,$dat){
	global $dbh, $msg, $error;
	// construct SQL insert statement
	$sql = "INSERT INTO studentaccount(stu_id,date_as_at,amount) VALUES(" . $dbh->quote($id) ."," . $dbh->quote($dat) .",".$dbh->quote($arrears).")";
	if($dbh->exec($sql) === false){
		return false;
	}else{
		return true;
	}
}
/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
function Insert_Arrears($id,$arrears,$dat){
	global $dbh, $msg, $error;
	// construct SQL insert statement
	$sql = "INSERT INTO studentaccount(stu_id,date_as_at,amount) VALUES(" . $dbh->quote($id) ."," . $dbh->quote($dat) .",".$dbh->quote($arrears).")";
	if($dbh->exec($sql) === false){
		return false;
	}else{
		return true;
	}
}
/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/


function ExStaff(){
$stmt = $dbh->prepare("SELECT
staff.fullname,
staff.staff_id
FROM
staff");
	 $stmt->execute();?>
	 ><option value="*">All Staff</option>
	 <?php
	 while($row=$stmt->fetchAll(PDO::FETCH_OBJ))
	 {
	  ?>
	  <option value="<?php echo htmlentities($row['fullname']); ?>"><?php echo htmlentities($row['fulllname']); ?></option>
	  <?php
	 }
}		

/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
function StudentClass($id){
		global $msg, $dbh,$stdClass;
		$sql_select = "SELECT
		stu_class.class_name
		FROM
		stu_class
		WHERE
		stu_class.class_id = ".$dbh->quote($id) . "
		LIMIT 1";
		$stmt = $dbh->query($sql_select);
		if($stmt === false){
			return NULL;
		}
		$qry = $stmt->fetchAll(PDO::FETCH_OBJ);
		if($qry !== false){
			foreach($qry as $stdClass)
			{}
			return $stdClass->class_name;
		}else
			return null;
}

/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
function StudentLevel($id){
		global $msg, $dbh,$stdClass;
		$sql_select = "SELECT
		stu_class.LevelId
		FROM
		stu_class
		WHERE
		stu_class.class_id = ".$dbh->quote($id) . "
		LIMIT 1";
		$stmt = $dbh->query($sql_select);
		if($stmt === false){
			return NULL;
		}
		$qry = $stmt->fetchAll(PDO::FETCH_OBJ);
		if($qry !== false){
			foreach($qry as $stdClass)
			{}
			return $stdClass->LevelId;
		}else
			return null;
}
/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
function GetCashierName($id){
		global $msg, $dbh,$getCashier;
		$sql_select = "SELECT
		staff.fullname
		FROM
		staff
		WHERE
		staff.staff_id = ".$dbh->quote($id) . "
		LIMIT 1";
		$stmt = $dbh->query($sql_select);
		if($stmt === false){
			return NULL;
		}
		$qry = $stmt->fetchAll(PDO::FETCH_OBJ);
		if($qry !== false){
			foreach($qry as $getCashier)
			{}
			return $getCashier->fullname;
		}else
			return null;
}
/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
function GetStdArrears($id){
		global $msg, $dbh,$getArrears;
		$sql_select = "SELECT
		studentaccount.amount
		FROM
		studentaccount
		WHERE
		studentaccount.stu_id = ".$dbh->quote($id) . "
		LIMIT 1";
		$stmt = $dbh->query($sql_select);
		if($stmt === false){
			return NULL;
		}
		$qry = $stmt->fetchAll(PDO::FETCH_OBJ);
		if($qry !== false){
			foreach($qry as $getArrears)
			{}
			return $getArrears->amount;
		}else
			return null;
}

/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
function GetStudentName($id){
		global $msg, $dbh,$getStudent;
		$sql_select = "SELECT
		student.surname,
		student.firstname
		FROM
		student
		WHERE
		student.stu_id = ".$dbh->quote($id) . "
		LIMIT 1";
		$stmt = $dbh->query($sql_select);
		if($stmt === false){
			return NULL;
		}
		$qry = $stmt->fetchAll(PDO::FETCH_OBJ);
		if($qry !== false){
			foreach($qry as $getStudent)
			{}
			return $getStudent->surname." ".$getStudent->firstname;
		}else
			return null;
}

/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
function FeePaidDetails($id){
		global $msg, $dbh,$FeePaidDetailes;
		$sql_select = "SELECT
		tblfeepayment.id,
		tblfeepayment.stu_id,
		tblfeepayment.transtype,
		tblfeepayment.classid,
		tblfeepayment.term,
		tblfeepayment.initialamount,
		tblfeepayment.amount,
		tblfeepayment.balance,
		tblfeepayment.Rdate,
		tblfeepayment.cashier,
		tblfeepayment.acyear,
		tblfeepayment.NameDep,
		tblfeepayment.paydate,
		tblfeepayment.status,
		tblfeepayment.paybank,
		tblfeepayment.paymode,

		tblfeepayment.reason
		FROM
		tblfeepayment
		WHERE
		tblfeepayment.id =" . $dbh->quote($id) . "
		LIMIT 1";
		$stmt = $dbh->query($sql_select);
		if($stmt === false){
			return NULL;
		}
		$qry = $stmt->fetchAll(PDO::FETCH_OBJ);
		if($qry !== false){
			foreach($qry as $FeePaidDetailes)
			{}
			return $FeePaidDetailes;
		}else
			return null;
}



/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
	function history_exist($indexno){
	global $msg, $dbh, $error;
 
	$sql_select = "SELECT stu_id
		       FROM tblfeepayment
		       WHERE stu_id = " . $dbh->quote($indexno) . "
		       LIMIT 1";
 
	$stmt = $dbh->query($sql_select);
 
	if($stmt === false){
		return NULL;
	}
	$r = $stmt->fetch(PDO::FETCH_ASSOC);
	if($r !== false){
		return true;
	}else
		return false;
}
/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
	function termhistory_exist($indexno){
	global $msg, $dbh, $error;
	$term=CurrentTerm();
	$acyear=CurrentACYear();
	$sql_select = "SELECT stu_id
		       FROM tblfeepayment
		       WHERE stu_id = " . $dbh->quote($indexno) . "
			   AND term = " . $dbh->quote($term) . "
			   AND acyear = " . $dbh->quote($acyear) . "
		       LIMIT 1";
	$stmt = $dbh->query($sql_select);
	if($stmt === false){
		return NULL;
	}
	$r = $stmt->fetch(PDO::FETCH_ASSOC);
	if($r !== false){
		return true;
	}else
		return false;
}
/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
?>