<?php
include 'kasulixlsx.class.php';
///////////////////////////////////////////////////////////////////////////////////////////////D
class SchoolData{
	const DB_HOST = 'localhost'; /// Beware
	const DB_NAME = 'bold_smis'; // database credentials declares below again
	const DB_USER = 'root';
	const DB_PASSWORD = '';
	public $RowCounts;
	public $errors = false;

	private $conn = null;
	private static $pdoTypes = array(
		'boolean' => PDO::PARAM_BOOL,
		'integer' => PDO::PARAM_INT,
		'double'  => PDO::PARAM_INT,
		'string'  => PDO::PARAM_STR,
		'NULL'    => PDO::PARAM_NULL
	);
	/**
	const DB_HOST = 'localhost'; /// Beware
	const DB_NAME = 'fastlq51_school'; // database credentials declares below again
	const DB_USER = 'fastlq51_school';
	const DB_PASSWORD = 'Fast081612!*';
	 * Open the database connection
	 */
	public function __construct(){
		// open database connection
		$connectionString = sprintf("mysql:host=%s;dbname=%s",
				SchoolData::DB_HOST,
				SchoolData::DB_NAME);
		try {
			$this->conn = new PDO($connectionString,
					SchoolData::DB_USER,
					SchoolData::DB_PASSWORD);

		} catch (PDOException $pe) {
			die($pe->getMessage());
		}
	}
	function SelectSql($sql,$param=[]){
		try
		{
		$q = $this->conn->prepare($sql);
		self::bindValues($q,$param);
		$q->execute();
		if($q === false){
			return NULL;
		}
		$this->RowCounts = $q->rowCount();
		return $q->fetchAll(PDO::FETCH_OBJ);
		}
		catch (PDOException $e)
		{
		exit("Error: " . $e->getMessage());
		}
	}
    public static function bindValue($statement, $paramName, $value, $pdoType = null) {
            if ($paramName[0] != ':') {
                $paramName = ':' . $paramName;
            }

            if (empty($pdoType)) {
                $valueType = gettype($value);

                if (isset(self::$pdoTypes[$valueType])) {
                    $pdoType = self::$pdoTypes[$valueType];
                } else {
                    $value = print_r($value, true);
                    $pdoType = PDO::PARAM_STR;
                }
            }

            return $statement->bindValue($paramName, $value, $pdoType);
        }

        public static function bindValues($statement, $paramKVP, $pdoType = null) {
            $return = true;

            foreach ($paramKVP as $paramName => $value) {
                $return = self::bindValue($statement, $paramName, $value, $pdoType) && $return;
            }

            return $return;
        }
	public function Subjectdata($rid){
			global $msg, $dbh,$subjectdataresult;
			$sql_select = "SELECT
			tblsubject.SubjectName,
			tblsubject.ShortName,
			tblsubject.`Status`,
			tblsubject.id
			FROM
			tblsubject
			WHERE
			tblsubject.id= :id LIMIT 1";
			 $data=array(':id' => $rid);
			 $r = self::SelectSql($sql_select,$data);
			if($r !== false && $r !== null){
				foreach($r as $subjectdataresult)
			{
				
			}
				return $subjectdataresult;
			}else
				return null;
	}
	function ExecSql($sql,$param=[]){
		$q = $this->conn->prepare($sql);
		self::bindValues($q,$param);
		return $q->execute();
	}
	/**
	 * close the database connection
	 */
	public function __destruct() {
		// close the database connection
		$this->conn = null;
	}
}
///////////////////////////////////////////////////////////////////////////////////////////////D
// DB credentials.
define('DB_HOST','localhost');
define('DB_USER','root');
define('DB_PASS','');
define('DB_NAME','bold_smis');
// Establish database connection.
try
{
$dbh = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME,DB_USER, DB_PASS,array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8'"));
}
catch (PDOException $e)
{
exit("Error: " . $e->getMessage());
}
////////////////////////////////////////////////////////////////
	function student_exist($indexno){
	global $msg, $dbh, $error;
 
	$sql_select = "SELECT stu_id
		       FROM student
		       WHERE stu_id = " . $dbh->quote($indexno) . "
		       LIMIT 1";
 
	$stmt = $dbh->query($sql_select);
 
	if($stmt === false){
		$error = 'Error querying student table';
		return NULL;
	}
	$r = $stmt->fetch(PDO::FETCH_ASSOC);
	if($r !== false){
		return true;
	}else
		return false;
}
////////////////////////////////////////////////////////////////
	function SMSApi(){
		global $msg, $dbh,$current;
		$sql_select = "SELECT tblsmsapi.id, tblsmsapi.SMSApi FROM tblsmsapi LIMIT 1";
		$stmt = $dbh->query($sql_select);
	 
		if($stmt === false){
			return NULL;
		}
		$r = $stmt->fetchAll(PDO::FETCH_OBJ);
		if($r !== false){
			foreach($r as $result)
		{
			
			$current = $result->SMSApi;
		}
			return $current;
		}else
			return null;
}
////////////////////////////////////////////////////////////////
	function stu_exist($indexno){
	global $msg, $dbh, $error;
 
	$sql_select = "SELECT stu_id
		       FROM paid_fees
		       WHERE stu_id = " . $dbh->quote($indexno) . "
		       LIMIT 1";
 
	$stmt = $dbh->query($sql_select);
 
	if($stmt === false){
		$error = 'Error querying fee table table';
		return NULL;
	}
	$r = $stmt->fetch(PDO::FETCH_ASSOC);
	if($r !== false){
		return true;
	}else
		return false;
}

///////////////////////////////////////////////////////////////////////////////////////////////
	function ExpenseType($cid){
		global $msg, $dbh;
		$sql_select = "SELECT tblexpensetype.ExpenseName FROM tblexpensetype WHERE tblexpensetype.id =". $dbh->quote($cid) . "
				   LIMIT 1";
		$stmt = $dbh->query($sql_select);
		if($stmt === false){
			return NULL;
		}
		$r = $stmt->fetchAll(PDO::FETCH_OBJ);
		if($r !== false){
			foreach($r as $result)
		{
			$currexpend = $result->ExpenseType;
		}
			return $currexpend;
		}else
			return null;
}


////////////////////////////////////////////////////////////////
function FirstSecond($string) {
$locale = 'en_UK';
$nf = new NumberFormatter($locale, NumberFormatter::ORDINAL);
$output= $nf->format($string);
 
    return $output;
}
////////////////////////////////////////////////////////////////
function Aggregate($file,$stid) {
	global $outputs;
if ( $xlsx = KasuliXLSX::parse( $file ) ) {
	$x= $xlsx->sheetNames();
	$numbers=array();
	$numbers1=array();
	$totalsheets=(sizeof($x)-1);
	for ($k = 0; $k <= 3; $k++){
	foreach ( $xlsx->rows($k) as $r => $row ) {
	if($row[0] == $stid)
	{ if(!empty($row[8])){
		array_push($numbers,$row[8]);
	}
	}
	}
	}
	for ($k = 4; $k <= $totalsheets; $k++){
	foreach ( $xlsx->rows($k) as $r => $row ) {
	if($row[0] == $stid)
	{ if(!empty($row[8])){
		array_push($numbers1,$row[8]);
	}
	}
	}
	}
		$outputs=0;
		sort($numbers1);
		for($x = 0; $x < 4; $x++) {
			$outputs = $outputs+ $numbers[$x];
		}
		for($x = 0; $x < 2; $x++) {
			$outputs = $outputs+ $numbers1[$x];
		}
} else {
	$outputs=0;
}
return $outputs;
}

///////////////////////////////////////////////////////////////////////////////////////////D
function RemarkSheet($file) {
	$gmani = array();
	$gmanis = array();
	$headteacherremark = "";
if ( $xlsx = KasuliXLSX::parse( $file ) ) {
	list($num_cols, $num_rows) = $xlsx->dimension();
	$f = 0;
	$sheetnames = $xlsx->sheetNames();
	while ($overall = current($sheetnames)) {
		if ($overall == 'Attitude' || $overall == 'Interest' || $overall == 'HEADMASTERRemarks'|| $overall == 'HEADTEACHERRemarks') {
			return true;
		}
		next($sheetnames);
	}
} else {
	return false;
}	
return false;
}
///////////////////////////////////////////////////////////////

function Attendance($file,$stid) {
	$gmani = array();
	$gmanis = array();
	$headteacherremark = "";
if ( $xlsx = KasuliXLSX::parse( $file ) ) {
	list($num_cols, $num_rows) = $xlsx->dimension();
	$f = 0;
	$sheetnames = $xlsx->sheetNames();
	while ($overall = current($sheetnames)) {
		if ($overall == 'Attendance') {
			$key = key($sheetnames);
		}
		next($sheetnames);
	}
	foreach( $xlsx->rows($key) as $r ) 
	{
		if ($f == 0)
		{
			$f++;
			continue;
		}
		for( $i=0; $i < $num_cols; $i++ )
		{
			if ($i == 0)		$data['studentid']		=	$r[$i];
			else if ($i == 2)	$data['ft']		=	        $r[$i];
			if($data['studentid']==$stid)
			{
				$tal = $data['ft'];
			}
		}
	}
	$Attendance =$tal;
} else {
	$Attendance=0;
}	
    return $Attendance;
}


//////////////////////////////////////
function AttendanceOutof($file,$stid) {
	$gmani = array();
	$gmanis = array();
	$headteacherremark = "";
if ( $xlsx = KasuliXLSX::parse( $file ) ) {
	list($num_cols, $num_rows) = $xlsx->dimension();
	$f = 0;
	$sheetnames = $xlsx->sheetNames();
	while ($overall = current($sheetnames)) {
		if ($overall == 'Attendance') {
			$key = key($sheetnames);
		}
		next($sheetnames);
	}
	foreach( $xlsx->rows($key) as $r ) 
	{
		if ($f == 0)
		{
			$f++;
			continue;
		}
		for( $i=0; $i < $num_cols; $i++ )
		{
			if ($i == 0)		$data['studentid']		=	$r[$i];
			else if ($i == 3)	$data['ft']		=	        $r[$i];
			if($data['studentid']==$stid)
			{
				$tal = $data['ft'];
			}
		}
	}
	$Attendanceoutof =$tal;
} else {
	$Attendanceoutof=0;
}	
    return $Attendanceoutof;
}

//////////////////////////////////////
function Promotion($file,$stid) {
	$gmani = array();
	$gmanis = array();
	$headteacherremark = "";
if ( $xlsx = KasuliXLSX::parse( $file ) ) {
	list($num_cols, $num_rows) = $xlsx->dimension();
	$f = 0;
	$sheetnames = $xlsx->sheetNames();
	while ($overall = current($sheetnames)) {
		if ($overall == 'Promotion') {
			$key = key($sheetnames);
		}
		next($sheetnames);
	}
	foreach( $xlsx->rows($key) as $r ) 
	{
		if ($f == 0)
		{
			$f++;
			continue;
		}
		for( $i=0; $i < $num_cols; $i++ )
		{
			if ($i == 0)		$data['studentid']		=	$r[$i];
			else if ($i == 2)	$data['ft']		=	        $r[$i];
			if($data['studentid']==$stid)
			{
				$tal = $data['ft'];
			}
		}
	}
	$Promotion =$tal;
} else {
	$Promotion=0;
}	
    return $Promotion;
}

///////////////////////////////////////////////////////////////////////////////////////////D
function HeadMasterRemarks($file,$stid) {
	$gmani = array();
	$gmanis = array();
	$headteacherremark = "";
if ( $xlsx = KasuliXLSX::parse( $file ) ) {
	list($num_cols, $num_rows) = $xlsx->dimension();
	$f = 0;
	$sheetnames = $xlsx->sheetNames();
	while ($overall = current($sheetnames)) {
		if ($overall == 'HEADMASTERRemarks') {
			$key = key($sheetnames);
		}
		next($sheetnames);
	}
	foreach( $xlsx->rows($key) as $r ) 
	{
		if ($f == 0)
		{
			$f++;
			continue;
		}
		for( $i=0; $i < $num_cols; $i++ )
		{
			if ($i == 0)		$data['studentid']		=	$r[$i];
			else if ($i == 2)	$data['ft']		=	        $r[$i];
			if($data['studentid']==$stid)
			{
				$tal = $data['ft'];
			}
		}
	}
	$headteacherremark =$tal;
} else {
	$headteacherremark=0;
}	
    return $headteacherremark;
}

///////////////////////////////////////////////////////////////////////////////////////////D
function ClassTeacherRemarks($file,$stid) {
	$gmani = array();
	$gmanis = array();
	$headteacherremark = "";
if ( $xlsx = KasuliXLSX::parse( $file ) ) {
	list($num_cols, $num_rows) = $xlsx->dimension();
	$f = 0;
	$sheetnames = $xlsx->sheetNames();
	while ($overall = current($sheetnames)) {
		if ($overall == 'HEADTEACHERRemarks') {
			$key = key($sheetnames);
		}
		next($sheetnames);
	}
	foreach( $xlsx->rows($key) as $r ) 
	{
		if ($f == 0)
		{
			$f++;
			continue;
		}
		for( $i=0; $i < $num_cols; $i++ )
		{
			if ($i == 0)		$data['studentid']		=	$r[$i];
			else if ($i == 2)	$data['ft']		=	        $r[$i];
			if($data['studentid']==$stid)
			{
				$tal = $data['ft'];
			}
		}
	}
	$headteacherremark =$tal;
} else {
	$headteacherremark=0;
}	
    return $headteacherremark;
}


///////////////////////////////////////////////////////////////////////////////////////////D
function AttitudeRemarks($file,$stid) {
	$gmani = array();
	$gmanis = array();
	$headteacherremark = "";
if ( $xlsx = KasuliXLSX::parse( $file ) ) {
	list($num_cols, $num_rows) = $xlsx->dimension();
	$f = 0;
	$sheetnames = $xlsx->sheetNames();
	while ($overall = current($sheetnames)) {
		if ($overall == 'Attitude') {
			$key = key($sheetnames);
		}
		next($sheetnames);
	}
	foreach( $xlsx->rows($key) as $r ) 
	{
		if ($f == 0)
		{
			$f++;
			continue;
		}
		for( $i=0; $i < $num_cols; $i++ )
		{
			if ($i == 0)		$data['studentid']		=	$r[$i];
			else if ($i == 2)	$data['ft']		=	        $r[$i];
			if($data['studentid']==$stid)
			{
				$tal = $data['ft'];
			}
		}
	}
	$attituderemark =$tal;
} else {
	$attituderemark=0;
}	
    return $attituderemark;
}

///////////////////////////////////////////////////////////////////////////////////////////D
function InterestRemarks($file,$stid) {
	$gmani = array();
	$gmanis = array();
	$headteacherremark = "";
if ( $xlsx = KasuliXLSX::parse( $file ) ) {
	list($num_cols, $num_rows) = $xlsx->dimension();
	$f = 0;
	$sheetnames = $xlsx->sheetNames();
	while ($overall = current($sheetnames)) {
		if ($overall == 'Interest') {
			$key = key($sheetnames);
		}
		next($sheetnames);
	}
	foreach( $xlsx->rows($key) as $r ) 
	{
		if ($f == 0)
		{
			$f++;
			continue;
		}
		for( $i=0; $i < $num_cols; $i++ )
		{
			if ($i == 0)		$data['studentid']		=	$r[$i];
			else if ($i == 2)	$data['ft']		=	        $r[$i];
			if($data['studentid']==$stid)
			{
				$tal = $data['ft'];
			}
		}
	}
	$interestremark =$tal;
} else {
	$interestremark=0;
}	
    return $interestremark;
}
/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
	function arrears_exist1($username){
	global $msg, $dbh, $error;
 
	$sql_select = "SELECT
	studentaccount.stu_id
	FROM
	studentaccount
	WHERE
	studentaccount.stu_id = " . $dbh->quote($username) . "
		       LIMIT 1";
 
	$stmt = $dbh->query($sql_select);
 
	if($stmt === false){
		$error = 'Error querying table';
		return NULL;
	}
	$r = $stmt->fetch(PDO::FETCH_ASSOC);
	if($r !== false){
		return true;
	}else
		return false;
}

/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
	function arrears_existpta($username){
	global $msg, $dbh, $error;
 
	$sql_select = "SELECT
	studentaccountpta.stu_id
	FROM
	studentaccountpta
	WHERE
	studentaccountpta.stu_id = " . $dbh->quote($username) . "
		       LIMIT 1";
 
	$stmt = $dbh->query($sql_select);
 
	if($stmt === false){
		$error = 'Error querying table';
		return NULL;
	}
	$r = $stmt->fetch(PDO::FETCH_ASSOC);
	if($r !== false){
		return true;
	}else
		return false;
}

////////////////////////////////////////////////////////////////
function ClassSize ($id) {
	global $msg, $dbh, $class_id;
    $sql_select = "SELECT
					COUNT(student.id) AS ClassSize
					FROM
					student
					WHERE
					student.class = " . $dbh->quote($id) ;
		$stmt = $dbh->query($sql_select);
		if($stmt === false){
			return NULL;
		}
		$r = $stmt->fetchAll(PDO::FETCH_OBJ);
		if($r !== false){
			foreach($r as $rs)
		{
			$class_id = $rs->ClassSize;
		}
			return $class_id;
		}else
			return null;
}
////////////////////////////////////////////////////////////////
function ClassAverage($file,$stid) {
if ( $xlsx = KasuliXLSX::parse( $file ) ) {
	$x= $xlsx->sheetNames();
	$numbers=0;
	$cnt=0;
	$totalsheets=(sizeof($x)-1);
	for ($k = 0; $k <= 3; $k++){
	foreach ( $xlsx->rows($k) as $r => $row ) {
	if($row[0] == $stid)
	{ if(!empty($row[4])  && $row[4]<=100){
		$numbers=$numbers+$row[4];
		$cnt++;
	}
	}
	}
	}
	$ClassAverage=0;
	if($numbers!=0 && $cnt!=0){
	$ClassAverage=$numbers/$cnt;	
	$ClassAverage=round($ClassAverage,2);	
	}
} else {
	$ClassAverage=0;
}	
    return $ClassAverage;
}
////////////////////////////////////////////////////////////////D
			function formatMoney($number, $fractional=false) {
					if ($fractional) {
						$number = sprintf('%.2f', $number);
					}
					while (true) {
						$replaced = preg_replace('/(-?\d+)(\d\d\d)/', '$1,$2', $number);
						if ($replaced != $number) {
							$number = $replaced;
						} else {
							break;
						}
					}
					return $number;
				}

///////////////////////////////////////////////////////////////////////////////////////////////D
function NewAverage($file) {
	$gmani = array();
	$gmanis = array();
	$tot = 0;
	$totmarks = 0;
if ( $xlsx = KasuliXLSX::parse( $file ) ) {
	$x= $xlsx->sheetNames();
	$q=1;
	$totalsheets=(sizeof($x));
	list( $num_cols, $num_rows ) = $xlsx->dimension();
			list( $cols, ) = $xlsx->dimension();
			for ($k = 0; $k <= $num_rows; $k++)
			{
				if($x[$k]=="Overall")
				{
					$gmani = $xlsx->rows($k);
					$f = 0;
					for ( $i = 1; $i < $num_rows; $i ++ )
					{
						$gmanis =$gmani[$i];
						$totmarks = $totmarks+$gmanis[4];	
						$tot = round(($totmarks/$num_rows),2);	

						
					}
				}
			}
} else {
	$tot=0;
}	
    return $tot;
}


////////////////////////////////////////////////////////////////D
function StudentData($id){
		global $msg, $dbh,$stu_id112;
		$sql_select = "SELECT
					student.id,
					student.stu_id,
					student.surname,
					student.firstname,
					student.admission_year,
					student.class,
					student.guardian_name,
					student.guardian_contact,
					student.Photo
					FROM
					student
					WHERE
					student.stu_id = " . $dbh->quote($id) . "
					LIMIT 1";
		$stmt = $dbh->query($sql_select);
		if($stmt === false){
			return NULL;
		}
		$r = $stmt->fetchAll(PDO::FETCH_OBJ);
		if($r !== false){
			foreach($r as $stu_id112)
		{
			
		}
			return $stu_id112;
		}else
			return null;
}
////////////////////////////////////////////////////////////////
global $msg,$error;
function icrypt( $string, $action = 'e' ) {
    $secret_key = 'kasulana_latif';
    $secret_iv = 'knight_rider';
 
    $output = false;
    $encrypt_method = "AES-256-CBC";
    $key = hash( 'sha256', $secret_key );
    $iv = substr( hash( 'sha256', $secret_iv ), 0, 16 );
 
    if( $action == 'e' ) {
        $output = base64_encode( openssl_encrypt( $string, $encrypt_method, $key, 0, $iv ) );
    }
    else if( $action == 'd' ){
        $output = openssl_decrypt( base64_decode( $string ), $encrypt_method, $key, 0, $iv );
    }
 
    return $output;
}
///////////////////////////////////////////////////////////////////////////////////////////////////
function cleanInput($input) {

  $search = array(
    '@<script[^>]*?>.*?</script>@si',   // Strip out javascript
    '@<[\/\!]*?[^<>]*?>@si',            // Strip out HTML tags
    '@<style[^>]*?>.*?</style>@siU',    // Strip style tags properly
    '@<![\s\S]*?--[ \t\n\r]*>@'         // Strip multi-line comments
  );

    $output = preg_replace($search, '', $input);
    return $output;
  }
function clean($input) {
    if (is_array($input)) {
        foreach($input as $var=>$val) {
            $output[$var] = clean($val);
        }
    }
    else {
        //if (get_magic_quotes_gpc()) {
           // $input = stripslashes($input);
        //}
        $input  = cleanInput($input);
		$output = filter_var($input,FILTER_SANITIZE_STRING);
    }
    return $output;
}
//////////////////////////////////////////////////////////////////////////////////////////////
function getExtension($str) {
$i = strrpos($str,".");
if (!$i) { return ""; }
$l = strlen($str) - $i;
$ext = substr($str,$i+1,$l);
return $ext;
}
///////////////////////////////////////////////////////////////////////////////////////////////D
	function LevelName($cid){
		global $msg, $dbh;
		$sql_select = "SELECT tbllevel.LevelName FROM tbllevel WHERE tbllevel.id =". $dbh->quote($cid) . "
				   LIMIT 1";
		$stmt = $dbh->query($sql_select);
		if($stmt === false){
			return NULL;
		}
		$r = $stmt->fetchAll(PDO::FETCH_OBJ);
		if($r !== false){
			foreach($r as $result)
		{
			$fees_paid = $result->LevelName;
		}
			return $fees_paid;
		}else
			return null;
}
///////////////////////////////////////////////////////////////////////////////////////////////D
	function class_lid($cid){
		global $msg, $dbh;
		$sql_select = "SELECT LevelId
				   FROM stu_class
				   WHERE class_id = " . $dbh->quote($cid) . "
				   LIMIT 1";
		$stmt = $dbh->query($sql_select);
		if($stmt === false){
			return NULL;
		}
		$r = $stmt->fetchAll(PDO::FETCH_OBJ);
		if($r !== false){
			foreach($r as $result)
		{
			$class_lid = $result->LevelId;
		}
			return $class_lid;
		}else
			return null;
}
///////////////////////////////////////////////////////////////////////////////////////////////D
function class_level($cid){
		global $msg, $dbh;
		$sql_select = "SELECT LevelName
				   FROM tbllevel
				   WHERE id = " . $dbh->quote($cid) . "
				   LIMIT 1";
		$stmt = $dbh->query($sql_select);
		if($stmt === false){
			return NULL;
		}
		$r = $stmt->fetchAll(PDO::FETCH_OBJ);
		if($r !== false){
			foreach($r as $result)
		{
			$class_level = $result->LevelName;
		}
			return $class_level;
		}else
			return null;
}

function GetStaff($cid){
		global $msg, $dbh, $error;
		$sql_select = "SELECT fullname FROM staff WHERE staff_id = " . $dbh->quote($cid) . "
				   LIMIT 1";
		$stmt = $dbh->query($sql_select);
		if($stmt === false){
			return NULL;
		}
		$r = $stmt->fetchAll(PDO::FETCH_OBJ);
		if($r !== false){
			foreach($r as $result)
		{
			$arrears = $result->fullname;
		}
			return $arrears;
		}else
			return null;
}

///////////////////////////////////////////////////////////////////////////////////////////////D
	function 	Getsubject($cid){
		global $msg, $dbh;
		$sql_select = "SELECT tblsubject.SubjectName FROM tblsubject WHERE tblsubject.id =". $dbh->quote($cid) . "
				   LIMIT 1";
		$stmt = $dbh->query($sql_select);
		if($stmt === false){
			return NULL;
		}
		$r = $stmt->fetchAll(PDO::FETCH_OBJ);
		if($r !== false){
			foreach($r as $result)
		{
			$fees_paid = $result->SubjectName;
		}
			return $fees_paid;
		}else
			return null;
}
///////////////////////////////////////////////////////////////////////////////////////////////D
	function 	GetClass($cid){
		global $msg, $dbh;
		$sql_select = "SELECT stu_class.class_name FROM stu_class WHERE stu_class.class_id =". $dbh->quote($cid) . "
				   LIMIT 1";
		$stmt = $dbh->query($sql_select);
		if($stmt === false){
			return NULL;
		}
		$r = $stmt->fetchAll(PDO::FETCH_OBJ);
		if($r !== false){
			foreach($r as $result)
		{
			$fees_paid = $result->class_name;
		}
			return $fees_paid;
		}else
			return null;
}
///////////////////////////////////////////////////////////////////////////////////////////////D
	function Total_fee_paid($cid){
		global $msg, $dbh,$fees_paidss;
		$sql_select = "SELECT
		Sum(paid_fees.amount_paid) AS fees_paid
		FROM
		paid_fees
		WHERE
		paid_fees.stu_id = " . $dbh->quote($cid);
		$stmt = $dbh->query($sql_select);
		if($stmt === false){
			return NULL;
		}
		$r = $stmt->fetchAll(PDO::FETCH_OBJ);
		if($r !== false){
			foreach($r as $result)
		{
			$fees_paidss = $result->fees_paid;
		}
			return $fees_paidss;
		}else
			return null;
}
///////////////////////////////////////////////////////////////////////////////////////////////D
	function fee_paid($cid){
		global $msg, $dbh;
		$sql_select = "SELECT fees_paid
				   FROM student
				   WHERE stu_id = " . $dbh->quote($cid) . "
				   LIMIT 1";
		$stmt = $dbh->query($sql_select);
		if($stmt === false){
			return NULL;
		}
		$r = $stmt->fetchAll(PDO::FETCH_OBJ);
		if($r !== false){
			foreach($r as $result)
		{
			$fees_paid = $result->fees_paid;
		}
			return $fees_paid;
		}else
			return null;
}
///////////////////////////////////////////////////////////////////////////////////////////////D
	function SumFee($cid){
		global $msg, $dbh,$Fee;
		$Fee=0;
		$sql_select = "SELECT
		Sum(tblfee.Fee) AS Fee
		FROM
		tblfee
		WHERE
		tblfee.Classid =" . $dbh->quote($cid);
		$stmt = $dbh->query($sql_select);
		if($stmt === false){
			return NULL;
		}
		$r = $stmt->fetchAll(PDO::FETCH_OBJ);
		if($r !== false){
			foreach($r as $result)
		{
			$Fee = $result->Fee;
		}
			return $Fee;
		}else
			return null;
}
///////////////////////////////////////////////////////////////////////////////////////////////D
	function SumAllFee($cid){
		global $msg, $dbh,$Fees;
		$x ="*";
		$Fees=0;
		$sql_select = "SELECT
		Sum(tblfee.Fee) AS Fees
		FROM
		tblfee
		WHERE
		tblfee.Classid = " . $dbh->quote($x)." AND
		tblfee.LevelId =" . $dbh->quote($cid);
		$stmt = $dbh->query($sql_select);
		if($stmt === false){
			return NULL;
		}
		$r = $stmt->fetchAll(PDO::FETCH_OBJ);
		if($r !== false){
			foreach($r as $result)
		{
			$Fees = $result->Fees;
		}
			return $Fees;
		}else
			return null;
}
///////////////////////////////////////////////////////////////////////////////////////////////D
	function class_name($cid){
		global $msg, $dbh;
		$sql_select = "SELECT class_name
				   FROM stu_class
				   WHERE class_id = " . $dbh->quote($cid) . "
				   LIMIT 1";
		$stmt = $dbh->query($sql_select);
		if($stmt === false){
			return NULL;
		}
		$r = $stmt->fetchAll(PDO::FETCH_OBJ);
		if($r !== false){
			foreach($r as $result)
		{
			$class_name = $result->class_name;
		}
			return $class_name;
		}else
			return null;
}
///////////////////////////////////////////////////////////////////////////////////////////////D
function ClassPosition($file,$stid) {
	$gmani = array();
	$gmanis = array();
	$pos = 0;
	$data =array();
if ( $xlsx = KasuliXLSX::parse( $file ) ) {
	list($num_cols, $num_rows) = $xlsx->dimension();
	$f = 0;
	$sheetnames = $xlsx->sheetNames();
	end($sheetnames);
	$key = key($sheetnames);
	foreach( $xlsx->rows($key) as $r ) 
	{
		if ($f == 0)
		{
			$f++;
			continue;
		}
		for( $i=0; $i < $num_cols; $i++ )
		{
			if ($i == 0)		$data['studentid']		=	$r[$i];
			else if ($i == 5)	$data['ft']		=	        $r[$i];
			if($data['studentid']==$stid)
			{
				$tal = $data['ft'];
			}
		}
	}
	$pos =$tal;
} else {
	$pos=0;
}	
    return $pos;
}
///////////////////////////////////////////////////////////////////////////////////////////////D
function ClassTotalScore($file,$stid) {
	$gmani = array();
	$gmanis = array();
	$pos = 0;
	$data =array();
if ( $xlsx = KasuliXLSX::parse( $file ) ) {
	list($num_cols, $num_rows) = $xlsx->dimension();
	$f = 0;
	$sheetnames = $xlsx->sheetNames();
	end($sheetnames);
	$key = key($sheetnames);
	foreach( $xlsx->rows($key) as $r ) 
	{
		if ($f == 0)
		{
			$f++;
			continue;
		}
		for( $i=0; $i < $num_cols; $i++ )
		{
			if ($i == 0)		$data['studentid']		=	$r[$i];
			else if ($i == 4)	$data['ft']		=	        $r[$i];
			if($data['studentid']==$stid)
			{
				$tal = $data['ft'];
			}
		}
	}
	$score =$tal;
} else {
	$score=0;
}	
    return $score;
}
///////////////////////////////////////////////////////////////////////////////////////////////D
	function class_fee($cid){
		global $msg, $dbh;
		$sql_select = "SELECT class_total_fee
				   FROM stu_class
				   WHERE class_id = " . $dbh->quote($cid) . "
				   LIMIT 1";
		$stmt = $dbh->query($sql_select);
		if($stmt === false){
			return NULL;
		}
		$r = $stmt->fetchAll(PDO::FETCH_OBJ);
		if($r !== false){
			foreach($r as $result)
		{
			$class_total_fee = $result->class_total_fee;
		}
			return $class_total_fee;
		}else
			return null;
}
///////////////////////////////////////////////////////////////////////////////////////////////D
	function surname($cid){
		global $msg, $dbh;
		$sql_select = "SELECT surname
				   FROM student
				   WHERE stu_id = " . $dbh->quote($cid) . "
				   LIMIT 1";
		$stmt = $dbh->query($sql_select);
		if($stmt === false){
			return NULL;
		}
		$r = $stmt->fetchAll(PDO::FETCH_OBJ);
		if($r !== false){
			foreach($r as $result)
		{
			$posnam = $result->surname;
		}
			return $posnam;
		}else
			return null;
}
///////////////////////////////////////////////////////////////////////////////////////////////D
	function firstname($cid){
		global $msg, $dbh;
		$sql_select = "SELECT firstname
				   FROM student
				   WHERE stu_id = " . $dbh->quote($cid) . "
				   LIMIT 1";
		$stmt = $dbh->query($sql_select);
		if($stmt === false){
			return NULL;
		}
		$r = $stmt->fetchAll(PDO::FETCH_OBJ);
		if($r !== false){
			foreach($r as $result)
		{
			$posnam = $result->firstname;
		}
			return $posnam;
		}else
			return null;
}
///////////////////////////////////////////////////////////////////////////////////////////////D
	function class_id($cid){
		global $msg, $dbh;
		$sql_select = "SELECT class
				   FROM student
				   WHERE stu_id = " . $dbh->quote($cid) . "
				   LIMIT 1";
		$stmt = $dbh->query($sql_select);
		if($stmt === false){
			return NULL;
		}
		$r = $stmt->fetchAll(PDO::FETCH_OBJ);
		if($r !== false){
			foreach($r as $result)
		{
			$posnam = $result->class;
		}
			return $posnam;
		}else
			return null;
}
////////////////////////////////////////////////////////////////////////////////////////
	function schinfo_exist($schid){
	global $msg, $dbh, $error;
 
	$sql_select = "SELECT tblschool.Id
		       FROM tblschool
		       WHERE  tblschool.Id= ".$dbh->quote($schid)."
		       LIMIT 1";
 
	$stmt = $dbh->query($sql_select);
 
	if($stmt === false){
		$error = 'Error querying table';
		return NULL;
	}
	$r = $stmt->fetch(PDO::FETCH_ASSOC);
	if($r !== false){
		return true;
		$error="School Info Already Exist";
	}else
		return false;
}
///////////////////////////////////////////////////////////////////////////////////////////////D
function numtowords($num){ 
$decones = array( 
            '01' => "One", 
            '02' => "Two", 
            '03' => "Three", 
            '04' => "Four", 
            '05' => "Five", 
            '06' => "Six", 
            '07' => "Seven", 
            '08' => "Eight", 
            '09' => "Nine",
            10 => "Ten", 
            11 => "Eleven", 
            12 => "Twelve", 
            13 => "Thirteen", 
            14 => "Fourteen", 
            15 => "Fifteen", 
            16 => "Sixteen", 
            17 => "Seventeen", 
            18 => "Eighteen", 
            19 => "Nineteen" 
            );
$ones = array( 
            0 => " ",
            1 => "One",     
            2 => "Two", 
            3 => "Three", 
            4 => "Four", 
            5 => "Five", 
            6 => "Six", 
            7 => "Seven", 
            8 => "Eight", 
            9 => "Nine", 
            10 => "Ten", 
            11 => "Eleven", 
            12 => "Twelve", 
            13 => "Thirteen", 
            14 => "Fourteen", 
            15 => "Fifteen", 
            16 => "Sixteen", 
            17 => "Seventeen", 
            18 => "Eighteen", 
            19 => "Nineteen" 
            ); 
$tens = array( 
            0 => "",
            2 => "Twenty", 
            3 => "Thirty", 
            4 => "Forty", 
            5 => "Fifty", 
            6 => "Sixty", 
            7 => "Seventy", 
            8 => "Eighty", 
            9 => "Ninety" 
            ); 
$hundreds = array( 
            "Hundred", 
            "Thousand", 
            "Million", 
            "Billion", 
            "Trillion", 
            "Quadrillion" 
            ); //limit t quadrillion 
$num = number_format($num,2,".",","); 
$num_arr = explode(".",$num); 
$wholenum = $num_arr[0]; 
$decnum = $num_arr[1]; 
$whole_arr = array_reverse(explode(",",$wholenum)); 
krsort($whole_arr); 
$rettxt = ""; 
foreach($whole_arr as $key => $i){ 
    if($i < 20){ 
        $rettxt .= $ones[$i]; 
    }
    elseif($i < 100){ 
        $rettxt .= $tens[substr($i,0,1)]; 
        $rettxt .= " ".$ones[substr($i,1,1)]; 
    }
    else{ 
        if(substr($i,1,2)==00){
        $rettxt .= $ones[substr($i,0,1)]." ".$hundreds[0]; 
        $rettxt .= " ".$tens[substr($i,1,2)]; 
        $rettxt .= " ".$ones[substr($i,1,2)]; 
        }elseif(substr($i,1,1)==0 || substr($i,1,1)==1){
        $rettxt .= $ones[substr($i,0,1)]." ".$hundreds[0].' And'; 
         $rettxt .= " ".$decones[substr($i,1,2)]; 
         //$rettxt .= " ".$ones[substr($i,2,1)];
    
        }else{
			$rettxt .= $ones[substr($i,0,1)]." ".$hundreds[0].' And'; 
         $rettxt .= " ".$tens[substr($i,1,1)]; 
         $rettxt .= " ".$ones[substr($i,2,1)];
		}
    } 
    if($key > 0){ 
        $rettxt .= " ".$hundreds[$key]." "; 
    } 
} 
$rettxt = $rettxt." Ghana Cedis";
if($decnum > 0){ 
    $rettxt .= " and "; 
    if($decnum < 20){ 
        $rettxt .= $decones[$decnum]; 
    }
    elseif($decnum < 100){ 
        $rettxt .= $tens[substr($decnum,0,1)]; 
        $rettxt .= " ".$ones[substr($decnum,1,1)]; 
    }
    $rettxt = $rettxt." Pesewas"; 
} 
return $rettxt;
}
///////////////////////////////////////////////////////////////////////////////////////////////D
	function classname_exist($username){
	global $msg, $dbh, $error;
 
	$sql_select = "SELECT class_name
		       FROM stu_class
		       WHERE class_name LIKE " . $dbh->quote($username) . "
		       LIMIT 1";
 
	$stmt = $dbh->query($sql_select);
 
	if($stmt === false){
		$error = 'Error querying table';
		return NULL;
	}
	$r = $stmt->fetch(PDO::FETCH_ASSOC);
	if($r !== false){
		$error = "class $username already exists.";
		return true;
	}else
		return false;
}
///////////////////////////////////////////////////////////////////////////////////////////////D
	function uname_exist($username){
	global $msg, $dbh, $error;
 
	$sql_select = "SELECT username
		       FROM staff
		       WHERE username = " . $dbh->quote($username) . "
		       LIMIT 1";
 
	$stmt = $dbh->query($sql_select);
 
	if($stmt === false){
		$error = 'Error querying table';
		return NULL;
	}
	$r = $stmt->fetch(PDO::FETCH_ASSOC);
	if($r !== false){
		$error = "Username $username already exists.";
		return true;
	}else
		return false;
}
///////////////////////////////////////////////////////////////////////////////////////////////D
function deleteimg($dir,$dfile){    
        $dirHandle = opendir($dir);    
        while ($file = readdir($dirHandle)) {    
            if($file==$dfile) {
                unlink($dir.'/'.$file);//give correct path,
            }
        }    
        closedir($dirHandle);
		return true;
}
///////////////////////////////////////////////////////////////////////////////////////////////D
	function fee_exist($feename,$class,$level){
	global $msg, $dbh, $error;
 
	$sql_select = "SELECT
				tblfee.FeeName,
				tblfee.Classid
				FROM
				tblfee
				WHERE
				tblfee.FeeName LIKE " . $dbh->quote($feename) . " AND
				tblfee.Classid = " . $dbh->quote($class) . " AND
				tblfee.LevelId = " . $dbh->quote($level) . "
				LIMIT 1";
	$stmt = $dbh->query($sql_select);
 
	if($stmt === false){
		$error = 'Error querying table';
		return NULL;
	}
	$r = $stmt->fetch(PDO::FETCH_ASSOC);
	if($r !== false){
		$error = "Fee already exists.";
		return true;
	}else
		return false;
}
///////////////////////////////////////////////////////////////////////////////////////////////D
 function checkimg($img) {
	 global $error;
	$check = getimagesize($img);
    if($check !== false){
			addslashes(file_get_contents($img));
			return true;
	}else{
		$error = "Please select an Image ";
		return false;
	}
	}
///////////////////////////////////////////////////////////////////////////////////////////////D
function School(){
		global $msg, $dbh,$School;
		$sql_select = "SELECT
				tblschool.Id,
				tblschool.SchoolName,
				tblschool.SchoolShortName,
				tblschool.PostAddress,
				tblschool.SchoolEmail,
				tblschool.SchoolMoto,
				tblschool.SchoolPhone,
				tblschool.SchoolPhone2,
				tblschool.SchoolLogo,
				tblschool.nextterm,
				tblschool.SchoolWebsite
				FROM
				tblschool
				   LIMIT 1";
		$stmt = $dbh->query($sql_select);
		if($stmt === false){
			return NULL;
		}
		$r = $stmt->fetchAll(PDO::FETCH_OBJ);
		if($r !== false){
			foreach($r as $School){}
			return $School;
		}else
			return null;
}
///////////////////////////////////////////////////////////////////////////////////////////////D
function FeeDetails($fid){
		global $msg, $dbh,$fee;
		$sql_select = "SELECT
					tblfee.Fee,
					tblfee.id,
					tblfee.FeeName,
					tblfee.LevelId,
					tblfee.Classid
					FROM
					tblfee
					WHERE
					tblfee.id = " . $dbh->quote($fid) . "
					LIMIT 1";
		$stmt = $dbh->query($sql_select);
		if($stmt === false){
			return NULL;
		}
		$r = $stmt->fetchAll(PDO::FETCH_OBJ);
		if($r !== false){
			foreach($r as $fee){}
			return $fee;
		}else
			return null;
}
///////////////////////////////////////////////////////////////////////////////////////////////D
function Student($id){
		global $msg, $dbh,$Student;
		$sql_select = "SELECT
					student.id,
					student.stu_id,
					student.surname,
					student.firstname,
					student.othername,
					student.admission_year,
					student.class,
					student.guardian_name,
					student.guardian_contact,
					student.Photo,
					student.gender,
					student.date_of_birth,
					student.hometown,
					student.tongue,
					student.formal,
					student.loc,
					student.stage,
					student.date_of_admission,
					student.religion,
					student.nationality,
					student.residential_sta,
					student.postal_address,
					student.email,
					student.medical_con,
					student.scholarship_sta,
					student.father_name,
					student.father_phone,
					student.fphone2,
					student.father_occ,
					student.father_religion,
					student.father_educ,
					student.father_address,
					student.mother_name,
					student.mother_phone,
					student.mphone2,
					student.mother_occ,
					student.mother_religion,
					student.mother_educ,
					student.mother_address,
					student.officer,
					student.entered
					FROM
					student
					WHERE
					student.id = " . $dbh->quote($id) . "
					LIMIT 1";
		$stmt = $dbh->query($sql_select);
		if($stmt === false){
			return NULL;
		}
		$r = $stmt->fetchAll(PDO::FETCH_OBJ);
		if($r !== false){
			foreach($r as $Student)
		{
			
		}
			return $Student;
		}else
			return null;
}
///////////////////////////////////////////////////////////////////////////////////////////////D
function ClassData($id){
		global $msg, $dbh,$ClassData;
		$sql_select = "SELECT
					stu_class.class_id,
					stu_class.class_name,
					stu_class.class_total_fee,
					stu_class.LevelId,
					tbllevel.LevelName
					FROM
					stu_class
					INNER JOIN tbllevel ON stu_class.LevelId = tbllevel.id
					WHERE
					stu_class.class_id= " . $dbh->quote($id) . "
					LIMIT 1";
		$stmt = $dbh->query($sql_select);
		if($stmt === false){
			return NULL;
		}
		$r = $stmt->fetchAll(PDO::FETCH_OBJ);
		if($r !== false){
			foreach($r as $ClassData)
		{
			
		}
			return $ClassData;
		}else
			return null;
}
///////////////////////////////////////////////////////////////////////////////////////////D
class ResizeImage
{
	private $ext;
	private $image;
	private $newImage;
	private $origWidth;
	private $origHeight;
	private $resizeWidth;
	private $resizeHeight;

	public function __construct( $filename )
	{
		if(file_exists($filename))
		{
			$this->setImage( $filename );
		} else {
			throw new Exception('Image ' . $filename . ' can not be found, try another image.');
		}
	}
	private function setImage( $filename )
	{
		$size = getimagesize($filename);
		$this->ext = $size['mime'];
		switch($this->ext)
	    {
	    	// Image is a JPG
	        case 'image/jpg':
	        case 'image/jpeg':
	        	// create a jpeg extension
	            $this->image = imagecreatefromjpeg($filename);
	            break;
	        // Image is a GIF
	        case 'image/gif':
	            $this->image = @imagecreatefromgif($filename);
	            break;
	        // Image is a PNG
	        case 'image/png':
	            $this->image = @imagecreatefrompng($filename);
	            break;
	        // Mime type not found
	        default:
	            throw new Exception("File is not an image, please use another file type.", 1);
	    }
	    $this->origWidth = imagesx($this->image);
	    $this->origHeight = imagesy($this->image);
	}
	public function saveImage($savePath, $imageQuality="100", $download = false)
	{
	    switch($this->ext)
	    {
	        case 'image/jpg':
	        case 'image/jpeg':
	        	// Check PHP supports this file type
	            if (imagetypes() & IMG_JPG) {
	                imagejpeg($this->newImage, $savePath, $imageQuality);
	            }
	            break;
	        case 'image/gif':
	        	// Check PHP supports this file type
	            if (imagetypes() & IMG_GIF) {
	                imagegif($this->newImage, $savePath);
	            }
	            break;
	        case 'image/png':
	            $invertScaleQuality = 9 - round(($imageQuality/100) * 9);
	            // Check PHP supports this file type
	            if (imagetypes() & IMG_PNG) {
	                imagepng($this->newImage, $savePath, $invertScaleQuality);
	            }
	            break;
	    }
	    if($download)
	    {
	    	header('Content-Description: File Transfer');
			header("Content-type: application/octet-stream");
			header("Content-disposition: attachment; filename= ".$savePath."");
			readfile($savePath);
	    }
	    imagedestroy($this->newImage);
	}
	public function resizeTo( $width, $height, $resizeOption = 'default' )
	{
		switch(strtolower($resizeOption))
		{
			case 'exact':
				$this->resizeWidth = $width;
				$this->resizeHeight = $height;
			break;
			case 'maxwidth':
				$this->resizeWidth  = $width;
				$this->resizeHeight = $this->resizeHeightByWidth($width);
			break;
			case 'maxheight':
				$this->resizeWidth  = $this->resizeWidthByHeight($height);
				$this->resizeHeight = $height;
			break;
			default:
				if($this->origWidth > $width || $this->origHeight > $height)
				{
					if ( $this->origWidth > $this->origHeight ) {
				    	 $this->resizeHeight = $this->resizeHeightByWidth($width);
			  			 $this->resizeWidth  = $width;
					} else if( $this->origWidth < $this->origHeight ) {
						$this->resizeWidth  = $this->resizeWidthByHeight($height);
						$this->resizeHeight = $height;
					}
				} else {
		            $this->resizeWidth = $width;
		            $this->resizeHeight = $height;
		        }
			break;
		}
		$this->newImage = imagecreatetruecolor($this->resizeWidth, $this->resizeHeight);
    	imagecopyresampled($this->newImage, $this->image, 0, 0, 0, 0, $this->resizeWidth, $this->resizeHeight, $this->origWidth, $this->origHeight);
	}
	private function resizeHeightByWidth($width)
	{
		return floor(($this->origHeight/$this->origWidth)*$width);
	}
	private function resizeWidthByHeight($height)
	{
		return floor(($this->origWidth/$this->origHeight)*$height);
	}
}
///////////////////////////////////////////////////////////////////////////////////////////D
class Schoolsend {

    private $_endpoint;
    public $keys;
    public $message;
    public $number;
    public $sender;

    public function __construct()
    {
        $this->_endpoint = 'https://apps.mnotify.net/smsapi';
    }
    public function sendMessage()
    {
        $url = $this->_endpoint."?key=".$this->keys."&to=".$this->number."&msg=".$this->message."&sender_id=".$this->sender;
		$result = file_get_contents($url);
        return $this->interpret($result);
    }
    private function interpret($code)
    {
        $status = '';
        switch ($code) {
            case '1000':
                $status = '1000';
                return $status;
                break;
            case '1002':
                $status = 'sending SMS to parent/guardian failed. Might be due to server error or other reason';
                return $status;
                break;
            case '1003':
                $status = 'Insufficient SMS credit balance to notification to parent/guardian';
                return $status;
                break;
            case '1004':
                $status = 'Invalid API Key';
                return $status;
                break;
            case '1005':
                $status = 'Invalid parent/guardian phone number';
                return $status;
                break;
            case '1006':
                $status = 'School Short Name must not be more than 11 characters. Characters include white space';
                return $status;
                break;
            case '1007':
                $status = 'Message scheduled for later delivery';
                return $status;
                break;
            case '1008':
                $status = 'Empty Message';
                return $status;
                break;
            default:
                return $status;
                break;
        }
    }
}
///////////////////////////////////////////////////////////////////////////////////////////D
/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
	function subconb_exist($classid,$subjectid){
	global $msg, $dbh, $error;
 
	$sql_select = "SELECT ClassId, SubjectId
		       FROM tblsubcombination
		       WHERE  ClassId= ".$dbh->quote($classid)." AND SubjectId= ".$dbh->quote($subjectid)."
		       LIMIT 1";
 
	$stmt = $dbh->query($sql_select);
 
	if($stmt === false){
		$error = 'Error querying table';
		return NULL;
	}
	$r = $stmt->fetch(PDO::FETCH_ASSOC);
	if($r !== false){
		return true;
		$error="The subject is already assigned to the class";
	}else
		return false;
}
/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
	function Assignrole_exist($username,$role){
	global $msg, $dbh, $error;
 
	$sql_select = "SELECT
	tblstaffrole.username
	FROM
	tblstaffrole
	WHERE
	tblstaffrole.username = ".$dbh->quote($username)." AND
	tblstaffrole.RoleId = ".$dbh->quote($role)." LIMIT 1";
	$stmt = $dbh->query($sql_select);
	if($stmt === false){
		$error = 'Error querying table';
		return NULL;
	}
	$r = $stmt->fetch(PDO::FETCH_ASSOC);
	if($r !== false){
		return true;
		$error="The subject is already assigned to the class";
	}else
		return false;
}
/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
	function FeeMessage($pid){
		global $gndr, $title,$current;
		$class_fee = class_fee(StudentData($pid)->class);
		$Studentname = StudentData($pid)->surname." ".StudentData($pid)->firstname;
		$feeowed = ($class_fee-fee_paid($pid));
		$current = "Dear Parent your ward ".$Studentname." is still owing the an amount of GH₵ ".$feeowed.". You are kindly REMINDED to settle your fees. Thank you." ;
		return $current;
}
/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
	function uname_exist1($username){
	global $msg, $dbh, $error;
 
	$sql_select = "SELECT username
		       FROM user
		       WHERE username = " . $dbh->quote($username) . "
		       LIMIT 1";
 
	$stmt = $dbh->query($sql_select);
 
	if($stmt === false){
		$error = 'Error querying table';
		return NULL;
	}
	$r = $stmt->fetch(PDO::FETCH_ASSOC);
	if($r !== false){
		return true;
	}else
		return false;
}
/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
	function staff_exist($indexno){
	global $msg, $dbh, $error;
	$sql_select = "SELECT staff.username FROM staff WHERE staff.username = " . $dbh->quote($indexno) . " LIMIT 1";
	$stmt = $dbh->query($sql_select);
	if($stmt === false){
		$error = 'Error querying the table or the view';
		return NULL;
	}
	$r = $stmt->fetch(PDO::FETCH_ASSOC);
	if($r !== false){
		return true;
	}else
		return false;
}
/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
function StaffData($id){
		global $msg, $dbh,$staffusername;
		$sql_select = "SELECT
					staff.staff_id,
					staff.username,
					staff.fullname,
					staff.contact
					FROM
					staff
					WHERE
					staff.username = " . $dbh->quote($id) . "
					LIMIT 1";
		$stmt = $dbh->query($sql_select);
		if($stmt === false){
			return NULL;
		}
		$r = $stmt->fetchAll(PDO::FETCH_OBJ);
		if($r !== false){
			foreach($r as $staffusername)
		{
			
		}
			return $staffusername;
		}else
			return null;
}
/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
function StaffUsername($id){
		global $msg, $dbh,$staffusername;
		$sql_select = "SELECT
			staff.staff_id,staff.role,staff.username,
			staff.`password`,
			staff.fullname,
			staff.contact
			FROM
			staff
			WHERE
			staff.staff_id = " . $dbh->quote($id) . "
			LIMIT 1";
		$stmt = $dbh->query($sql_select);
		if($stmt === false){
			return NULL;
		}
		$r = $stmt->fetchAll(PDO::FETCH_OBJ);
		if($r !== false){
			foreach($r as $staffusername)
		{
			
		}
			return $staffusername;
		}else
			return null;
}
/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
function User($rid){
		global $msg, $dbh,$usernamesss;
		$sql_select = "SELECT `user`.id,`user`.username,`user`.`name`,`user`.gender,
		`user`.`password`,`user`.contact,`user`.type,`user`.email,`user`.photo
		FROM`user`	WHERE `user`.username= " . $dbh->quote($rid)." LIMIT 1";
		$stmt = $dbh->query($sql_select);
		if($stmt === false){
			return NULL;
		}
		$r = $stmt->fetchAll(PDO::FETCH_OBJ);
		if($r !== false){
			foreach($r as $usernamesss):
			endforeach;
			return $usernamesss;
		}else
			return null;
}
/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
	function IsAdmin($username, $pass){
		global $msg, $dbh, $error;
		$sql_select = "SELECT
		`user`.username,
		`user`.`password`
		FROM
		`user`
		WHERE
		`user`.username = :username AND`user`.password = :password
				   LIMIT 1";
		$stmt = $dbh->prepare($sql_select);
		$stmt->bindParam(':username', $username);
		$stmt->bindParam(':password', $pass);
		$stmt->execute();
		if($stmt === false){
			return NULL;
		}
		$r = $stmt->fetch(PDO::FETCH_ASSOC);
		if($r !== false){
			return true;
		}else
			return false;
}
//////////////////////////////////////////////////////////////////////////////P
	function IsStaff($username, $pass){
		global $msg, $dbh, $error;
		$sql_select = "SELECT username,password FROM staff WHERE username=:staffid and password=:password
				   LIMIT 1";
		$stmt = $dbh->prepare($sql_select);
		$stmt->bindParam(':staffid', $username);
		$stmt->bindParam(':password', $pass);
		$stmt->execute();
		if($stmt === false){
			return NULL;
		}
		$r = $stmt->fetch(PDO::FETCH_ASSOC);
		if($r !== false){
			return true;
		}else
			return false;
}
/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
function ClassPositions($file,$stid) {
	$gmani = array();
	$gmanis = array();
	$pos = 0;
	$data =array();
if ( $xlsx = KasuliXLSX::parse( $file ) ) {
	list($num_cols, $num_rows) = $xlsx->dimension();
	$f = 0;
	$sheetnames = $xlsx->sheetNames();
	end($sheetnames);
	$key = key($sheetnames);
	foreach( $xlsx->rows($key) as $r ) 
	{
		if ($f == 0)
		{
			$f++;
			continue;
		}
		for( $i=0; $i < $num_cols; $i++ )
		{
			if ($i == 0)		$data['studentid']		=	$r[$i];
			else if ($i == 5)	$data['ft']		=	        $r[$i];
			if($data['studentid']==$stid)
			{
				$tal = $data['ft'];
			}
		}
	}
	$pos =$tal;
} else {
	$pos=0;
}	
    return $pos;
}
/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
	function scholar_exist($username){
	global $msg, $dbh, $error;
 
	$sql_select = "SELECT
	tblscholar.stu_id
	FROM
	tblscholar
	WHERE
	tblscholar.stu_id = " . $dbh->quote($username) . "
		       LIMIT 1";
 
	$stmt = $dbh->query($sql_select);
 
	if($stmt === false){
		$error = 'Error querying table';
		return NULL;
	}
	$r = $stmt->fetch(PDO::FETCH_ASSOC);
	if($r !== false){
		return true;
	}else
		return false;
}
/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
function ScholarData($id){
		global $msg, $dbh,$ScholarDatass;
		$sql_select = "SELECT
					tblscholar.stu_id,
					student.surname,
					student.firstname,
					student.guardian_name,
					student.class,
					tblscholartype.scholarType,
					tblscholar.scholarId,
					tblscholar.id,
					stu_class.class_name,
					stu_class.LevelId,
					tblscholar.scholarAmount
					FROM
					tblscholar
					INNER JOIN tblscholartype ON tblscholar.scholarId = tblscholartype.id
					INNER JOIN student ON tblscholar.stu_id = student.stu_id
					INNER JOIN stu_class ON student.class = stu_class.class_id
					WHERE
					tblscholar.id= " . $dbh->quote($id) . "
					LIMIT 1";
		$stmt = $dbh->query($sql_select);
		if($stmt === false){
			return NULL;
		}
		$r = $stmt->fetchAll(PDO::FETCH_OBJ);
		if($r !== false){
			foreach($r as $ScholarDatass)
		{
			
		}
			return $ScholarDatass;
		}else
			return null;
}
/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
	function bill_exist($feename){
	global $msg, $dbh, $error;
 
	$sql_select = "SELECT
				tblyearlybill.BillName
				FROM
				tblyearlybill
				WHERE
				tblyearlybill.BillName LIKE " . $dbh->quote($feename) . "
				LIMIT 1";
	$stmt = $dbh->query($sql_select);
 
	if($stmt === false){
		$error = 'Error querying table';
		return NULL;
	}
	$r = $stmt->fetch(PDO::FETCH_ASSOC);
	if($r !== false){
		$error = "Bill already exists.";
		return true;
	}else
		return false;
}
/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
function YearlyBillDetails($fid){
		global $msg, $dbh,$fee;
		$sql_select = "SELECT
					tblyearlybill.BillName,
					tblyearlybill.BillAmount,
					tblyearlybill.id
					FROM
					tblyearlybill
					WHERE
					tblyearlybill.id = " . $dbh->quote($fid) . "
					LIMIT 1";
		$stmt = $dbh->query($sql_select);
		if($stmt === false){
			return NULL;
		}
		$r = $stmt->fetchAll(PDO::FETCH_OBJ);
		if($r !== false){
			foreach($r as $fee){}
			return $fee;
		}else
			return null;
}
/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
function OptionalBillDetails($fid){
		global $msg, $dbh,$fee;
		$sql_select = "SELECT
					tbloptbill.BillName,
					tbloptbill.BillAmount,
					tbloptbill.id
					FROM
					tbloptbill
					WHERE
					tbloptbill.id = " . $dbh->quote($fid) . "
					LIMIT 1";
		$stmt = $dbh->query($sql_select);
		if($stmt === false){
			return NULL;
		}
		$r = $stmt->fetchAll(PDO::FETCH_OBJ);
		if($r !== false){
			foreach($r as $fee){}
			return $fee;
		}else
			return null;
}
/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
	function optBill_exist($username,$bill){
	global $msg, $dbh, $error;
	$sql_select = "SELECT
				tbloptionalstudent.stu_id
				FROM
				tbloptionalstudent
				WHERE
				tbloptionalstudent.stu_id = " . $dbh->quote($username) . " AND
				tbloptionalstudent.BillId = " . $dbh->quote($bill) . "
				LIMIT 1";
	$stmt = $dbh->query($sql_select);
	if($stmt === false){
		$error = 'Error querying table';
		return NULL;
	}
	$r = $stmt->fetch(PDO::FETCH_ASSOC);
	if($r !== false){
		return true;
	}else
		return false;
}
/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
function OptBillStu($fid){
		global $msg, $dbh,$fee;
		$sql_select = "SELECT
		tbloptbill.BillName,
		tbloptbill.BillAmount,
		tbloptionalstudent.stu_id,
		student.surname,
		student.firstname,
		stu_class.class_name,
		stu_class.LevelId,
		stu_class.class_id,
		tbloptionalstudent.id,
		tbloptionalstudent.BillId
		FROM
		tbloptionalstudent
		INNER JOIN tbloptbill ON tbloptionalstudent.BillId = tbloptbill.id
		INNER JOIN student ON tbloptionalstudent.stu_id = student.stu_id
		INNER JOIN stu_class ON student.class = stu_class.class_id
		WHERE
		tbloptionalstudent.id = " . $dbh->quote($fid) . "
					LIMIT 1";
		$stmt = $dbh->query($sql_select);
		if($stmt === false){
			return NULL;
		}
		$r = $stmt->fetchAll(PDO::FETCH_OBJ);
		if($r !== false){
			foreach($r as $fee){}
			return $fee;
		}else
			return null;
}
/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
include('func.inc.php');
/*Provoke your inner energy; Challenge yourself and you will achieve amazing things.*/
?>