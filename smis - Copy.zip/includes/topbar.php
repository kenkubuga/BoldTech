<?php date_default_timezone_set("Africa/Accra"); ?>
<header class="header fixed-top clearfix">
<!--logo start-->
<div class="brand">
    <a href="dashboard.php" class="logo">
	<img alt="" src="<?php echo(isset(School()->SchoolLogo))? "school/".School()->SchoolLogo:"school/logo.jpg"; ?>" style="width: 30px; height: 30px;" class="img-circle profile-img">
    <?php echo(isset(School()->SchoolShortName))? School()->SchoolShortName:"SMS"; ?>
    </a>
    <div class="sidebar-toggle-box">
        <div class="fa fa-bars"></div>
    </div>
</div>
<!--logo end-->
<?php
$username=$_SESSION['alogin'];
DEFINE('UID',$username);
?>
<div class="top-nav clearfix">
    <!--search & user info start-->
    <ul class="nav pull-right top-menu">
        <!-- user login dropdown start-->
        <li class="dropdown">
            <a data-toggle="dropdown" class="dropdown-toggle" href="#">
			<?php if(uname_exist1(UID)===true):?>
                <img alt="" src="user/<?php echo htmlentities(User(UID)->photo);?>" style="width: 30px; height: 30px;" class="img-circle profile-img">
			<?php elseif(staff_exist(UID)===true):?>
			    <img alt="" src="staff/default.jpg" style="width: 30px; height: 30px;" class="img-circle profile-img">
			<?php endif;?>
                <span class="username"><?php
				if(uname_exist1(UID)===true):
					echo htmlentities(User(UID)->name);
				elseif(staff_exist(UID)===true):
					echo htmlentities(StaffData(UID)->fullname);
				endif;?></span>
                <b class="caret"></b>
            </a>
            <ul class="dropdown-menu extended logout">
                <li><a href="change-password.php"><i class=" fa fa-lock"></i>Change Password</a></li>
                <li><a href="logout.php"><i class="fa fa-sign-out"></i> Log Out</a></li>
            </ul>
        </li>
        <!-- user login dropdown end -->
    </ul>
    <!--search & user info end-->
</div>
</header>
<!--header end-->