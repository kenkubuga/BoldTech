<?php
session_start();
error_reporting(0);
DEFINE('BASENAMESS',basename(__FILE__));
include('includes/config.php');
if(strlen($_SESSION['alogin'])=="")
    {   
    header("Location: index.php"); 
    }
    else{
		if(isset($_GET['id'])){ DEFINE('CID',$_GET['id']);}else{ DEFINE('CID','');}
		if(isset($_POST['save']))
		{
			$classname=$_POST['classname'];
			$levelname=$_POST['levelname'];
			$sql="INSERT INTO  stu_class(class_name,LevelId) VALUES(:classname,:levelname)";
			$data = array(':classname' => $classname,':levelname' => $levelname);
			$insert = new SchoolData();
			if(classname_exist($classname)===false){
				if($insert->ExecSql($sql,$data)!==false)
				{
				$msg="Class added successfully";
				}
				else 
				{
				$error="Something went wrong. Please try again";
				}
			}
		}
		if(isset($_POST['update']))
		{
			$classname=$_POST['classname'];
			$levelname=$_POST['levelname'];
			$id = $_GET['id'];
			$sql="UPDATE stu_class SET class_name=:classname,LevelId=:levelname WHERE class_id=:id";
			$data = array(':classname' => $classname,':levelname' => $levelname,':id' => $id);
			$insert = new SchoolData();
			if($insert->ExecSql($sql,$data)!==false)
			{
			$msg="Class Udated successfully";
			}
			else 
			{
			$error="Something went wrong. Please try again";
			}	
		}
?>
<!DOCTYPE html>
<head>
<title><?php echo(isset(School()->SchoolName))? School()->SchoolName:"SMS"; ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Kasuli A-L Hotel Management System, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- bootstrap-css -->
<link rel="stylesheet" href="css/bootstrap.min.css" >
<!-- //bootstrap-css -->
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href="css/style-responsive.css" rel="stylesheet"/>
<!-- font CSS -->
<link href='//fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
<!-- font-awesome icons -->
<link rel="stylesheet" href="css/font.css" type="text/css"/>
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons -->
<script src="js/jquery2.0.3.min.js"></script>
  <link href="src/jquery.bootstrap-touchspin.css" rel="stylesheet" type="text/css" media="all">
  <script src="src/jquery.bootstrap-touchspin.js"></script>
</head>
<body>
<section id="container">
<!--header start-->
<?php include('includes/topbar.php');?>
<!--header end-->
<!--sidebar start-->
<?php include('includes/sidebar.php');?>
<!--sidebar end-->
<!--main content start-->
<section id="main-content">
	<section class="wrapper">
		<div class="form-w3layouts">
            <!-- page start-->
            <div class="row">
                <div class="col-lg-12">
                    <section class="panel">
                        <header class="panel-heading">
                            Student Classes
                        </header>
                        <div class="panel-body">
<?php if($msg){?>
<div class="alert alert-success left-icon-alert" role="alert">
 <strong>Well done! </strong><?php echo htmlentities($msg); ?>
 </div><?php } 
else if($error){?>
    <div class="alert alert-danger left-icon-alert" role="alert">
	<strong>Sorry! </strong> <?php echo htmlentities($error); ?>
</div>
<?php } ?>
<form class="form-horizontal" method="post" enctype="multipart/form-data">
			<div class="form-group">    
			<label class="col-md-2 control-label">Level</label>
            <div class="col-md-4">
              <div class="input-group">             
                  <span class="input-group-addon">
              <i class="fa fa-home" aria-hidden="true"></i>
              </span>
			<select name="levelname" class="form-control clid" required="required">
			<option value="<?php echo(isset(ClassData(CID)->LevelId))? ClassData(CID)->LevelId:""; ?>"><?php echo(isset(ClassData(CID)->LevelName))? ClassData(CID)->LevelName:"Select Level"; ?></option>
			<?php $sql = "SELECT id,LevelName from tbllevel";
			$query = $dbh->prepare($sql);
			$query->execute();
			$results=$query->fetchAll(PDO::FETCH_OBJ);
			if($query->rowCount() > 0)
			{
			foreach($results as $result)
			{   ?>
			<option value="<?php echo htmlentities($result->id); ?>"><?php echo htmlentities($result->LevelName); ?></option>
			<?php }} ?>
			 </select>
              </div>
            </div>
            </div>
			<div class="form-group">    
			<label class="col-md-2 control-label">Class Name</label>
            <div class="col-md-4">
              <div class="input-group">             
                  <span class="input-group-addon">
              <i class="glyphicon glyphicon-education" aria-hidden="true"></i>
              </span>
              <input type="text" name="classname" id="classname" title="Enter Full Name of the class" autocomplete="off" value="<?php echo(isset(ClassData(CID)->class_name))? ClassData(CID)->class_name:""; ?>" class="form-control" placeholder="Class Name" required="required">
              </div>
            </div>
            </div>
		<div class="form-group has-success">
			<div class="col-sm-6 col-sm-offset-2">
			   <button type="submit" name="<?php echo(isset(ClassData(CID)->class_id))? "update":"save"; ?>" class="btn btn-success btn-labeled">Save <span class="btn-label btn-label-right"><i class="fa fa-save"></i></span></button>
			</div>
		</div>    
</form>
			</div>
		</section>
	</div>
</div>
<!-- page end-->
</div>
</section>
<!-- footer -->
<?php include('includes/footer.php');?>
  <!-- / footer -->
</section>
<!--main content end-->
</section>
<script src="js/bootstrap.js"></script>
<script src="js/jquery.dcjqaccordion.2.7.js"></script>
<script src="js/scripts.js"></script>
<script src="js/jquery.slimscroll.js"></script>
<script src="js/jquery.nicescroll.js"></script>
<script src="js/jquery.scrollTo.js"></script>
</body>
</html>
<?php }?>