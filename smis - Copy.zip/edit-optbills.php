<?php
session_start();
error_reporting(0);
DEFINE('BASENAMESS',basename(__FILE__));
DEFINE('BASENAMESS',basename(__FILE__));
include('includes/config.php');
if(strlen($_SESSION['alogin'])=="")
    {   
    header("Location: index.php"); 
	}else{ if(isset($_GET['fid'])){ DEFINE('FID',$_GET['fid']);}else{ DEFINE('FID','');}
		if(isset($_POST['submit']))
		{ 
			$feename = clean($_POST['feename']);
			$fee = clean($_POST['fee']);
			$id = clean($_GET['fid']);
			$insert = new SchoolData();
			$sql="UPDATE `tbloptbill` SET `BillName`=:feename,`BillAmount`=:fee WHERE (`id`=:id)";
			$data = array(':feename' => $feename,':fee' => $fee,':id' => $id);
			if($insert->ExecSql($sql,$data)!==false)
			{
				$msg="Optional bill upadated successfully";
			}
			else 
			{
				$error="Something went wrong. Please try again";
			}
		}
?>
<!DOCTYPE html>
<head>
<title><?php echo(isset(School()->SchoolName))? School()->SchoolName:"SMS"; ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Kasuli A-L Hotel Management System, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- bootstrap-css -->
<link rel="stylesheet" href="css/bootstrap.min.css" >
<!-- //bootstrap-css -->
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href="css/style-responsive.css" rel="stylesheet"/>
<!-- font CSS -->
<link href='//fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
<!-- font-awesome icons -->
<link rel="stylesheet" href="css/font.css" type="text/css"/>
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons -->
<script src="js/jquery2.0.3.min.js"></script>
  <link href="src/jquery.bootstrap-touchspin.css" rel="stylesheet" type="text/css" media="all">
  <script src="src/jquery.bootstrap-touchspin.js"></script>
	<script>
		function getAcyear(val) {
    $.ajax({
    type: "POST",
    url: "y.php",
    data:'billid='+val,
    success: function(data){
        $("#acyearlvl").html(data);
        
    }
    });
		$.ajax({
        type: "POST",
        url: "smsStudent.php",
        data:'classid1='+val,
        success: function(data){
            $("#subject").html(data);
            
        }
        });
}
    </script>
<script language=Javascript>
   <!--
   function isNumberKey(evt,element)
   {
	  var charCode = (evt.which) ? evt.which : evt.keyCode;
	  if ((charCode != 46 || $(element).val().indexOf('.') != -1) && charCode > 31 
		&& (charCode < 48 || charCode > 57))
		 return false;

	  return true;
   }
   //-->
</script>
</head>
<body>
<section id="container">
<!--header start-->
<?php include('includes/topbar.php');?>
<!--header end-->
<!--sidebar start-->
<?php include('includes/sidebar.php');?>
<!--sidebar end-->
<!--main content start-->
<section id="main-content">
	<section class="wrapper">
		<div class="form-w3layouts">
            <!-- page start-->
            <div class="row">
                <div class="col-lg-12">
                    <section class="panel">
                        <header class="panel-heading">
                            Update Optional Bills
                        </header>
                        <div class="panel-body">
<?php if($msg){?>
<div class="alert alert-success left-icon-alert" role="alert">
 <strong>Well done! </strong><?php echo htmlentities($msg); ?>
 </div><?php } 
else if($error){?>
    <div class="alert alert-danger left-icon-alert" role="alert">
	<strong>Sorry! </strong> <?php echo htmlentities($error); ?>
</div>
<?php } ?>
		<form method="post" enctype="multipart/form-data" action="" class="form-horizontal">
			<div class="form-group">    
			<label class="col-md-2 control-label">Optional Bill Name</label>
            <div class="col-md-6">
              <div class="input-group">             
                  <span class="input-group-addon">
              <i class="fa fa-user" aria-hidden="true"></i>
              </span>
              <input type="text" value="<?php echo(isset(OptionalBillDetails(FID)->BillName))? OptionalBillDetails(FID)->BillName:""; ?>" name="feename" class="form-control" id="feename" maxlength="50" required="required" autocomplete="off">
              </div>
            </div>
            </div>
			<div class="form-group">    
			<label class="col-md-2 control-label">Optional Bill Amount</label>
            <div class="col-md-6">
              <div class="input-group">             
                  <span class="input-group-addon">
              <i class="fa fa-money" aria-hidden="true"></i>
              </span>
              <input type="text" value="<?php echo(isset(OptionalBillDetails(FID)->BillAmount))? OptionalBillDetails(FID)->BillAmount:""; ?>" name="fee" class="form-control" id="fee" onkeypress="return isNumberKey(event,this)"  maxlength="10" required="required" autocomplete="off">
              </div>
            </div>
            </div>
		<div class="row">
			<div class="col-sm-8 col-sm-offset-2">
				<button type="submit" name="submit" class="btn-primary btn">Submit</button>
				<button type="reset" class="btn-inverse btn">Reset</button>
			</div>
		</div>
	</form>
			</div>
		</section>
	</div>
</div>
<!-- page end-->
</div>
</section>
<!-- footer -->
<?php include('includes/footer.php');?>
  <!-- / footer -->
</section>
<!--main content end-->
</section>
<script src="js/bootstrap.js"></script>
<script src="js/jquery.dcjqaccordion.2.7.js"></script>
<script src="js/scripts.js"></script>
<script src="js/jquery.slimscroll.js"></script>
<script src="js/jquery.nicescroll.js"></script>
<script src="js/jquery.scrollTo.js"></script>
</body>
</html>
<?php }?>