<?php
session_start();
error_reporting(0);
include('includes/config.php');
DEFINE('BASENAMESS',basename(__FILE__));
if(strlen($_SESSION['alogin'])=="")
    {   
    header("Location: index.php"); 
    }
    else{
		if(isset($_POST['submit']))
		{
			$class = clean($_POST['classid']);
			$classid = clean($_POST['acyearlvl']);
?>
<!DOCTYPE html>
<head>
<title><?php echo(isset(School()->SchoolName))? School()->SchoolName:"SMS"; ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Kasuli A-L Hotel Management System, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- bootstrap-css -->
<link rel="stylesheet" type="text/css" href="js/DataTables/datatables.min.css"/>
<link rel="stylesheet" href="css/bootstrap.min.css" >
<!-- //bootstrap-css -->
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href="css/style-responsive.css" rel="stylesheet"/>
<!-- font CSS -->
<link href='//fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
<!-- font-awesome icons -->
<link rel="stylesheet" href="css/kas.css" type="text/css"/>
<link rel="stylesheet" href="css/font.css" type="text/css"/>
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons -->
<script src="js/jquery2.0.3.min.js"></script>
<link href="src/jquery.bootstrap-touchspin.css" rel="stylesheet" type="text/css" media="all">

<!--for the new datatable   -->
<link href="//cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css" rel="stylesheet">
<link href="//cdn.datatables.net/buttons/2.2.3/css/buttons.dataTables.min.css" rel="stylesheet">
<!--end for the new datatable   -->
<script src="src/jquery.bootstrap-touchspin.js"></script>
<script type="text/javascript">
function PrintDiv(id) {
	var data=document.getElementById(id).innerHTML;
	var myWindow = window.open('', '<?php echo(isset(School()->SchoolName))? School()->SchoolName:"SMS"; ?>', 'height=4000,width=6000');
	myWindow.document.write('<html><head><title><?php echo(isset(School()->SchoolName))? School()->SchoolName:"SMS"; ?></title>');
	myWindow.document.write('<link rel="stylesheet" href="css/font-awesome.min.css" media="screen" >');
	myWindow.document.write('<link rel="stylesheet" href="css/bootstrap.min.css" type="text/css" />');
	myWindow.document.write('<link rel="stylesheet" href="css/font.css" media="screen" >');
	myWindow.document.write('<link rel="stylesheet" href="css/style-responsive.css" media="screen" >');
	myWindow.document.write('<link rel="stylesheet" href="css/style.css" type="text/css" />');
	myWindow.document.write('<link rel="stylesheet" href="css/kas.css" type="text/css" />');
	myWindow.document.write('</head><body >');
	myWindow.document.write(data);
	myWindow.document.write('</body></html>');
	myWindow.document.close(); // necessary for IE >= 10

	myWindow.onload=function(){ // necessary if the div contain images

		myWindow.focus(); // necessary for IE >= 10
		myWindow.print();
		myWindow.close();
	};
}
</script>
</head>
<body>
<section id="container">
<!--header start-->
<?php include('includes/topbar.php');?>
<!--header end-->
<!--sidebar start-->
<?php include('includes/sidebar.php');?>
<!--sidebar end-->
<!--main content start-->
<section id="main-content">
	<section class="wrapper">
		<div class="form-w3layouts">
            <!-- page start-->
            <div class="row">
                <div class="col-lg-12">
                    <section class="panel">
                        <header class="panel-heading">
                            Students
                        </header>
                        <div class="panel-body">
<?php if($msg){?>
<div class="alert alert-success left-icon-alert" role="alert">
 <strong>Well done! </strong><?php echo htmlentities($msg); ?>
 </div><?php } 
else if($error){?>
    <div class="alert alert-danger left-icon-alert" role="alert">
	<strong>Oh snap! </strong> <?php echo htmlentities($error); ?>
</div>
<?php } ?>
<!--<div class="col-ms-offset-2 col-ms-10">                                                           
	<button class="btn btn-success btn-labeled pull-right" onclick="PrintDiv('result')">Print <span class="btn-label btn-label-right"><i class="fa fa-print"></i></span></button>
</div>

<br>-->
<div id ='result'>
<center><?php echo htmlentities(class_name($classid).' Students');?></center>
	<table id="example" class="gridtable" cellspacing="0" width="100%">
			<thead>
				<tr>
					<th>#</th>
					<th>Sch. Num.</th>
					<th>Student name</th>
					<th>Class</th>
					<th>Guardian name</th>
					<th>Contact</th>
					<th class="noprint">Action</th>
				</tr>
			</thead>
			<tbody>
<?php $sql = "SELECT
student.id,
student.stu_id,
student.surname,
student.firstname,
student.class,
student.guardian_name,
student.guardian_contact,
student.fees_paid,
stu_class.class_id,
stu_class.class_name,
stu_class.class_total_fee
FROM
student
INNER JOIN stu_class ON student.class = stu_class.class_id
WHERE student.class=:classid";
$query = $dbh->prepare($sql);
$query->bindParam(':classid',$classid,PDO::PARAM_STR);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{   ?>
<tr>
	<td><?php echo htmlentities($cnt);?></td>
	<td><?php echo htmlentities($result->stu_id);?></td>
	<td><?php echo htmlentities($result->surname);?> <?php echo htmlentities($result->firstname);?></td>
	<td><?php echo htmlentities($result->class_name);?></td>
	<td><?php echo str_replace('\' ', '\'', ucwords(str_replace('\'', '\' ', strtolower($result->guardian_name))));?></td>
	<td><?php echo htmlentities($result->guardian_contact);?></td>
	<td class="noprint"><a class="btn btn-default btn-sm" href="studentview.php?action=<?php echo htmlentities(icrypt($result->stu_id,'e'))?>"><i class="fa fa-eye" style="font-size:15px;color:black" title="View Student details"></i> </a></td>
</tr>
<?php $cnt=$cnt+1;}} ?>
			</tbody>
</table>
</div>
</div>
</section>
</div>
</div>
<!-- page end-->
</div>
</section>
<!-- footer -->
<?php include('includes/footer.php');?>
  <!-- / footer -->
</section>
<!--main content end-->
</section>
	
<script src="//code.jquery.com/jquery-3.5.1.js"></script>
<script src="//cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
<script src="//cdn.datatables.net/buttons/2.2.3/js/dataTables.buttons.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script src="//cdn.datatables.net/buttons/2.2.3/js/buttons.html5.min.js"></script>
<script src="//cdn.datatables.net/buttons/2.2.3/js/buttons.print.min.js"></script>
<script>
$(document).ready(function() {
    $('#example').DataTable( {
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ]
    } );
} );
</script>
<script src="js/bootstrap.js"></script>
<script src="js/jquery.dcjqaccordion.2.7.js"></script>
<script src="js/scripts.js"></script>
<script src="js/jquery.slimscroll.js"></script>
<script src="js/jquery.nicescroll.js"></script>
<script src="js/jquery.scrollTo.js"></script>
</body>
</html>
	<?php }}?>