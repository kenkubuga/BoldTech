<?php
session_start();
session_regenerate_id();
error_reporting(0);
include('includes/config.php');
DEFINE('BASENAMESS',basename(__FILE__));
if(strlen($_SESSION['alogin'])=="")
    {   
    header("Location: index.php"); 
    }
    else{
		$username=$_SESSION['alogin'];
		DEFINE('UIDs',$username);
		if(uname_exist1(UIDs)===true)
		{
			$cashier=(User(UIDs)->name);
		}
		elseif(staff_exist(UIDs)===true)
		{
			if(IsCashier(UIDs)===true)
			{
				$cashier=StaffData(UIDs)->staff_id;
			}
			else
			{
				echo "<script>alert('Sorry!! You have no right to Reverse any transaction');</script>";
				echo "<script type='text/javascript'> document.location = 'logout.php'; </script>";
			}
		}
		else
		{
			echo "<script>alert('Sorry!! You're not a user in the system');</script>";
			echo "<script type='text/javascript'> document.location = 'logout.php'; </script>";
		}
		if(isset($_POST['submit']))
		{
			$level = clean($_POST['classid']);
			$classid = clean($_POST['acyearlvl']);
			$term = CurrentTerm();
			$acyear = CurrentACYear();
			$insert = new SchoolData();
			$Rdate=date('Y-m-d');
			$studentid = clean($_POST['studentid']);
			define('STID',$studentid);
			$reason = clean($_POST['reason']);
			$fee = clean($_POST['fee']);
			$feea = clean($_POST['fee']);
			$fee=($fee*(-1));
			$transtype='Reversal';
			if(todaypay_reverse(STID,$Rdate)===false)
			{
				$error="The Selected student has not made any payment today";
			}
			else
			{
			    $ini_fee=ArrearsAmount1(STID);
				$bal=ArrearsAmount1(STID)+$feea;
				$sql="INSERT INTO  tblfeepayment(stu_id,transtype,classid,term,initialamount,amount,balance,Rdate,cashier,acyear,reason,status)
				VALUES(:studentid,:transtype,:classid,:term,:initialamount,:amount,:balance,:Rdate,:cashier,:acyear,:reason,:status)";
				$data = array(':studentid' => $studentid,':transtype' => $transtype,':classid' => $classid
				,':term' => $term,':initialamount' => $ini_fee,':amount' => $fee,':balance' => $bal,':Rdate' => $Rdate,':cashier' => $cashier,':acyear' => $acyear,':reason' => $reason,':status'=>'pending');
				if($insert->ExecSql($sql,$data)!==false)
				{
					//$termbill=TotalTermlyBill(STID);
					//$feepaid=TermlyFeePaid(STID);
					//$arrears=($termbill-$feepaid);
					//Update_Arrears($studentid,$arrears,$term);
					$FID=Penalty_BillId(STID);
					$FID=icrypt($FID,'e');
					$msg="Reversal Successfully Initiated Pending Approval";
				}
				else
				{
					$error="Something went wrong! Please try again.";
				}
			}
		}
?>
<!DOCTYPE html>
<head>
<title><?php echo(isset(School()->SchoolName))? School()->SchoolName:"SMS"; ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Kasuli A-L Hotel Management System, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- bootstrap-css -->
<link rel="stylesheet" href="css/bootstrap.min.css" >
<!-- //bootstrap-css -->
<!-- Custom CSS -->
<link rel="stylesheet" type="text/css" href="dp/jquery.datetimepicker.css"/>
<link rel="stylesheet" href="css/select2/select2.min.css" >
<link rel="stylesheet" href="css/select2/select2.js" >
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href="css/style-responsive.css" rel="stylesheet"/>
<!-- font CSS -->
<link href='//fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
<!-- font-awesome icons -->
<link rel="stylesheet" href="css/font.css" type="text/css"/>
<link rel="stylesheet" href="css/kas.css" type="text/css"/>
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons -->
<script src="js/jquery2.0.3.min.js"></script>
  <link href="src/jquery.bootstrap-touchspin.css" rel="stylesheet" type="text/css" media="all">
  <script src="src/jquery.bootstrap-touchspin.js"></script>
<script>
function getAcyear(val) {
$.ajax({
type: "POST",
url: "y.php",
data:'classid='+val,
success: function(data){
$("#acyearlvl").html(data);

}
});
}
</script>
<!-- script -->
<script>
function getClass(val) {
$.ajax({
type: "POST",
url: "t.php",
data:'classid1='+val,
success: function(data){
$("#studentid").html(data);

}
});
}
</script>
<script>
function getStudent(val) 
{     
$.ajax({
type: "POST",
url: "t.php",
data:'billstudent='+val,
success: function(data){
	$("#reslt").html(data);
	
}
});
}
</script>
<script language=Javascript>
   <!--
   function isNumberKey(evt,element)
   {
	  var charCode = (evt.which) ? evt.which : evt.keyCode;
	  if ((charCode != 46 || $(element).val().indexOf('.') != -1) && charCode > 31 
		&& (charCode < 48 || charCode > 57))
		 return false;

	  return true;
   }
   //-->
</script>

</head>
<body>
<section id="container">
<!--header start-->
<?php include('includes/topbar.php');?>
<!--header end-->
<!--sidebar start-->
<?php include('includes/sidebar.php');?>
<!--sidebar end-->
<!--main content start-->
<section id="main-content">
	<section class="wrapper">
		<div class="form-w3layouts">
            <!-- page start-->
            <div class="row">
                <div class="col-lg-12">
                    <section class="panel">
                        <header class="panel-heading">
                            Reverse Payment
                        </header>
                        <div class="panel-body">
<?php if($msg){?>
<div class="alert alert-success left-icon-alert" role="alert">
 <strong>Well done! </strong><?php echo htmlentities($msg); ?>
 </div><?php } 
else if($error){?>
    <div class="alert alert-danger left-icon-alert" role="alert">
	<strong>Sorry! </strong> <?php echo htmlentities($error); ?>
</div>
<?php } ?>
<form method="post" enctype="multipart/form-data" action="" class="form-horizontal">
<div class="col-md-7">
	<div class="form-group">    
	<label class="col-md-4 control-label">Level</label>
	<div class="col-md-8">
	  <div class="input-group">             
		  <span class="input-group-addon">
	  <i class="fa fa-wpforms" aria-hidden="true"></i>
	  </span>
	  <select name="classid" id="classid" required="required" onChange="getAcyear(this.value);" class="form-control clid">
	 <option value="">Select Level</option>
	<?php $sql = "SELECT id,LevelName from tbllevel";
	$query = $dbh->prepare($sql);
	$query->execute();
	$results=$query->fetchAll(PDO::FETCH_OBJ);
	if($query->rowCount() > 0)
	{
	foreach($results as $result)
	{   ?>
	<option value="<?php echo htmlentities($result->id); ?>"><?php echo htmlentities($result->LevelName); ?></option>
	<?php }} ?>
	 </select>
	  </div>
	</div>
	</div>
	<div class="form-group">    
	<label class="col-md-4 control-label">Class</label>
	<div class="col-md-8">
	  <div class="input-group">             
		  <span class="input-group-addon">
	  <i class="fa fa-bar-chart-o" aria-hidden="true"></i>
	  </span>
	  <select name="acyearlvl" id="acyearlvl" required="required" onChange="getClass(this.value)" class="form-control acyearlvl">

	  </select>
	  </div>
	</div>
	</div>
	<div class="form-group">    
	<label class="col-md-4 control-label">Student</label>
	<div class="col-md-8">
	  <div class="input-group">             
		  <span class="input-group-addon">
	  <i class="fa fa-female" aria-hidden="true"></i>
	  </span>
	  <select name="studentid" id="studentid" required="required" OnChange="getStudent(this.value)" class="form-control select2">
	  </select>
	  </div>
	</div>
	</div>
	<div class="form-group">    
	<label class="col-md-4 control-label">Reason for reverse</label>
	<div class="col-md-8">
	  <div class="input-group">             
		  <span class="input-group-addon">
	  <i class="fa fa-file-text" aria-hidden="true"></i>
	  </span>
	  <input type="text" value="" name="reason" class="form-control" id="feename" maxlength="50" required="required" autocomplete="off">
	  </div>
	</div>
	</div>
	
	<div class="form-group">    
	<label class="col-md-4 control-label">Amount to be reversed</label>
	<div class="col-md-8">
	  <div class="input-group">             
		  <span class="input-group-addon">
	  <i class="fa fa-money" aria-hidden="true"></i>
	  </span>
	  <input type="text" value="" name="fee" class="form-control" id="fee" onkeypress="return isNumberKey(event,this)"  maxlength="10" required="required" autocomplete="off">
	  </div>
	</div>
	</div>
	
<div class="row">
	<div class="col-sm-8 col-sm-offset-4">
		<button type="submit" id="submit" name="submit" class="btn-primary btn">Submit</button>
		<button type="reset" class="btn-inverse btn">Reset</button>
	</div>
</div>
</div>
<div class="col-md-5">
<div id="reslt">

</div>
</div>
</form>

		</div>
	</div>
</div>
</div>
</div>

			</div>
		</section>
	</div>
</div>
<!-- page end-->
</div>
</section>
<!-- footer -->
<?php include('includes/footer.php');?>
  <!-- / footer -->
</section>
<!--main content end-->
</section>
<script src="js/bootstrap.js"></script>
<script src="js/jquery.dcjqaccordion.2.7.js"></script>
<script src="js/scripts.js"></script>
<script src="js/jquery.slimscroll.js"></script>
<script src="js/jquery.nicescroll.js"></script>
<script src="js/jquery.scrollTo.js"></script>
</body>
</html>
<?php }?>