<?php 
include('includes/config.php');

		if(!$dbh) {
		    echo "not connected";
	
		 //$erroroccured='Could not connect to the database.';
		//echo json_encode($erroroccured);
		} else {
		    @extract($_REQUEST);
		    //$action_type='get_detail_by_name';
            if(!empty($_POST['action_type'])){
            	$action_type=$_POST['action_type'];
            	switch($action_type){
            		case "get_detail_by_cashier":
                        $date=date('Y-m-d');
                        //$date='2022/07/20';
                        $sql = "SELECT
                        DISTINCT tblfeepayment.cashier,
                        tblfeepayment.Rdate,
                        staff.fullname
                        FROM
                        tblfeepayment
                        INNER JOIN staff ON tblfeepayment.cashier = staff.staff_id
                        WHERE
                        tblfeepayment.Rdate = :a";
                        $query = $dbh->prepare($sql);
                        $query->bindParam(':a', $date);
                        $query->execute();
                        $results=$query->fetchAll(PDO::FETCH_OBJ);
                        if($query->rowCount() > 0)
                        {
                        echo json_encode($results);
                        //print_r($results);
                        }
            		
            			/*$query = "SELECT * FROM borrowers WHERE account=:pattern";
            				$stmt = $db->prepare($query);
            				//$params = array("%$queryString%");
            				$stmt->execute([':pattern' => $name]);
            				//$stmt->execute($params);
            				$result = $stmt ->fetchAll(PDO::FETCH_ASSOC);
            				foreach ($result as $bio) {
            					//$detail = array('type'=>'Success','bar_code'=>$book['fname']);
            					$detail = array('type'=>'Success','fname'=>$bio['fname'],'lname'=>$bio['lname'],'phone'=>$bio['phone'],'balance'=>$bio['balance'],'image'=>$bio['image'],'dob'=>$bio['dob'],'occupation'=>$bio['occupation'],'hn'=>$bio['hn'],'loc'=>$bio['loc'],'gps'=>$bio['gps'],'mstatus'=>$bio['mstatus'],'ndependent'=>$bio['ndependent'],'eincome'=>$bio['eincome']);
            				
            					echo json_encode($detail);
            						//echo $book['fname'];
            					}*/
            			
            			
            			/*$sql = $db->query("SELECT * FROM borrowers WHERE account = '$name'");
            			$numRow = $sql->num_rows;
            			if($numRow > 0){
            				//$row = $sql->fetch_array();
            				while($row = $sql->fetch_array()){
            					  echo $row['fname'];
            					}
            				//$detail = array('type'=>'Success','bar_code'=>$row['fname']);
            				
            				//echo json_encode($detail);	
            			}else{
            				echo "not found";
            			}*/
            			
            			break;
            		case "get_detail_by_name":
            		        $cashierid=$_POST['cashierid'];
            		        $date=date('Y-m-d');
            		        //$date='2022-07-20';
                            $sql = "SELECT
                            tblfeepayment.stu_id,
                            tblfeepayment.id,
                            tblfeepayment.transtype,
                            tblfeepayment.classid,
                            tblfeepayment.term,
                            tblfeepayment.amount,
                            tblfeepayment.Rdate,
                            tblfeepayment.cashier,
                            tblfeepayment.acyear,
                            tblfeepayment.reason,
                            staff.fullname,
                            student.surname,
                            student.firstname
                            FROM
                            tblfeepayment
                            INNER JOIN staff ON tblfeepayment.cashier = staff.staff_id
                            INNER JOIN student ON tblfeepayment.stu_id = student.stu_id
                            WHERE
                            tblfeepayment.Rdate = :a AND tblfeepayment.cashier=:b";
                            $query = $dbh->prepare($sql);
                            $query->bindParam(':a', $date);
                            $query->bindParam(':b', $cashierid);
                            $query->execute();
                            $results=$query->fetchAll(PDO::FETCH_OBJ);
                            if($query->rowCount() > 0)
                            {
                            echo json_encode($results);
                            //print_r($results);
                            }
                		
                			/*$query = "SELECT * FROM borrowers WHERE account=:pattern";
                				$stmt = $db->prepare($query);
                				//$params = array("%$queryString%");
                				$stmt->execute([':pattern' => $name]);
                				//$stmt->execute($params);
                				$result = $stmt ->fetchAll(PDO::FETCH_ASSOC);
                				foreach ($result as $bio) {
                					//$detail = array('type'=>'Success','bar_code'=>$book['fname']);
                					$detail = array('type'=>'Success','fname'=>$bio['fname'],'lname'=>$bio['lname'],'phone'=>$bio['phone'],'balance'=>$bio['balance'],'image'=>$bio['image'],'dob'=>$bio['dob'],'occupation'=>$bio['occupation'],'hn'=>$bio['hn'],'loc'=>$bio['loc'],'gps'=>$bio['gps'],'mstatus'=>$bio['mstatus'],'ndependent'=>$bio['ndependent'],'eincome'=>$bio['eincome']);
                				
                					echo json_encode($detail);
                						//echo $book['fname'];
                					}*/
                			
                			
                			/*$sql = $db->query("SELECT * FROM borrowers WHERE account = '$name'");
                			$numRow = $sql->num_rows;
                			if($numRow > 0){
                				//$row = $sql->fetch_array();
                				while($row = $sql->fetch_array()){
                					  echo $row['fname'];
                					}
                				//$detail = array('type'=>'Success','bar_code'=>$row['fname']);
                				
                				//echo json_encode($detail);	
                			}else{
                				echo "not found";
                			}*/
            		break;
            		}
            		
            }
			
	
		}
		
?>