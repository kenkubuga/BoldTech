function all() 
{
	// Ajax config
	var formData={
			action_type:"get_detail_by_cashier"
		}
	$.ajax({
	    
        type: "POST", //we are using GET method to get all record from the server
        url: 'ajax_details.php', // get the route value
        data:formData,
        cache:false,
        beforeSend: function () {//We add this before send to disable the button once we submit it so that we prevent the multiple click
            //ajaxLoader("#employees-list", "show");
        },
         
        success: function (response) {//once the request successfully process to the server side it will return result here
            
            // Parse the json result
        	response = JSON.parse(response);

            var html = "";
            // Check if there is available records
            if(response.length) {
				
	            // Loop the parsed JSON
				html += '<option value="">Select Cashier</option>';
	            $.each(response, function(key,value) {
					html += '<option value='+value.cashier+'>'+value.fullname+'</option>';
					//alert(value.cashier);
				
					
				
	            });
				
            } else {
            	html += '<div class="alert alert-warning">';
				  html += 'No records found!';
				html += '</div>';
            }

            // Insert the HTML Template and display all employee records
			$("#cashier").html(html);
        },
        complete: function() {
        	//ajaxLoader("#employees-list", "hide");
        }
    });
}
function getInfor() 
{
	$("#cashier").on("change", function() {
		var $actionEl = $(this);
		// Get our action value
		var action = $actionEl.val();
		// Ajax config
		console.log(action);
		if(action !==""){
        	var formData={
        			action_type:"get_detail_by_name",
        			cashierid:action
        		}
        		
        	$.ajax({
        	    
                type: "POST", //we are using GET method to get all record from the server
                url: 'ajax_details.php', // get the route value
                data:formData,
                cache:false,
                beforeSend: function () {//We add this before send to disable the button once we submit it so that we prevent the multiple click
                    //ajaxLoader("#employees-list", "show");
                },
                success: function (response) {//once the request successfully process to the server side it will return result here
                    
                    // Parse the json result
                	response = JSON.parse(response);
        
                    var html = "";
                    var cn=1;
                    var totalamount=0;
                    // Check if there is available records
                    if(response.length) {
        				
        	            // Loop the parsed JSON
        				html += '<table id="example" class="gridtable" cellspacing="0" width="100%"><thead><tr> <th>#</th><th>Sch. Num.</th><th>Name</th><th>Description</th><th>Type</th><th>Amount</th><th>Date</th><th>Cashier</th> <th>Action</th></tr></thead><tbody>';
        	            $.each(response, function(key,value) {
        					html += '<tr>';
        					html += '<td>'+cn+'</td>'
        					html += '<td>'+value.stu_id+'</td>';
        					html += '<td>'+value.surname+' '+value.firstname+'</td>';
        					html += '<td>'+value.reason+'</td>';
        					html += '<td>'+value.transtype+'</td>';
        					html += '<td>'+value.amount+'</td>';
        					html += '<td>'+value.Rdate+'</td>';
        					html += '<td>'+value.fullname+'</td>';
        					html += '<td><a href="all.php?action='+value.id+'" class="btn btn-info btn-sm btn-labeled pull-left"><i class="fa fa-eye" style="font-size:15px;color:white" title="View Student fee payment Receipt"></i></a> </td>';
        					html += '</tr>';
        					cn++;
        					totalamount += parseFloat(value.amount);
        	            });
        	            html +='<tr>';
        	            html += '<th colspan="5">Total Payments Today :</td>';
        	            html += '<th>'+'GH₵ '+totalamount+'</td>';
        	            html +='</tr>';
        				html +="</tbody></table>";
                    } else {
                    	html += '<div class="alert alert-warning">';
        				  html += 'No records found!';
        				html += '</div>';
                    }
        
                    // Insert the HTML Template and display all employee records
                    $('#cashier3').css('display', 'none');
        			$("#cashier2").html(html);
                },
                complete: function() {
                	//ajaxLoader("#employees-list", "hide");
                }
            });
		}
	});
}

$(document).ready(function() {
    $.ajaxSetup({
    cache: false
    });
	all();
	getInfor();
	//alert("Page connected");
});