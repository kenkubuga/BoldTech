<?php
session_start();
//error_reporting(0);
DEFINE('BASENAMESS',basename(__FILE__));
include('includes/config.php');
require_once "kasulixlsx.class.php";
if(strlen($_SESSION['alogin'])=="")
    {   
    header("Location: index.php"); 
    }
    else{
		if(isset($_POST['submit']))
		{
			$class = clean($_POST['classid']);
			$acyearlvl = clean($_POST['acyearlvl']);
			$term = clean($_POST['term']);
			$week = clean($_POST['week']);
			$acyear = clean($_POST['acyear']);
			//$studentid = $_POST['studentid'];
			$acyearlv = class_name($acyearlvl);
			$filename=$acyearlv.$term.$week.$acyear;
			$filename = preg_replace('/\s+/', '', $filename);
			$filename = "uploads2/".$filename.".xlsx";
			if (!file_exists($filename)) {
				echo "<script>alert('No results found for the selected class');</script>";
			echo "<script type='text/javascript'> document.location = 'classresultwk.php'; </script>";
			} else {
?>
<!DOCTYPE html>
<head>
<title><?php echo(isset(School()->SchoolName))? School()->SchoolName:"SMS"; ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Kasuli A-L Hotel Management System, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- bootstrap-css -->
<link rel="stylesheet" type="text/css" href="js/DataTables/datatables.min.css"/>
<link rel="stylesheet" href="css/bootstrap.min.css" >
<!-- //bootstrap-css -->
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href="css/style-responsive.css" rel="stylesheet"/>
<!-- font CSS -->
<link href='//fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
<!-- font-awesome icons -->
<link rel="stylesheet" href="css/kas.css" type="text/css"/>
<link rel="stylesheet" href="css/font.css" type="text/css"/>
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons -->
<script src="js/jquery2.0.3.min.js"></script>
<link href="src/jquery.bootstrap-touchspin.css" rel="stylesheet" type="text/css" media="all">
<script src="src/jquery.bootstrap-touchspin.js"></script>
<script type="text/javascript">
function printDiv(id) {
	var data=document.getElementById(id).innerHTML;
	var myWindow = window.open('', '<?php echo(isset(School()->SchoolName))? School()->SchoolName:"SMS"; ?>', 'height=4000,width=6000');
	myWindow.document.write('<html><head><title><?php echo(isset(School()->SchoolName))? School()->SchoolName:"SMS"; ?></title>');
	myWindow.document.write('<link rel="stylesheet" href="css/font-awesome.min.css" media="screen" >');
	myWindow.document.write('<link rel="stylesheet" href="css/bootstrap.min.css" type="text/css" />');
	myWindow.document.write('<link rel="stylesheet" href="css/font.css" media="screen" >');
	myWindow.document.write('<link rel="stylesheet" href="css/style-responsive.css" media="screen" >');
	myWindow.document.write('<link rel="stylesheet" href="css/style.css" type="text/css" />');
	myWindow.document.write('<link rel="stylesheet" href="css/kprint.css" type="text/css" />');
	myWindow.document.write('<link rel="stylesheet" href="css/kas.css" type="text/css" />');
	myWindow.document.write('</head><body >');
	myWindow.document.write(data);
	myWindow.document.write('</body></html>');
	myWindow.document.close();
	myWindow.onload=function(){
		myWindow.focus();
		myWindow.print();
		myWindow.close();
	};
}
</script>
</head>
<body>
<section id="container">
<!--header start-->
<?php include('includes/topbar.php');?>
<!--header end-->
<!--sidebar start-->
<?php include('includes/sidebar.php');?>
<!--sidebar end-->
<!--main content start-->
<section id="main-content">
<section class="wrapper">
<div class="form-w3layouts">
<!-- page start-->
<div class="row">
    <div class="col-lg-12"> <section class="panel"> <header class="panel-heading"> 
      <?php
echo htmlentities(class_name($acyearlvl)." Summary Weekly Class results");?>
      </header> 
      <div class="panel-body"> 
        <?php if($msg){?>
        <div class="alert alert-success left-icon-alert" role="alert"> <strong>Well 
          done! </strong> 
          <?php echo htmlentities($msg); ?>
        </div>
        <?php } 
else if($error){?>
        <div class="alert alert-danger left-icon-alert" role="alert"> <strong>Oh 
          snap! </strong> 
          <?php echo htmlentities($error); ?>
        </div>
        <?php } ?>
        <div class="col-ms-offset-2 col-ms-10 noprint"> 
          <button class="btn btn-success btn-labeled pull-right" onclick="printDiv('result')">Print 
          <span class="btn-label btn-label-right"><i class="fa fa-print"></i></span></button>
        </div>
        <br>
        <div id ='result' class="noprint"> 
          <center>
            <b> 
            <?php echo htmlentities(strtoupper(class_name($acyearlvl)." Student results"));?>
            </b> 
          </center>
          <br>
          <table cellspacing="0" width="90%">
            <tr height="40"> 
              <td align="center"> <b>ACADEMIC YEAR: 
                <?php echo $acyear; ?>
                </b> </td>
              <td valign="center"> <b>TERM: 
                <?php echo " ".$term;?>
                </b> </td>
            </tr>
          </table>
          <br>
          <?php
 $stmt = $dbh->prepare("SELECT
tblsubject.ShortName,
tblsubject.`Status`,
tblsubcombination.Classid
FROM
tblsubject
INNER JOIN tblsubcombination ON tblsubject.id = tblsubcombination.SubjectId
WHERE
tblsubcombination.Classid = 8
ORDER BY
tblsubject.`Status` ASC");
 $stmt->execute(array(':cid' => $acyearlvl));
 $count=$stmt->rowCount();
 ?>
<table id="example" class="gridtable" cellspacing="0" width="100%">              
            <thead>
              <tr> 


    </thead>
	</tr>		
 </table>

<table border="1" width="100%">

</table>
	          <?php 

				$xlsx = KasuliXLSX::parse($filename);
		$sheetnames = $xlsx->sheetNames();
		$totalsheets=(sizeof($sheetnames)-2);

			echo "<table class='resulttable' cellspacing='0' width='100%'>
			  <tbody>
				<tr>
                <th width='10.5%'>Name</th>
                <th width='4%' >Stu. ID.</th>
			
			";
					for ($k = 0; $k <= $totalsheets; $k++)
					{
						
						 echo "<th colspan='3' width='6%' style='text-align:center;'>".strtoupper(substr($sheetnames[$k],0,1)).strtolower(substr($sheetnames[$k],1,2))."</th>"; 

					}

					
					echo " <th width='2%'>Tot</th>
			                <th width='2%'>Pos</th>
			    </tr>
				<tr>
                <th width='10.5%'></th>
                <th width='4%'></th>
			
			";
					for ($k = 0; $k <= $totalsheets; $k++)
					{
						
						   echo "<td width='2%'>".'CA'."</td>";
						   echo "<td width='2%'>".'EOT'."</td>";
						   echo "<td width='2%'>".'Tot'."</td>";
					}

					
					echo " <th width='2%'></th>
			                <th width='2%'></th>
			    </tr>"; 


			?>



              <?php
	if ( $xlsx = KasuliXLSX::parse($filename) ) {
		$sheetnames = $xlsx->sheetNames();
		$totalsheets=(sizeof($sheetnames)-2);
		$sheetname = $xlsx->sheetNames();
		end($sheetname);
		$key = key($sheetname);
		$f = 0;
			foreach($xlsx->rows($key) as $result)
			{
						if ($f == 0)
						{
							$f++;
							continue;
						}
				$studentid =$result[0];
				?>
              <tr> 
                <td width="10.5%"> 
                  <?php echo htmlentities($result[1]);?>
                </td>
                <td width="4%"> 
                  <?php echo htmlentities($result[0]);?>
                </td>
                <?php 
				for ($k = 0; $k <= $totalsheets; $k++)
				{
					foreach ( $xlsx->rows($k) as $row ) 
					{
						if($row[0] == $studentid){
						   echo "<td width='1.5%'>".( ( isset( $row[3] ) ) ? $row[3] : '&nbsp;' )."</td>";
						   echo "<td width='1.5%'>".( ( isset( $row[5] ) ) ? $row[5] : '&nbsp;' )."</td>";
						   echo "<td width='1.5%'>".( ( isset( $row[6] ) ) ? $row[6] : '&nbsp;' )."</td>";
						}
					}
				}
				?>
                <td width="2%"> 
                  <?php echo htmlentities(isset( $result[4] ) ? $result[4] : '' );?>
                </td>
                <td width="2%"> 
                  <?php echo htmlentities((isset( $result[5] ) ? $result[5] : '0' ));?>
                </td>
              </tr>
              <?php
			} ?>
              <?php 
	}else
	{
		$error = SimpleXLSX::parse_error();
	}
?>
            </tbody>
          </table>
        </div>
      </div>
      </section> </div>
</div>
<!-- page end-->
</div>
</section>
<!-- footer -->
<?php include('includes/footer.php');?>
  <!-- / footer -->
</section>
<!--main content end-->
</section>
<script src="js/bootstrap.js"></script>
<script src="js/jquery.dcjqaccordion.2.7.js"></script>
<script src="js/scripts.js"></script>
<script src="js/jquery.slimscroll.js"></script>
<script src="js/jquery.nicescroll.js"></script>
<!--[if lte IE 8]><script language="javascript" type="text/javascript" src="js/flot-chart/excanvas.min.js"></script><![endif]-->
<script src="js/jquery.scrollTo.js"></script>
</body>
</html>
	<?php 	}
		}
	}
?>