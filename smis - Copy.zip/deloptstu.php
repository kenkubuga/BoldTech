		<?php
session_start();
error_reporting(0);
include('includes/config.php');
			$cid=intval($_GET['cid']);
			$sql="delete from tbloptionalstudent where id=:cid ";
			$query = $dbh->prepare($sql);
			$query->bindParam(':cid',$cid,PDO::PARAM_STR);
			$query->execute();
		?>