<?php
error_reporting(0);
define('DB_NAME', 'fastlfny_fastlq51_smis');
define('DB_USER', 'fastlfny_fastlq51_acauser');
define('DB_PASSWORD', '#d^CY!d,7ghd');
define('DB_HOST', 'localhost');
 
// Create connection
$db     =   new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
// Check connection
if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}
?>
