<?php
session_start();
//error_reporting(0);
include('includes/config.php');
DEFINE('BASENAMESS',basename(__FILE__));
if(strlen($_SESSION['alogin'])=="")
    {   
    header("Location: index.php"); 
    }
    else{
		 $d1=(isset($_GET['d1']))? clean($_GET['d1']):"";
		 $d2=(isset($_GET['d2']))? clean($_GET['d2']):"";
		 $ca=(isset($_GET['ca']))? clean($_GET['ca']):"";
		 $st = "pending";
		 $ep = " ";

?>
<!DOCTYPE html>
<head>
<title><?php echo(isset(School()->SchoolName))? School()->SchoolName:"SMS"; ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Kasuli A-L Hotel Management System, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- bootstrap-css -->
<link rel="stylesheet" type="text/css" href="js/DataTables/datatables.min.css"/>
<link rel="stylesheet" href="css/bootstrap.min.css" >
<link rel="stylesheet" type="text/css" href="dp/jquery.datetimepicker.css"/>
<!-- //bootstrap-css -->
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href="css/style-responsive.css" rel="stylesheet"/>
<!-- font CSS -->
<link href='//fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
<!-- font-awesome icons -->
<link rel="stylesheet" href="css/kas.css" type="text/css"/>
<link rel="stylesheet" href="css/font.css" type="text/css"/>
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons -->
<script src="js/jquery2.0.3.min.js"></script>
<link href="src/jquery.bootstrap-touchspin.css" rel="stylesheet" type="text/css" media="all">
<script src="src/jquery.bootstrap-touchspin.js"></script>
<script type="text/javascript">
function PrintDiv(id) {
	var data=document.getElementById(id).innerHTML;
	var myWindow = window.open('', '<?php echo(isset(School()->SchoolName))? School()->SchoolName:"SMS"; ?>', 'height=4000,width=6000');
	myWindow.document.write('<html><head><title><?php echo(isset(School()->SchoolName))? School()->SchoolName:"SMS"; ?></title>');
	myWindow.document.write('<link rel="stylesheet" href="css/font-awesome.min.css" media="screen" >');
	myWindow.document.write('<link rel="stylesheet" href="css/bootstrap.min.css" type="text/css" />');
	myWindow.document.write('<link rel="stylesheet" href="css/font.css" media="screen" >');
	myWindow.document.write('<link rel="stylesheet" href="css/style-responsive.css" media="screen" >');
	myWindow.document.write('<link rel="stylesheet" href="css/style.css" type="text/css" />');
	myWindow.document.write('<link rel="stylesheet" href="css/kas.css" type="text/css" />');
	myWindow.document.write('</head><body >');
	myWindow.document.write(data);
	myWindow.document.write('</body></html>');
	myWindow.document.close(); // necessary for IE >= 10

	myWindow.onload=function(){ // necessary if the div contain images

		myWindow.focus(); // necessary for IE >= 10
		myWindow.print();
		myWindow.close();
	};
}
</script>
</head>
<body>
<section id="container">
<!--header start-->
<?php include('includes/topbar.php');?>
<!--header end-->
<!--sidebar start-->
<?php include('includes/sidebar.php');?>
<!--sidebar end-->
<!--main content start-->
<section id="main-content">
	<section class="wrapper">
		<div class="form-w3layouts">
            <!-- page start-->
            <div class="row">
                
    <div class="col-lg-12"> <section class="panel"> <header class="panel-heading"> 
      Fee payment Records </header> 
      <div class="panel-body"> 
        <?php if($msg){?>
        <div class="alert alert-success left-icon-alert" role="alert"> <strong>Congrats! 
          </strong> 
          <?php echo htmlentities($msg); ?>
        </div>
        <?php } 
else if($error){?>
        <div class="alert alert-danger left-icon-alert" role="alert"> <strong>Error! 
          </strong> 
          <?php echo htmlentities($error); ?>
        </div>
        <?php } ?>
        <div class="col-ms-offset-2 col-ms-10"> 
          <button class="btn btn-success btn-labeled pull-left" onclick="PrintDiv('result')">Print<span class="btn-label btn-label-right"><i class="fa fa-print"></i></span></button>
        </div>
        <br>
        <br>
        <form class="form-inline" method="GET" action="allsummary.php">
          <div class="form-group"> 
            <label for="default" class="col-sm-3 control-label">Cashier</label>
            <div class="col-sm-3"> 
              <select name="ca" id="cashier" class="form-control input-sm" required="required">
                <option value="">Select Cashier</option>
                <option value="*">All</option>
                <?php  $sql = "SELECT DISTINCT
					tblfeepayment.cashier,
					staff.fullname
					FROM
					tblfeepayment
					INNER JOIN staff ON tblfeepayment.cashier = staff.staff_id";
				$query = $dbh->prepare($sql);
				$query->execute();
				$results=$query->fetchAll(PDO::FETCH_OBJ);
				if($query->rowCount() > 0)
				{
				foreach($results as $result)
				{   ?>
                <option value="<?php echo htmlentities($result->cashier); ?>"> 
                <?php echo htmlentities($result->fullname); ?>
                </option>
                <?php }} ?>
              </select>
            </div>
          </div>
          <div class="form-group"> 
            <label for="default" class="col-sm-2 control-label">From</label>
            <div class="col-sm-3"> 
              <input type="text" id="JoinDate" title="Select Date" name="d1" autocomplete="off" placeholder="From Date" onkeyup="if (/\D/g.test(this.value)) this.value = this.value.replace(/\D/g,'')" value=""  class="form-control input-sm" required="required">
            </div>
          </div>
          <div class="form-group"> 
            <label for="default" class="col-sm-2 control-label">To</label>
            <div class="col-sm-3"> 
              <input type="text" id="LeaveDate" title="Select Date" name="d2" autocomplete="off" placeholder="To Date" onkeyup="if (/\D/g.test(this.value)) this.value = this.value.replace(/\D/g,'')" value=""  class="form-control input-sm" required="required">
            </div>
          </div>
          <button type="submit" class="btn btn-success">Search</button>
        </form>
        <br>
        <div id='result'> 
          <?php
if(!empty($ca))
{
	if($ca === "*"){
		$sql = "SELECT
		tblfeepayment.stu_id,
		tblfeepayment.id,
		tblfeepayment.transtype,
		tblfeepayment.classid,
		tblfeepayment.term,
		tblfeepayment.amount,
		tblfeepayment.Rdate,
		tblfeepayment.cashier,
		tblfeepayment.acyear,
		tblfeepayment.reason,
		tblfeepayment.paybank,
		tblfeepayment.NameDep,
		tblfeepayment.paymode,
		staff.fullname,
		student.surname,
		student.firstname
		FROM
		tblfeepayment
		INNER JOIN staff ON tblfeepayment.cashier = staff.staff_id
		INNER JOIN student ON tblfeepayment.stu_id = student.stu_id
		WHERE tblfeepayment.status != :st AND
		tblfeepayment.Rdate BETWEEN :a AND :b";
		$query = $dbh->prepare($sql);
		$query->bindParam(':st',$st, PDO::PARAM_STR);
		//$query->bindParam(':ep',$ep);
		$query->bindParam(':a', $d1);
		$query->bindParam(':b', $d2);
		$query->execute();
		$results=$query->fetchAll(PDO::FETCH_OBJ);
		$cnt=1;

		?>
          <table id="example" class="gridtable" cellspacing="0" width="100%">
            <thead>
              <tr> 
                <th>#</th>
                <th>Student ID.</th>
                <th>Name</th>
                <th>Narration</th>
                <th>Type</th>
                <th>Amount</th>
                <th>Payment Date</th>
                <th>Paid By</th>
                <th> Bank</th>
                <th> Mode</th>
                <th class="noprint">Action</th>
              </tr>
            </thead>
            <tbody>
              <?php
		if($query->rowCount() > 0)
		{
		foreach($results as $result)
		{ ?>
              <tr class="record"> 
                <td> 
                  <?php echo htmlentities($cnt);?>
                </td>
                <td> 
                  <?php echo htmlentities($result->stu_id);?>
                </td>
                <td> 
                  <?php echo htmlentities($result->surname);?>
                  <?php echo htmlentities($result->firstname);?>
                </td>
                <td> 
                  <?php echo htmlentities($result->reason);?>
                </td>
                <td> 
                  <?php echo htmlentities($result->transtype);?>
                </td>
                <td> 
                  <?php echo htmlentities($result->amount);?>
                </td>
                <td>

                  <?php echo htmlentities($result->Rdate);?>
                </td>
                <td> 
                  <?php echo htmlentities($result->NameDep);?>
                </td>
                <td> 
                  <?php echo htmlentities($result->paybank);?>
                </td>
                <td> 
                  <?php echo htmlentities($result->paymode);?>
                </td>
                <td class="noprint"> 
                  <?php if($result->transtype=="Credit"){ ?>
                  <a href="receipt.php?action=<?php echo htmlentities(icrypt($result->id,'e')); ?>" class="btn btn-info btn-sm btn-labeled pull-left"><i class="fa fa-eye" style="font-size:15px;color:white" title="View Student fee payment Receipt"></i> 
                  </a> 
                  <?php }else{?>
                  <!--<a href="#" class="btn btn-info btn-sm btn-labeled pull-left"><i class="fa fa-eye" style="font-size:15px;color:white" title="View Student fee payment Receipt"></i> </a>-->
                  <?php }?>
                </td>
              </tr>
              <?php $cnt=$cnt+1;}} ?>
            </tbody>
          </table>
          <?php
	}else
	{?>
          <table id="example" class="gridtable" cellspacing="0" width="100%">
            <thead>
              <tr> 
                <th>#</th>
                <th>Payment Date</th>
                <th>Student ID.</th>
                <th>Name</th>
                <th>Narration</th>
                <th>Type</th>
                <th>Amount</th>
                <th>Date Recorded</th>
                <th>Paid By</th>
                <th>Bank</th>
                <th class="noprint">Action</th>
              </tr>
            </thead>
            <tbody>
              <?php
		$sql = "SELECT
		tblfeepayment.stu_id,
		tblfeepayment.id,
		tblfeepayment.transtype,
		tblfeepayment.classid,
		tblfeepayment.term,
		tblfeepayment.amount,
		tblfeepayment.Rdate,
		tblfeepayment.cashier,
		tblfeepayment.acyear,
		tblfeepayment.reason,
		tblfeepayment.paybank,
		tblfeepayment.paydate,
		tblfeepayment.NameDep,
		staff.fullname,
		student.surname,
		student.firstname
		FROM
		tblfeepayment
		INNER JOIN staff ON tblfeepayment.cashier = staff.staff_id
		INNER JOIN student ON tblfeepayment.stu_id = student.stu_id
		WHERE tblfeepayment.status != :st AND tblfeepayment.Rdate BETWEEN :a AND :b AND tblfeepayment.cashier=:c";
		$query = $dbh->prepare($sql);
		$query->bindParam(':st',$st, PDO::PARAM_STR);
		//$query->bindParam(':ep',$ep);
		$query->bindParam(':a', $d1);
		$query->bindParam(':b', $d2);
		$query->bindParam(':c', $ca);
		$query->execute();
		$results=$query->fetchAll(PDO::FETCH_OBJ);
		$cnt=1;
		if($query->rowCount() > 0)
		{
		foreach($results as $result)
		{ ?>
              <tr class="record"> 
                <td> 
                  <?php echo htmlentities($cnt);?>
                </td>
                <td> 
					<?php $Ppaydate = htmlentities($result->paydate);
                  	$newDate = date("d-M-Y", strtotime($Ppaydate));
					echo $newDate;?>



                </td>

                <td> 
                  <?php echo htmlentities($result->stu_id);?>
                </td>
                <td> 
                  <?php echo htmlentities($result->surname);?>
                  <?php echo htmlentities($result->firstname);?>
                </td>
                <td> 
                  <?php echo htmlentities($result->reason);?>
                </td>
                <td> 
                  <?php echo htmlentities($result->transtype);?>
                </td>
                <td>  <?php echo htmlentities($result->amount);?>
                </td>
                <td> 
					<?php $ken = htmlentities($result->Rdate);
                  $newDate = date("d-M-Y", strtotime($ken));
					echo $newDate;?>
				 </td>
                <td> 
                  <?php echo htmlentities($result->NameDep);?>
                </td>
                <td> 
                  <?php echo htmlentities($result->paybank);?>
                </td>
                <td class="noprint"> 
                  <?php if($result->transtype=="Credit"){ ?>
                  <a href="receipt.php?action=<?php echo htmlentities(icrypt($result->id,'e')); ?>" class="btn btn-info btn-sm btn-labeled pull-left"><i class="fa fa-eye" style="font-size:15px;color:white" title="View Student fee payment Receipt"></i> 
                  </a> 
                  <?php }else{?>
                  <!--<a href="#" class="btn btn-info btn-sm btn-labeled pull-left"><i class="fa fa-eye" style="font-size:15px;color:white" title="View Student fee payment Receipt"></i> </a>-->
                  <?php }?>
                </td>
              </tr>
              <?php $cnt=$cnt+1;}}	
		?>
            </tbody>
          </table>
          <?php
	}
}

if(!empty($ca))
{
	if($ca === "*"){?>
          <tr> 
            <th colspan="5"> Total Payments 
              <?php echo(isset($d1))? "From ".$d1:""; ?>
              <?php echo(isset($d2))? " To ".$d2:""; ?>
            </th>
            <th> 
              <?php
		$results = $dbh->prepare("SELECT
		Sum(tblfeepayment.amount) AS Amount
		FROM
		tblfeepayment
		WHERE status != :st AND
		tblfeepayment.Rdate BETWEEN :a AND :b");
		$results->bindParam(':st',$st, PDO::PARAM_STR);
		//$results->bindParam(':ep',$ep);
		$results->bindParam(':a', $d1);
		$results->bindParam(':b', $d2);
		$results->execute();
		for($i=0; $rows = $results->fetch(); $i++){
		$dsdsd=$rows['Amount'];
		echo 'GH₵ '.formatMoney($dsdsd, true);
		}
		?>
            </th>
          </tr>
          <?php 
	}else
	{
?>
          <tr> 
            <th colspan="5"> Total Payments 
              <?php echo(isset($d1))? "From ".$d1:""; ?>
              <?php echo(isset($d2))? " To ".$d2:""; ?>
            </th>
            <th> 
              <?php
		$results = $dbh->prepare("SELECT
		Sum(tblfeepayment.amount) AS Amount
		FROM
		tblfeepayment
		WHERE status != :st AND
		tblfeepayment.Rdate BETWEEN :a AND :b AND tblfeepayment.cashier=:c");
		$results->bindParam(':a', $d1);
		$results->bindParam(':st', $st, PDO::PARAM_STR);
		//$results->bindParam(':ep', $ep);
		$results->bindParam(':b', $d2);
		$results->bindParam(':c', $ca);
		$results->execute();
		for($i=0; $rows = $results->fetch(); $i++){
		$dsdsd=$rows['Amount'];
		echo 'GH₵ '.formatMoney($dsdsd, true);
		}
		?>
            </th>
          </tr>
          <?php
	}
}
?>
        </div>
      </div>
      </section> </div>
</div>
<!-- page end-->
</div>
</section>
<!-- footer -->
<?php include('includes/footer.php');?>
  <!-- / footer -->
</section>
<!--main content end-->
</section>
<script src="js/bootstrap.js"></script>
<script src="js/jquery.dcjqaccordion.2.7.js"></script>
<script src="js/scripts.js"></script>
<script src="js/jquery.slimscroll.js"></script>
<script src="js/jquery.nicescroll.js"></script>
<!--[if lte IE 8]><script language="javascript" type="text/javascript" src="js/flot-chart/excanvas.min.js"></script><![endif]-->
<script src="js/jquery.scrollTo.js"></script>
<script src="js/DataTables/datatables.min.js"></script>
<script src="dp/jquery.datetimepicker.full.js"></script>

<script>
  var birthdate = $('#Birthdate').val();
    var today = new Date();
    var dd = today.getDate();
    var mm = today.getMonth()+1;
    var yy = today.getFullYear();
    var tdate = yy+"-"+mm+"-"+dd;

$('#Birthdate').datetimepicker({
  yearOffset:0,
  lang:'ch',
  timepicker:false,
  format:'Y-m-d',
  formatDate:'Y-m-d',
  //minDate:'-1980/01/01', // yesterday is minimum date
  maxDate: tdate, // and tommorow is maximum date calendar
});

$('#JoinDate').datetimepicker({
  yearOffset:0,
  lang:'ch',
  timepicker:false,
  format:'Y-m-d',
  formatDate:'Y-m-d',
  //minDate:'-1980/01/01', // yesterday is minimum date
  maxDate: tdate // and tommorow is maximum date calendar
});

$('#LeaveDate').datetimepicker({
  yearOffset:0,
  lang:'ch',
  timepicker:false,
  format:'Y-m-d',
  formatDate:'Y-m-d',
  maxDate: tdate
});
</script>

<script>
	$(function($) {
		$('#example').DataTable({
			dom: 'Bfrtip',
			buttons: [
				'excelHtml5',
				'csvHtml5',
				'pdfHtml5'
			],

			"pager": 150,
			"pageLength" : 100,
			
		});
	});


</script>
</body>
</html>
<?php }?>