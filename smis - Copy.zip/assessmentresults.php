<?php
session_start();
error_reporting(0);
DEFINE('BASENAMESS',basename(__FILE__));
include('includes/config.php');
$sta=clean($_POST['staff']);
$staa=clean($_POST['date1']);
require_once "kasulixlsx.class.php";
if(strlen($_SESSION['alogin'])=="")
    {   
    header("Location: index.php"); 
	}else
	{
		
		
?>
<!DOCTYPE html>
<head>
<title><?php echo(isset(School()->SchoolName))? School()->SchoolName:"SMS"; ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Kasuli A-L Hotel Management System, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- bootstrap-css -->
<link rel="stylesheet" href="css/bootstrap.min.css" >
<!-- //bootstrap-css -->
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href="css/style-responsive.css" rel="stylesheet"/>
<!-- font CSS -->
<link href='//fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
<!-- font-awesome icons -->
<link rel="stylesheet" href="css/font.css" type="text/css"/>
<link rel="stylesheet" href="css/kas.css" type="text/css"/>
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons -->
<script src="js/jquery2.0.3.min.js"></script>
  <link href="src/jquery.bootstrap-touchspin.css" rel="stylesheet" type="text/css" media="all">
  <script src="src/jquery.bootstrap-touchspin.js"></script>
<script type="text/javascript">
function PrintDiv(id) {
	var data=document.getElementById(id).innerHTML;
	var myWindow = window.open('', '<?php echo(isset(School()->SchoolName))? School()->SchoolName:"SMS"; ?>', 'height=4000,width=6000');
	myWindow.document.write('<html><head><title><?php echo(isset(School()->SchoolName))? School()->SchoolName:"SMS"; ?></title>');
	myWindow.document.write('<link rel="stylesheet" href="css/font-awesome.min.css" media="screen" >');
	myWindow.document.write('<link rel="stylesheet" href="css/bootstrap.min.css" type="text/css" />');
	myWindow.document.write('<link rel="stylesheet" href="css/font.css" media="screen" >');
	myWindow.document.write('<link rel="stylesheet" href="css/style-responsive.css" media="screen" >');
	myWindow.document.write('<link rel="stylesheet" href="css/style.css" type="text/css" />');
	myWindow.document.write('<link rel="stylesheet" href="css/kas.css" type="text/css" />');
	myWindow.document.write('</head><body >');
	myWindow.document.write(data);
	myWindow.document.write('</body></html>');
	myWindow.document.close(); // necessary for IE >= 10

	myWindow.onload=function(){ // necessary if the div contain images

		myWindow.focus(); // necessary for IE >= 10
		myWindow.print();
		myWindow.close();
	};
}
</script>
</head>
<body>
<section id="container">
<!--header start-->
<?php include('includes/topbar.php');?>
<!--header end-->
<!--sidebar start-->
<?php include('includes/sidebar.php');?>
<!--sidebar end-->
<!--main content start-->
<section id="main-content">
<section class="wrapper">
<div class="form-w3layouts">
	<!-- page start-->
<div class="row">
	
  <div class="col-lg-11"> <section class="panel"> <header class="panel-heading"> 
    Staff results </header> 
    <div class="col-ms-offset-2 col-ms-10"> 
      <button class="btn btn-success btn-labeled pull-right" onclick="PrintDiv('result')">Print<span class="btn-label btn-label-right"><i class="fa fa-print"></i></span></button>
    </div>
    <div class="panel-body"> 
      <div id ='result' > 
	  
	  <?php 
		$sql = "SELECT staffid,wkdate,classid,subjectid,lesson,actual,ol,exercise,eactual,oe,obj,intro,tla,tlm,cp,eval,cc,psp,timem,pchallenge,suggestions,lowermarks,remark from stafflesson where staffid=:st and wkdate=:stt";
$query = $dbh->prepare($sql);
$query->bindParam(':st',$sta,PDO::PARAM_STR);
$query->bindParam(':stt',$staa,PDO::PARAM_STR);
$query->execute();
$rows=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($rows as $row)

{ 
	 ?>
        
        <div style="border:solid 1px black;margin:auto; page-break-after: always; height:1132px;width:820px;"> 
          <table class="resulttable" cellspacing="0" width="100%">
            <tr> 
              <td> <img class="img-rounded" src="school/<?php echo htmlentities(School()->SchoolLogo);?>" alt="School Logo" style="width:auto; height:120px;"><br/> 
              </td>
              <td> <center>
                  <font style=" font:bold 35px 'Aleo'; text-shadow:1px 1px 15px #000; color:#0498CF;"> 
                  <?php echo htmlentities(School()->SchoolName);?>
                  </font>
                </center>
                <div style="text-align:center;" > 
                  <center>
                    <font style=" font:bold 25px 'Aleo';  color:#44484B;"> 
                    <?php echo htmlentities(School()->SchoolMoto);?>
                    </font>
                  </center>
                  <?php echo htmlentities(School()->PostAddress);?>
                  || 
                  <?php echo htmlentities(School()->SchoolEmail);?>
                  || Phone: 
                  <?php echo htmlentities(School()->SchoolPhone);?>
				  || 
                <?php echo htmlentities(School()->SchoolPhone2);?>
                </div></td>
              <td align="right"> <img src="student/<?php ;?>" class="img-rounded" id="test" class="media-object" style="width: 120px; height: 120px; border: 1%;"> 
              </td>
            </tr>
          </table>
		  <?php 
		$sql = "SELECT fullname,othername from staff where staff_id=:st";
$query = $dbh->prepare($sql);
$query->bindParam(':st',$sta,PDO::PARAM_STR);
$query->execute();
$rows=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($rows as $row1)

{ 
$stname=$row1->fullname;
$stname1=$row1->othername;
}}
	 ?>
          <center>
            <font style=" font:bold 30px 'Aleo'; text-shadow:1px 1px 15px #000; color:#44484B;"> 
            <i>Staff Assessment Results</i></font>
          </center>
		  <center>
            <font style=" font:bold 30px 'Aleo'; text-shadow:1px 1px 15px #000; color:#44484B;"> 
            <i>Name: <?php echo $stname." ".$stname1; ?></i></font>
          </center>
          <center>
            <font style=" font:bold 30px 'Aleo'; text-shadow:1px 1px 15px #000; color:#44484B;"> 
            <i>Week: <?php echo $staa." To ".date('Y-m-d', strtotime($staa. ' + 5 days')); ?></i></font>
          </center>
		  
		  
	 
          <table class="resulttable" cellpadding="0" cellspacing="0" border="0" width="100%" >
            <tr width="20%"> 
             
				<td > <font style=" font:bold 20px 'Aleo';  color:#44484B;"> 
                Class :</font></td>

				<td><?php echo htmlentities(GetClass($row->classid))?></td>
				 
				<td> <font style=" font:bold 20px 'Aleo';  color:#44484B;"> 
                Subject : </td>
				<td colspan="3"><?php echo htmlentities(Getsubject($row->subjectid))?></td>
				
            </tr>
			<tr width="20%"> 
			<td > <font style=" font:bold 20px 'Aleo';  color:#44484B;"> 
                Lesson notes to be prepared:</font><font style=" font:bold 21px 'Aleo'; margin-left:4.5em; color:#44484B; margin-left:2.5em"> 
                
                </font> </td>
				<td><?php echo htmlentities($row->lesson)?></td>
				
				<td > <font style=" font:bold 20px 'Aleo';  color:#44484B;"> 
                lessons notes prepared:</font><font style=" font:bold 21px 'Aleo'; margin-left:4.5em; color:#44484B; margin-left:2.5em"> 
                
                </font> </td>
				<td><?php echo htmlentities($row->actual)?></td>
				<td > <font style=" font:bold 20px 'Aleo';  color:#44484B;"> 
                Outstanding Lesson:</font><font style=" font:bold 21px 'Aleo'; margin-left:4.5em; color:#44484B; margin-left:2.5em"> 
                
                </font> </td>
				<td><?php echo htmlentities($row->ol)?></td>
              
				
            </tr>
			
			<tr width="20%"> 
			<td > <font style=" font:bold 20px 'Aleo';  color:#44484B;"> 
                No. of exercise:</font><font style=" font:bold 21px 'Aleo'; margin-left:4.5em; color:#44484B; margin-left:2.5em"> 
                
                </font> </td>
				<td><?php echo htmlentities($row->exercise)?></td>
				
				<td width="25%"> <font style=" font:bold 20px 'Aleo';  color:#44484B;"> 
                Actual Exercise:</font><font style=" font:bold 21px 'Aleo'; margin-left:4.5em; color:#44484B; margin-left:2.5em"> 
                
                </font> </td>
				<td ><?php echo htmlentities($row->eactual)?></td>
				
				<td > <font style=" font:bold 20px 'Aleo';  color:#44484B;"> 
                Outstanding Exercise:</font><font style=" font:bold 21px 'Aleo'; margin-left:4.5em; color:#44484B; margin-left:2.5em"> 
                
                </font> </td>
				<td width="20%"><?php echo htmlentities($row->oe)?></td>
				
				
            </tr>
			
			<tr width="20%"> 
			
              <td  width="25%"> <font style=" font:bold 20px 'Aleo';  color:#44484B;"> 
                Objective:</font><font style=" font:bold 21px 'Aleo'; margin-left:4.5em; color:#44484B; margin-left:2.5em"> 
                
                </font> </td>
				<td width="100%" colspan="5"><?php echo htmlentities($row->obj)?></td>
              
				
				
            </tr>
			
			<tr width="20%"> 
			
              <td  width="25%"> <font style=" font:bold 20px 'Aleo';  color:#44484B;"> 
                Introduction:</font><font style=" font:bold 21px 'Aleo'; margin-left:4.5em; color:#44484B; margin-left:2.5em"> 
                
                </font> </td>
				<td width="100%" colspan="5"><?php echo htmlentities($row->intro)?></td>
              
				
				
            </tr>
			
			<tr width="20%"> 
			
              <td  width="25%"> <font style=" font:bold 20px 'Aleo';  color:#44484B;"> 
                TLA:</font><font style=" font:bold 21px 'Aleo'; margin-left:4.5em; color:#44484B; margin-left:2.5em"> 
                
                </font> </td>
				<td width="100%" colspan="5"><?php echo htmlentities($row->tla)?></td>
              
				
				
            </tr>
			<tr width="20%"> 
			
              <td  width="25%"> <font style=" font:bold 20px 'Aleo';  color:#44484B;"> 
                TLM'S:</font><font style=" font:bold 21px 'Aleo'; margin-left:4.5em; color:#44484B; margin-left:2.5em"> 
                
                </font> </td>
				<td width="100%" colspan="5"><?php echo htmlentities($row->tlm)?></td>
              
				
				
            </tr>
			<tr width="20%"> 
			
              <td  width="25%"> <font style=" font:bold 20px 'Aleo';  color:#44484B;"> 
                Core Points:</font><font style=" font:bold 21px 'Aleo'; margin-left:4.5em; color:#44484B; margin-left:2.5em"> 
                
                </font> </td>
				<td width="100%" colspan="5"><?php echo htmlentities($row->cp)?></td>
              
				
				
            </tr>
			<tr width="20%"> 
			
              <td  width="25%"> <font style=" font:bold 20px 'Aleo';  color:#44484B;"> 
                Evaluation:</font><font style=" font:bold 21px 'Aleo'; margin-left:4.5em; color:#44484B; margin-left:2.5em"> 
                
                </font> </td>
				<td width="100%" colspan="5"><?php echo htmlentities($row->eval)?></td>
              
				
				
            </tr>
			<tr width="20%"> 
			
              <td  width="25%"> <font style=" font:bold 20px 'Aleo';  color:#44484B;"> 
                Class Control:</font><font style=" font:bold 21px 'Aleo'; margin-left:4.5em; color:#44484B; margin-left:2.5em"> 
                
                </font> </td>
				<td width="100%" colspan="5"><?php echo htmlentities($row->cc)?></td>
              
				
				
            </tr>
			<tr width="20%"> 
			
              <td  width="25%"> <font style=" font:bold 20px 'Aleo';  color:#44484B;"> 
                Pupil's/School Property:</font><font style=" font:bold 21px 'Aleo'; margin-left:4.5em; color:#44484B; margin-left:2.5em"> 
                
                </font> </td>
				<td width="100%" colspan="5"><?php echo htmlentities($row->psp)?></td>
              
				
				
            </tr>
            
            <tr width="20%"> 
			
              <td  width="25%"> <font style=" font:bold 20px 'Aleo';  color:#44484B;"> 
                Time Management:</font><font style=" font:bold 21px 'Aleo'; margin-left:4.5em; color:#44484B; margin-left:2.5em"> 
                
                </font> </td>
				<td width="100%" colspan="5"><?php echo htmlentities($row->timem)?></td>
              
				
				
            </tr>
			
			<tr width="20%"> 
			
              <td  width="25%"> <font style=" font:bold 20px 'Aleo';  color:#44484B;"> 
                Pupil's with specific challenges:</font><font style=" font:bold 21px 'Aleo'; margin-left:4.5em; color:#44484B; margin-left:2.5em"> 
                
                </font> </td>
				<td width="100%" colspan="5"><?php echo htmlentities($row->pchallenge)?></td>
              
				
				
            </tr>
            
            <tr width="20%"> 
			
              <td  width="25%"> <font style=" font:bold 20px 'Aleo';  color:#44484B;"> 
                Teacher's suggestion to deal with the challenges:</font><font style=" font:bold 21px 'Aleo'; margin-left:4.5em; color:#44484B; margin-left:2.5em"> 
                
                </font> </td>
				<td width="100%" colspan="5"><?php echo htmlentities($row->suggestions)?></td>
              
			
            </tr>
            
            <tr width="20%"> 
			
              <td  width="25%"> <font style=" font:bold 20px 'Aleo';  color:#44484B;"> 
                Pupil's with lower marks:</font><font style=" font:bold 21px 'Aleo'; margin-left:4.5em; color:#44484B; margin-left:2.5em"> 
                
                </font> </td>
				<td width="100%" colspan="5"><?php echo htmlentities($row->lowermarks)?></td>
              
				
				
            </tr>
            
			<tr width="20%"> 
			
              <td width="5%"> <font style=" font:bold 20px 'Aleo';  color:#44484B;"> 
                Remarks :</font><font style=" font:bold 21px 'Aleo'; margin-left:4.5em; color:#44484B; margin-left:2.5em"> 
                
                </font> </td>
				<td width="100%" colspan="5"><?php echo htmlentities($row->remark)?></td>
				
            </tr>
            	<tr width="20%"> 
			
              <td width="5%"> <font style=" font:bold 20px 'Aleo';  color:#44484B;"> 
                Director's Remark:</font><font style=" font:bold 21px 'Aleo'; margin-left:4.5em; color:#44484B; margin-left:2.5em"> 
                
                </font> </td>
				<td width="100%" colspan="5" style=" height:70px;"></td>
				
            </tr>
			
			
			
			<br>
			
	</table>	
</div>	
<?php } }?>     




	<br>
		<br>
		 <h3><center>Suplimentry Books</center></h3>
		<?php 
		$sql = "SELECT staffid,wkdate,book,exercise,actuale,ol,remark from staffsupbook where staffid=:st and wkdate=:stt";
$query1 = $dbh->prepare($sql);
$query1->bindParam(':st',$sta,PDO::PARAM_STR);
$query1->bindParam(':stt',$staa,PDO::PARAM_STR);
$query1->execute();
$rows1=$query1->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query1->rowCount() > 0)
{
foreach($rows1 as $row1)

{ 
	 ?>
	 
          <table class="resulttable" cellspacing="0" width="100%" >
		 
            <tr width="20%"> 
             
				
				<td width="25%"> <font style=" font:bold 20px 'Aleo';  color:#44484B;"> 
                Book Name : </font></td>
				<td width="25%"><?php echo htmlentities($row1->book)?></td>
				
				<td  > <font style=" font:bold 20px 'Aleo';  color:#44484B;"> 
                No. of exercise: 
                
                </font> </td>
				<td><?php echo htmlentities($row1->exercise)?></td>
				
            </tr>
			<tr width="20%"> 
			
				
				<td  width="25%"> <font style=" font:bold 20px 'Aleo';  color:#44484B;"> 
                Actual Exercise:
                
                </font> </td>
				<td width="25%"><?php echo htmlentities($row1->actuale)?></td>
				
				<td  width="25%"> <font style=" font:bold 20px 'Aleo';  color:#44484B;"> 
                Outstanding:</font><font style=" font:bold 21px 'Aleo'; margin-left:4.5em; color:#44484B; margin-left:2.5em"> 
                
                </font> </td>
				<td width="100%" colspan="3"><?php echo htmlentities($row1->ol)?></td>
              
				
            </tr>
			
			
			
			<tr width="20%"> 
			
              <td width="5%"> <font style=" font:bold 20px 'Aleo';  color:#44484B;"> 
                Remarks :</font><font style=" font:bold 21px 'Aleo'; margin-left:4.5em; color:#44484B; margin-left:2.5em"> 
                
                </font> </td>
				<td width="100%" colspan="3"><?php echo htmlentities($row1->remark)?></td>
				
            </tr>
			<br>
			
			
		
			
<?php } }?>     
            
           
          
				
            
          </table>
		  
		  <br>
			<br>
			<br>
            <tr> 
                <td  width="80%" align="left"> 
                  <b style="text-decoration: overline;  width: 50%; margin-left:4.5em"> 
            Supervisor's Name</b>
                </td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                
                 <td  width="20%" align="right">
                <b style="text-decoration: overline;  width: 50%; margin-left:4.5em"> 
            Class teacher's Name</b>
            </td>
         
        <br>
			<br>
			<br>
            <tr> 
                <td  width="80%" align="left"> 
                  <b style="text-decoration: overline;  width: 50%; margin-left:4.5em"> 
            Supervisor's Sign</b>
                </td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                
                 <td  width="20%" align="right">
                <b style="text-decoration: overline;  width: 50%; margin-left:4.5em"> 
            Class teacher's Sign</b>
            </td>
         
        <br>
 
      </div>
      </div>
  </div>
<!-- page end-->
</div>


</section>
<!-- footer -->
<?php include('includes/footer.php');?>
  <!-- / footer -->
</section>
<!--main content end-->
</section>
<script src="js/bootstrap.js"></script>
<script src="js/jquery.dcjqaccordion.2.7.js"></script>
<script src="js/scripts.js"></script>
<script src="js/jquery.slimscroll.js"></script>
<script src="js/jquery.nicescroll.js"></script>
<script src="js/jquery.scrollTo.js"></script>
</body>
</html>
	<?php	
	}?>