<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['alogin'])=="")
    {   
    header("Location: index.php"); 
    }
    else{
		if(isset($_POST['submit']))
		{
		$cid=$_POST['class'];
		$year=$_POST['year'];
		$term=$_POST['term'];
		$studentid=$_POST['studentid'];
			if($studentid==1){
			 $stmt = $dbh->prepare("SELECT StudentName,IndexNo FROM tblstudents WHERE ClassId= :id order by StudentName");
			 $stmt->execute(array(':id' => $cid));
			 while($row=$stmt->fetch(PDO::FETCH_ASSOC))
			 {
				 $indexno = $row['IndexNo'];
						$qery = "SELECT tblstudents.StudentName,tblstudents.IndexNo,tblstudents.StudentEmail,tblstudents.ParentId,tblstudents.ClassId,tblclasses.ClassName,tblclasses.Section,tblparent.ParentEmail FROM tblstudents INNER JOIN tblclasses ON tblstudents.ClassId=tblclasses.id,tblparent WHERE tblstudents.ParentId=tblparent.Id AND tblstudents.IndexNo=:indexno AND tblstudents.ClassId=:classid";
		$stmt = $dbh->prepare($qery);
		$stmt->bindParam(':indexno',$indexno,PDO::PARAM_STR);
		$stmt->bindParam(':classid',$cid,PDO::PARAM_STR);
		$stmt->execute();
		$resultss=$stmt->fetchAll(PDO::FETCH_OBJ);
		$cnt=1;
		if($stmt->rowCount() > 0)
		{
		foreach($resultss as $row)
	{ 
	$sname=$row->StudentName;
	$sclass=$row->ClassName;
	$ssection=$row->Section;
	$semail=$row->StudentEmail;
	$pemail=$row->ParentEmail;
		
			$cdetails=$sclass." ".$year.$ssection;
		$sdetails=$sname." ".$cdetails." ".$term." "."Exam Marks::";
	}
	
	$tablemessage .="<p><b>Student Name : </b>". strip_tags($row->StudentName)."</p>
		<p><b>Student Index No. : </b>". strip_tags($row->IndexNo)."</p>
		<p><b>Student Class : </b>". strip_tags($row->ClassName)." ".strip_tags($year).strip_tags($row->Section)."</p>";
		$tablemessage .=	'<table class="table table-hover table-bordered">';
		$tablemessage .= "<thead>
				<tr>
					<th>#</th>
					<th>Subject</th>    
					<th>Marks</th>
					<th>Grade</th>
					<th>Comments</th>
				</tr>
				 </thead>";
	
				$qry ="select t.StudentName,t.IndexNo,t.ClassId,t.yearLvl,t.marks,t.Term,SubjectId,tblsubjects.SubjectName from (select sts.StudentName,sts.IndexNo,sts.yearLvl,sts.ClassId,tr.Term,tr.marks,SubjectId from tblstudents as sts join  tblresult as tr on tr.StudentId=sts.IndexNo and tr.yearLvl=:year) as t join tblsubjects on tblsubjects.id=t.SubjectId where (t.IndexNo=:indexno and t.ClassId=:classid and t.Term=:term)";
				$query= $dbh -> prepare($qry);
				$query->bindParam(':indexno',$indexno,PDO::PARAM_STR);
				$query->bindParam(':classid',$cid,PDO::PARAM_STR);
				$query->bindParam(':year',$year,PDO::PARAM_STR);
				$query->bindParam(':term',$term,PDO::PARAM_STR);
				$query-> execute();  
				$results = $query -> fetchAll(PDO::FETCH_OBJ);
				$cnt=1;
				if($countrow=$query->rowCount()>0)
				{
					foreach($results as $result){
		$mark=$result->marks;
		if($mark>=85){
			$grade="A";
			$cmm="Excellent";
		}
		elseif($mark>=70){
			$grade="B";
			$cmm="Very Good";
		}
		elseif($mark>=55){
			$grade="C";
			$cmm="Good";
		}
		elseif($mark>=45){
			$grade="D";
			$cmm="Credit";
		}
		else{
			$grade="F";
			$cmm="Fail";
		}
								/*Start of table message*/
$tablemessage .= '<tbody>
					<tr>
						<th scope="row">'.strip_tags($cnt)."</th>
						<td>".strip_tags($result->SubjectName)."</td>
						<td>".strip_tags($totalmarks=$result->marks)."</td>
						<td>".strip_tags($grade)."</td>
						<td>".strip_tags($cmm)."</td>
					</tr>
				</tbody>";
$tablemessage .=	"</table>";
								/*End of table message*/

							${"mark" . $cnt} = $result->marks;
							$subject=$result->SubjectName;
							${"ssubject" . $cnt} = $subject;
							$cnt++;	}
/*-----------Knight Rider-------------*/require 'p.php';/*-----------Knight Rider-------------*/
/*combining the subjects and their marks*/	$ds1=$ssubject1." ".$mark1. " ".$grade1. " ".$cmm1;/*combining the subjects and their marks*/
											$ds2=$ssubject2." ".$mark2. " ".$grade2. " ".$cmm2;
											$ds3=$ssubject3." ".$mark3. " ".$grade3. " ".$cmm3;
											$ds4=$ssubject4." ".$mark4. " ".$grade4. " ".$cmm4;
											$ds5=$ssubject5." ".$mark5. " ".$grade5. " ".$cmm5;
											$ds6=$ssubject6." ".$mark6. " ".$grade6. " ".$cmm6;
											$ds7=$ssubject7." ".$mark7. " ".$grade7. " ".$cmm7;
											$ds8=$ssubject8." ".$mark8. " ".$grade8. " ".$cmm8;
											
								$markdetail=$ds1." || ".$ds2." || ".$ds3." || ".$ds4." || ".$ds5." || ".$ds6." || ".$ds7." || ".$ds8;
								$ssmessage=$sdetails." ".$markdetail;
								
							            require 'phpmailer/PHPMailerAutoload.php';
					$email = "srmsemail3";                    
                    $password = "tumalana";
                    $to_id = $semail;
                    $message = $ssmessage;
                    $subject = "END OF TERM RESULTS";

                    $mail = new PHPMailer;
					
					 $mail->SMTPOptions = array(
						'ssl' => array(
						'verify_peer' => false,
						'verify_peer_name' => false,
						'allow_self_signed' => true
										)
												);

                    $mail->isSMTP();

                    $mail->Host = 'smtp.gmail.com';

                    $mail->Port = 587;

                    $mail->SMTPSecure = 'tls';

                    $mail->SMTPAuth = true;

                    $mail->Username = $email;

                    $mail->Password = $password;

                    $mail->setFrom('srmsemail3@gmail.com', 'SRMS');

                    $mail->addReplyTo('srmsemail3@gmail.com', 'SRMS');

                    $mail->addAddress($to_id);
					$mail->addBCC($pemail);

                    $mail->Subject = $subject;

                    $mail->msgHTML($tablemessage);
					$mail->AltBody=$message;

                    if (!$mail->send()) {
                       $error = "Mailer Error: " . $mail->ErrorInfo;
                        
                    } 
                    else {
                       $msg1="Email sent successfully";
                    }
		}

		else
		{
			$warning="Results Not Publish Yet";
		}
		}
			 }	
			}else{
		$qery = "SELECT tblstudents.StudentName,tblstudents.IndexNo,tblstudents.StudentEmail,tblstudents.ParentId,tblstudents.ClassId,tblclasses.ClassName,tblclasses.Section,tblparent.ParentEmail FROM tblstudents INNER JOIN tblclasses ON tblstudents.ClassId=tblclasses.id,tblparent WHERE tblstudents.ParentId=tblparent.Id AND tblstudents.IndexNo=:indexno AND tblstudents.ClassId=:classid";
		$stmt = $dbh->prepare($qery);
		$stmt->bindParam(':indexno',$studentid,PDO::PARAM_STR);
		$stmt->bindParam(':classid',$cid,PDO::PARAM_STR);
		$stmt->execute();
		$resultss=$stmt->fetchAll(PDO::FETCH_OBJ);
		$cnt=1;
		if($stmt->rowCount() > 0)
		{
		foreach($resultss as $row)
	{ 
	$sname=$row->StudentName;
	$sclass=$row->ClassName;
	$ssection=$row->Section;
	$semail=$row->StudentEmail;
	$pemail=$row->ParentEmail;
		
			$cdetails=$sclass." ".$year.$ssection;
		$sdetails=$sname." ".$cdetails." ".$term." "."Exam Marks::";
	}
	
	$tablemessage .="<p><b>Student Name : </b>". strip_tags($row->StudentName)."</p>
		<p><b>Student Index No. : </b>". strip_tags($row->IndexNo)."</p>
		<p><b>Student Class : </b>". strip_tags($row->ClassName)." ".strip_tags($year).strip_tags($row->Section)."</p>";
		$tablemessage .=	'<table class="table table-hover table-bordered">';
		$tablemessage .= "<thead>
				<tr>
					<th>#</th>
					<th>Subject</th>    
					<th>Marks</th>
					<th>Grade</th>
					<th>Comments</th>
				</tr>
				 </thead>";
	
				$qry ="select t.StudentName,t.IndexNo,t.ClassId,t.yearLvl,t.marks,t.Term,SubjectId,tblsubjects.SubjectName from (select sts.StudentName,sts.IndexNo,sts.yearLvl,sts.ClassId,tr.Term,tr.marks,SubjectId from tblstudents as sts join  tblresult as tr on tr.StudentId=sts.IndexNo and tr.yearLvl=:year) as t join tblsubjects on tblsubjects.id=t.SubjectId where (t.IndexNo=:indexno and t.ClassId=:classid and t.Term=:term)";
				$query= $dbh -> prepare($qry);
				$query->bindParam(':indexno',$studentid,PDO::PARAM_STR);
				$query->bindParam(':classid',$cid,PDO::PARAM_STR);
				$query->bindParam(':year',$year,PDO::PARAM_STR);
				$query->bindParam(':term',$term,PDO::PARAM_STR);
				$query-> execute();  
				$results = $query -> fetchAll(PDO::FETCH_OBJ);
				$cnt=1;
				if($countrow=$query->rowCount()>0)
				{
					foreach($results as $result){
		$mark=$result->marks;
		if($mark>=85){
			$grade="A";
			$cmm="Excellent";
		}
		elseif($mark>=70){
			$grade="B";
			$cmm="Very Good";
		}
		elseif($mark>=55){
			$grade="C";
			$cmm="Good";
		}
		elseif($mark>=45){
			$grade="D";
			$cmm="Credit";
		}
		else{
			$grade="F";
			$cmm="Fail";
		}
								/*Start of table message*/
$tablemessage .= '<tbody>
					<tr>
						<th scope="row">'.strip_tags($cnt)."</th>
						<td>".strip_tags($result->SubjectName)."</td>
						<td>".strip_tags($totalmarks=$result->marks)."</td>
						<td>".strip_tags($grade)."</td>
						<td>".strip_tags($cmm)."</td>
					</tr>
				</tbody>";
$tablemessage .=	"</table>";
								/*End of table message*/

							${"mark" . $cnt} = $result->marks;
							$subject=$result->SubjectName;
							${"ssubject" . $cnt} = $subject;
							$cnt++;	}
/*-----------Knight Rider-------------*/require 'p.php';/*-----------Knight Rider-------------*/
/*combining the subjects and their marks*/	$ds1=$ssubject1." ".$mark1. " ".$grade1. " ".$cmm1;/*combining the subjects and their marks*/
											$ds2=$ssubject2." ".$mark2. " ".$grade2. " ".$cmm2;
											$ds3=$ssubject3." ".$mark3. " ".$grade3. " ".$cmm3;
											$ds4=$ssubject4." ".$mark4. " ".$grade4. " ".$cmm4;
											$ds5=$ssubject5." ".$mark5. " ".$grade5. " ".$cmm5;
											$ds6=$ssubject6." ".$mark6. " ".$grade6. " ".$cmm6;
											$ds7=$ssubject7." ".$mark7. " ".$grade7. " ".$cmm7;
											$ds8=$ssubject8." ".$mark8. " ".$grade8. " ".$cmm8;
											
								$markdetail=$ds1." || ".$ds2." || ".$ds3." || ".$ds4." || ".$ds5." || ".$ds6." || ".$ds7." || ".$ds8;
								$ssmessage=$sdetails." ".$markdetail;
								
							            require 'phpmailer/PHPMailerAutoload.php';
					$email = "srmsemail3";                    
                    $password = "tumalana";
                    $to_id = $semail;
                    $message = $ssmessage;
                    $subject = "END OF TERM RESULTS";

                    $mail = new PHPMailer;
					
					 $mail->SMTPOptions = array(
						'ssl' => array(
						'verify_peer' => false,
						'verify_peer_name' => false,
						'allow_self_signed' => true
										)
												);

                    $mail->isSMTP();

                    $mail->Host = 'smtp.gmail.com';

                    $mail->Port = 587;

                    $mail->SMTPSecure = 'tls';

                    $mail->SMTPAuth = true;

                    $mail->Username = $email;

                    $mail->Password = $password;

                    $mail->setFrom('srmsemail3@gmail.com', 'SRMS');

                    $mail->addReplyTo('srmsemail3@gmail.com', 'SRMS');

                    $mail->addAddress($to_id);
					$mail->addBCC($pemail);

                    $mail->Subject = $subject;

                    $mail->msgHTML($tablemessage);
					$mail->AltBody=$message;

                    if (!$mail->send()) {
                       $error = "Mailer Error: " . $mail->ErrorInfo;
                        
                    } 
                    else {
                       $msg1="Email sent successfully";
                    }
		}

		else
		{
			$warning="Results Not Publish Yet";
		}
		}
		}
		}
?>
<!DOCTYPE html>
<head>
<title>SRMS</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Visitors Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- bootstrap-css -->
<link rel="stylesheet" href="css/bootstrap.min.css" >
<!-- //bootstrap-css -->
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href="css/style-responsive.css" rel="stylesheet"/>
<link rel="stylesheet" href="css/select2/select2.min.css" >
<!-- font CSS -->
<link href='//fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
<!-- font-awesome icons -->
<link rel="stylesheet" href="css/font.css" type="text/css"/>
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons -->
<script src="js/jquery2.0.3.min.js"></script>
	<script>
		function getStudent(val) {
    $.ajax({
    type: "POST",
    url: "smsStudent.php",
    data:'classid='+val,
    success: function(data){
        $("#studentid").html(data);
        
    }
    });
		$.ajax({
        type: "POST",
        url: "smsStudent.php",
        data:'classid1='+val,
        success: function(data){
            $("#subject").html(data);
            
        }
        });
}
    </script>
</head>
<body>
<section id="container">
<!--header start-->
<?php include('includes/topbar.php');?>
<!--header end-->
<!--sidebar start-->
<?php include('includes/sidebar.php');?>
<!--sidebar end-->
<!--main content start-->
<section id="main-content">
	<section class="wrapper">
		<div class="form-w3layouts">
            <!-- page start-->
            <div class="row">
                <div class="col-lg-12">
                    <section class="panel">
                        <header class="panel-heading">
                            Send Email
                            <span class="tools pull-right">
                                <a class="fa fa-chevron-down" href="javascript:;"></a>
                                <a class="fa fa-cog" href="javascript:;"></a>
                                <a class="fa fa-times" href="javascript:;"></a>
                             </span>
                        </header>
                        <div class="panel-body">
<?php if($msg){?>
<div class="alert alert-success left-icon-alert" role="alert">
 <strong>Well done!</strong><?php echo htmlentities($msg); ?>
 </div><?php } 
else if($error){?>
    <div class="alert alert-danger left-icon-alert" role="alert">
	<strong>Oh snap!</strong> <?php echo htmlentities($error); ?>
</div>
<?php } ?>																																								
<div class="col-lg-12">
                                                <form class="form-horizontal" method="post">
<div class="form-group">
    <label for="default" class="col-sm-2 control-label">Year</label>
       <div class="col-sm-4">
		 <select name="year" class="form-control yearr" id="year" required="required">
			<option value="">Select Year</option>
			<option value= "1">1</option>
			<option value= "2">2</option>
			<option value= "3">3</option>
		 </select>
		</div>	
</div>

<div class="form-group">
    <label for="default" class="col-sm-2 control-label">Term</label>
       <div class="col-sm-4">
		 <select name="term" class="form-control term" id="term" required="required" >
			<option value="">Select Term</option>
			<option value= "FIRST">FIRST</option>
			<option value= "SECOND">SECOND</option>
			<option value= "THIRD">THIRD</option>
		 </select>
		</div>	
</div>


<div class="form-group">
		<label for="default" class="col-sm-2 control-label">Class</label>
			<div class="col-sm-4">
				<select name="class" class="form-control clid" id="classid" onChange="getStudent(this.value);" required="required">
					<option value="">Select Class</option>
					<?php $sql = "SELECT * from tblclasses";
					$query2 = $dbh->prepare($sql);
					$query2->execute();
					$results1=$query2->fetchAll(PDO::FETCH_OBJ);
					if($query2->rowCount() > 0)
				{
					foreach($results1 as $result2)
				{   ?>
					<option value="<?php echo htmlentities($result2->id); ?>"><?php echo htmlentities($result2->ClassName); ?>&nbsp; Form-<?php echo htmlentities($result2->Section); ?></option>
				<?php }} ?>
				</select>
			</div>
</div>
<div class="form-group">
 <label for="date" class="col-sm-2 control-label ">Student Name</label>
  <div class="col-sm-4">
   <select name="studentid" class="form-control stid" id="studentid" required="required" >
   </select>
  </div>
</div>   
						<div class="form-group">
							<div class="col-sm-offset-2 col-sm-4">
								<button type="submit" name="submit" class="btn btn-success btn-labeled pull-right">Send Email<span class="btn-label btn-label-right"><i class="fa fa-send"></i></span></button>
							</div>
						</div>
					</form>
</div>
                        </div>
                    </section>
                </div>
            </div>
            <!-- page end-->
        </div>
</section>
 <!-- footer -->
		  <div class="footer">
			<div class="wthree-copyright">
			  <p>© 2018 Kasuli A-L Apps. All rights reserved | Design by <a href="http://Kasulisoftec.com">Kasuli A-L Apps</a></p>
			</div>
		  </div>
  <!-- / footer -->
</section>

<!--main content end-->
</section>
<script src="js/bootstrap.js"></script>
<script src="js/jquery.dcjqaccordion.2.7.js"></script>
<script src="js/scripts.js"></script>
<script src="js/jquery.slimscroll.js"></script>
<script src="js/jquery.nicescroll.js"></script>
<script src="js/select2/select2.min.js"></script>
<!--[if lte IE 8]><script language="javascript" type="text/javascript" src="js/flot-chart/excanvas.min.js"></script><![endif]-->
<script src="js/jquery.scrollTo.js"></script>
        <script>
            $(function($) {
                $(".states").select2();
                $(".js-states-limit").select2({
                    maximumSelectionLength: 2
                });
                $(".js-states-hide").select2({
                    minimumResultsForSearch: Infinity
                });
            });
        </script>
</body>
</html>
	<?php }?>